#!/usr/bin/env python3
"""Validate the deploy boundary and offline dependencies without private project data."""
import json,re
from pathlib import Path
root=Path(__file__).resolve().parent.parent
web=root/'Web'
sw=(web/'service-worker.js').read_text()
assets=json.loads(re.search(r'const ASSETS=(\[.*?\]);',sw,re.S).group(1))
for name in assets:
    target=(web/name).resolve()
    assert target.is_relative_to(web.resolve()),name
    assert target.is_file() or target==web.resolve(),name
for p in web.rglob('*'):
    assert not p.is_symlink(),f'Link simbólico: {p}'
    assert p.suffix.lower() not in {'.zip','.mov','.afdesign','.afpub','.afphoto','.command','.swift'},f'Arquivo fora da publicação: {p}'
assert (web/'index.html').is_file()
assert 'path: Web' in (root/'.github/workflows/pages.yml').read_text()
print(f'Publicação limitada a Web; {len(assets)} dependências offline verificadas.')
