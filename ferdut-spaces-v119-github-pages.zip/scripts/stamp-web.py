#!/usr/bin/env python3
import re,sys
from pathlib import Path
version=sys.argv[1]
if not re.fullmatch(r'[a-f0-9]{40}',version):raise ValueError('Commit inválido')
p=Path(__file__).resolve().parent.parent/'Web/service-worker.js'
s,count=re.subn(r"const BUILD='[^']+';",f"const BUILD='{version}';",p.read_text())
assert count==1
p.write_text(s)
