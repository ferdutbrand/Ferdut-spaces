/* Rich note editor owns selection ranges and editing lifecycle. */
window.FerdutEditor=ctx=>{
const {$,snap,hideMenu,render,nodes,save,commit}=ctx;const get=id=>FerdutShapeText.model(ctx.get(id));
function cleanRich(html){const template=document.createElement('template');template.innerHTML=html;const allowed=new Set(['B','STRONG','I','EM','U','S','SPAN','DIV','P','BR','UL','OL','LI','INPUT','FONT']);function walk(node){for(const child of [...node.childNodes]){if(child.nodeType===8){child.remove();continue}if(child.nodeType!==1)continue;if(!allowed.has(child.tagName)){child.replaceWith(document.createTextNode(child.textContent||''));continue}for(const a of [...child.attributes]){const keep=(['SPAN','DIV','P','LI','FONT'].includes(child.tagName)&&['style','data-check','contenteditable','color','face','size'].includes(a.name))||(child.tagName==='INPUT'&&['type','checked','disabled'].includes(a.name));if(!keep)child.removeAttribute(a.name)}if(['SPAN','DIV','P','LI','FONT'].includes(child.tagName)&&child.hasAttribute('style')){const st=child.style;const color=st.color,bg=st.backgroundColor,fs=st.fontSize,weight=st.fontWeight,family=st.fontFamily,decoration=st.textDecorationLine;child.removeAttribute('style');if(weight)child.style.fontWeight=weight;if(decoration)child.style.textDecorationLine=decoration;if(family)child.style.fontFamily=family;if(color)child.style.color=color;if(bg)child.style.backgroundColor=bg;if(fs&&/^\d+(px|pt|em|rem)$/.test(fs))child.style.fontSize=fs}if(child.tagName==='INPUT'){child.setAttribute('type','checkbox');child.setAttribute('disabled','');}walk(child)}}walk(template.content);return template.innerHTML}
const richbar=document.createElement('div');richbar.id='richbar';richbar.innerHTML="<details class=\"text-menu\" data-text-menu=\"color\">\n <summary aria-label=\"Cor do texto\" title=\"Cor do texto\"><span class=\"text-color-dot\"></span><span class=\"text-chevron\">⌄</span></summary>\n <div class=\"text-popover text-colors\" role=\"group\" aria-label=\"Cores de texto\">\n  <div class=\"text-swatches\"></div>\n  <label>Personalizada <input type=\"color\" data-rich=\"foreColor\" aria-label=\"Cor personalizada do texto\"></label>\n  <label data-note-only>Fundo da nota <input type=\"color\" data-rich=\"textBg\" aria-label=\"Fundo da nota\"></label>\n </div>\n</details>\n<details class=\"text-menu\" data-text-menu=\"font\">\n <summary title=\"Tipografia\" aria-label=\"Tipografia\">Aa<span class=\"text-chevron\">⌄</span></summary>\n <div class=\"text-popover\" role=\"group\" aria-label=\"Tipografia\">\n  <label>Fonte<select data-rich=\"fontName\" aria-label=\"Fonte\"><option>Host Grotesk</option><option>Arial</option><option>Georgia</option><option>Courier New</option><option>Times New Roman</option><option value=\"system-ui\">Sistema</option></select></label>\n  <label>Peso<select data-rich=\"weight\" aria-label=\"Peso da fonte\"><option value=\"400\">Regular</option><option value=\"500\">Médio</option><option value=\"600\">Seminegrito</option><option value=\"700\">Negrito</option><option value=\"800\">Extranegrito</option></select></label>\n  <div class=\"text-inline\"><button type=\"button\" data-rich=\"italic\" title=\"Itálico\" aria-label=\"Itálico\"><i>I</i></button><button type=\"button\" data-rich=\"underline\" title=\"Sublinhado\" aria-label=\"Sublinhado\"><u>U</u></button></div>\n </div>\n</details>\n<details class=\"text-menu\" data-text-menu=\"size\">\n <summary title=\"Tamanho e estilo\" aria-label=\"Tamanho e estilo\"><span data-text-size-label>12 pt</span><span class=\"text-chevron\">⌄</span></summary>\n <div class=\"text-popover\" role=\"group\" aria-label=\"Tamanho e estilo\">\n  <label>Estilo<select data-rich=\"preset\" aria-label=\"Estilo de texto\"><option value=\"body\">Corpo</option><option value=\"title\">Título</option><option value=\"subtitle\">Subtítulo</option></select></label>\n  <label>Tamanho em pontos<input data-rich=\"fontPt\" aria-label=\"Tamanho em pontos\" type=\"number\" min=\"6\" max=\"144\" step=\"1\" value=\"12\"></label>\n </div>\n</details>\n<div class=\"text-inline text-format\">\n <button type=\"button\" data-rich=\"bold\" title=\"Negrito\" aria-label=\"Negrito\"><b>B</b></button>\n <button type=\"button\" data-rich=\"strikeThrough\" title=\"Tachado\" aria-label=\"Tachado\"><s>S</s></button>\n <button type=\"button\" data-rich=\"insertUnorderedList\" title=\"Lista\" aria-label=\"Lista\"><svg viewBox=\"0 0 20 20\"><path d=\"M7 5h10M7 10h10M7 15h10M3 5h.1M3 10h.1M3 15h.1\"/></svg></button>\n <button type=\"button\" data-rich=\"checklist\" title=\"Checklist\" aria-label=\"Checklist\"><svg viewBox=\"0 0 20 20\"><path d=\"M2 3h6v6H2zM3 6l1 1 3-3M11 6h7M2 14h6M11 14h7\"/></svg></button>\n</div>\n<details class=\"text-menu\" data-text-menu=\"align\">\n <summary title=\"Alinhamento\" aria-label=\"Alinhamento\"><svg viewBox=\"0 0 20 20\"><path d=\"M3 4h14M3 8h9M3 12h14M3 16h9\"/></svg><span class=\"text-chevron\">⌄</span></summary>\n <div class=\"text-popover text-alignment\" role=\"group\" aria-label=\"Alinhamento\">\n  <select data-rich=\"alignment\" aria-label=\"Alinhamento do texto\" hidden><option value=\"left\">Esquerda</option><option value=\"center\">Centro</option><option value=\"right\">Direita</option></select>\n  <button type=\"button\" data-text-align=\"left\" title=\"Esquerda\" aria-label=\"Alinhar à esquerda\"><svg viewBox=\"0 0 20 20\"><path d=\"M3 4h14M3 8h9M3 12h14M3 16h9\"/></svg></button>\n  <button type=\"button\" data-text-align=\"center\" title=\"Centro\" aria-label=\"Centralizar texto\"><svg viewBox=\"0 0 20 20\"><path d=\"M3 4h14M5 8h10M3 12h14M5 16h10\"/></svg></button>\n  <button type=\"button\" data-text-align=\"right\" title=\"Direita\" aria-label=\"Alinhar à direita\"><svg viewBox=\"0 0 20 20\"><path d=\"M3 4h14M8 8h9M3 12h14M8 16h9\"/></svg></button>\n </div>\n</details>\n";const fit=document.createElement('button');fit.type='button';fit.dataset.rich='fitText';
fit.title='Ajustar caixa ao conteúdo';fit.setAttribute('aria-label',fit.title);
fit.innerHTML='<svg viewBox="0 0 20 20" width="18" height="18" fill="none" stroke="currentColor" aria-hidden="true"><path d="M2 7V2h5m6 0h5v5m0 6v5h-5m-6 0H2v-5M6 6h8v8H6z"/></svg>';
richbar.append(fit);richbar.setAttribute('role','toolbar');richbar.setAttribute('aria-label','Formatação do texto');
document.body.appendChild(richbar);const review=document.createElement('button');review.type='button';review.textContent='Revisar';review.title='Revisão local do texto';review.setAttribute('aria-label','Revisar');review.onclick=()=>window.FerdutTextReview.open(activeEditor);richbar.append(review);
const swatches=['#000000','#737373','#F24822','#FF9D43','#FFC94A','#65CF75','#59D4CB','#3AA7FF','#8C51FF','#E446CC','#FFFFFF','#B1B1B1','#DADADA','#FFC6C6','#FFE1C3','#FFF0B3','#CCF2CC','#C8F6F2','#C7E9FF','#DFCCFF','#FFD1F6'];
for(const color of swatches){
 const button=document.createElement('button');button.type='button';
 button.dataset.textColor=color;button.style.setProperty('--swatch',color);
 button.title=color;button.setAttribute('aria-label','Cor '+color);
 richbar.querySelector('.text-swatches').append(button);
}
function closeTextMenus(except){
 for(const menu of richbar.querySelectorAll('details[open]'))if(menu!==except)menu.open=false;
}
function placeTextPopover(menu){
 const popover=menu.querySelector('.text-popover'),anchor=menu.getBoundingClientRect();
 if(!popover)return;
 const width=popover.offsetWidth,height=popover.offsetHeight;
 popover.style.left=Math.max(8,Math.min(innerWidth-width-8,anchor.left))+'px';
 popover.style.top=Math.max(8,anchor.top-height-8>=8?anchor.top-height-8:Math.min(innerHeight-height-8,anchor.bottom+8))+'px';
}
richbar.addEventListener('pointerdown',e=>{
 const summary=e.target.closest('summary');
 if(summary)closeTextMenus(summary.closest('details'));
});
richbar.addEventListener('toggle',e=>{
 if(e.target.matches('details')&&e.target.open){closeTextMenus(e.target);placeTextPopover(e.target)}
},true);
richbar.addEventListener('click',e=>{
 const swatch=e.target.closest('[data-text-color]');
 const align=e.target.closest('[data-text-align]');
 if(swatch){richAction('foreColor',swatch.dataset.textColor);closeTextMenus();placeEditor()}
 if(align){richbar.querySelector('[data-rich=alignment]').value=align.dataset.textAlign;richAction('alignment',align.dataset.textAlign);closeTextMenus()}
});
richbar.addEventListener('keydown',e=>{
 if(e.key==='Escape'&&richbar.querySelector('details[open]')){
  const menu=richbar.querySelector('details[open]');e.preventDefault();e.stopPropagation();menu.open=false;menu.querySelector('summary').focus();
 }
});
document.addEventListener('pointerdown',e=>{if(!richbar.contains(e.target))closeTextMenus()},true);

function applyFontSize(pt,weight){
 const content=activeEditor,n=get(ctx.editingTextId);
 if(!content||!n)return;
 const selection=window.getSelection();
 const range=selection?.rangeCount?selection.getRangeAt(0):null;
 const partial=range&&!range.collapsed&&content.contains(range.commonAncestorContainer);
 const clearSizes=root=>{
  for(const el of root.querySelectorAll('[style],font[size]')){
   el.style.removeProperty('font-size');el.removeAttribute('size');
  }
 };
 if(partial){
  const fragment=range.extractContents();
  clearSizes(fragment);
  const span=document.createElement('span');
  span.style.fontSize=pt+'pt';
  if(weight)span.style.fontWeight=weight;
  span.append(fragment);range.insertNode(span);
  const next=document.createRange();next.selectNodeContents(span);
  selection.removeAllRanges();selection.addRange(next);storedRange=next.cloneRange();
 }else{
  n.fontPt=pt;clearSizes(content);content.style.removeProperty('font-size');
  content.closest('.node').style.fontSize=pt+'pt';
  if(weight){n.fontWeight=Number(weight);content.closest('.node').style.fontWeight=weight}
 }
 richbar.querySelector('[data-rich=fontPt]').value=pt;richbar.querySelector('[data-text-size-label]').textContent=pt+' pt';
 content.dispatchEvent(new Event('input',{bubbles:true}));
}
let finishActive=null;let activeEditor=null;let storedRange=null;document.addEventListener("selectionchange",()=>{if(activeEditor&&window.getSelection()?.rangeCount&&activeEditor.contains(window.getSelection().anchorNode))storedRange=window.getSelection().getRangeAt(0).cloneRange()});function richAction(cmd,value){const editor=activeEditor;if(!editor)return;const remembered=storedRange?.cloneRange();editor.focus();if(remembered&&editor.contains(remembered.commonAncestorContainer)){const sel=window.getSelection();sel.removeAllRanges();sel.addRange(remembered);storedRange=remembered}if(cmd==='weight'){
 const n=get(ctx.editingTextId);if(!n)return;
 n.fontWeight=Number(value);editor.closest('.node').style.fontWeight=value;
 editor.dispatchEvent(new Event('input',{bubbles:true}));return;
}if(cmd==='alignment'){
 const n=get(ctx.editingTextId);if(!n)return;
 n.textAlign=value;editor.closest('.node').style.textAlign=value;
 for(const button of richbar.querySelectorAll('[data-text-align]'))button.setAttribute('aria-pressed',String(button.dataset.textAlign===value));
 editor.dispatchEvent(new Event('input',{bubbles:true}));return;
}if(cmd==='fontName'&&(!storedRange||storedRange.collapsed)){
 const n=get(ctx.editingTextId);if(!n)return;
 n.fontFamily=value;editor.closest('.node').style.fontFamily=value;
 editor.dispatchEvent(new Event('input',{bubbles:true}));return;
}if(cmd==='textBg'){const n=get(ctx.editingTextId);if(n?.type==='note'){n.textBg=value;editor.closest('.node').style.background=value;save()}return}if(cmd==='preset'){
 const pt=({title:24,subtitle:17,body:12})[value]||12;
 applyFontSize(pt,value==='body'?'400':'700');return;
}if(cmd==='foreColor'){richbar.style.setProperty('--text-current-color',value);
 const sel=window.getSelection();const range=sel?.rangeCount?sel.getRangeAt(0):null;
 if(range&&!range.collapsed&&editor.contains(range.commonAncestorContainer)){
   const span=document.createElement('span');span.style.color=value;
   try{range.surroundContents(span)}catch{span.appendChild(range.extractContents());range.insertNode(span)}
   const r=document.createRange();r.selectNodeContents(span);sel.removeAllRanges();sel.addRange(r);storedRange=r.cloneRange();
 }else{const n=get(ctx.editingTextId);if(n){n.textColor=value;editor.closest('.node').style.color=value}}
 editor.dispatchEvent(new Event('input',{bubbles:true}));return
}if(cmd==='bold'&&storedRange&&!storedRange.collapsed&&editor.contains(storedRange.commonAncestorContainer)){
 const range=storedRange,span=document.createElement('span');
 const start=range.startContainer;
 const computed=getComputedStyle(start.nodeType===1?start:start.parentElement).fontWeight;
 span.style.fontWeight=Number(computed)>=600?'400':'700';
 span.appendChild(range.extractContents());range.insertNode(span);
 const selected=document.createRange();selected.selectNodeContents(span);
 const selection=window.getSelection();selection.removeAllRanges();selection.addRange(selected);storedRange=selected.cloneRange();
 editor.dispatchEvent(new Event('input',{bubbles:true}));return;
}if(cmd==='fitText'){
 const id=ctx.editingTextId;finishActive?.();ctx.fitText(id);return;
}if(cmd==='fontPt'){
 const number=Number(value);
 if(!Number.isFinite(number)||number<6||number>144)return;
 applyFontSize(number);return;
}else if(cmd==='checklist'){document.execCommand('insertHTML',false,'<div><span data-check="1" contenteditable="false">☐</span> Nova tarefa</div>')}else document.execCommand(cmd,false,value||null);editor.dispatchEvent(new Event('input',{bubbles:true}))}
richbar.addEventListener('pointerdown',e=>{if(e.target.closest('button'))e.preventDefault()});richbar.addEventListener('click',e=>{const b=e.target.closest('[data-rich]');if(b&&b.tagName==='BUTTON')richAction(b.dataset.rich)});richbar.addEventListener('change',e=>{const t=e.target.closest('[data-rich]');if(t)richAction(t.dataset.rich,t.value)});
function placeEditor(){if(!activeEditor)return;const el=activeEditor.closest('.node');FerdutFloating.place([richbar],el.getBoundingClientRect());if(richbar.dataset.placement==='docked'){ctx.reserveSpace?.(el,richbar.offsetHeight);FerdutFloating.place([richbar],el.getBoundingClientRect())}for(const menu of richbar.querySelectorAll('details[open]'))placeTextPopover(menu)}
document.addEventListener('pointerdown',e=>{if(!activeEditor)return;if(activeEditor.contains(e.target)||richbar.contains(e.target)||e.target.closest?.('#textReviewDialog'))return;finishActive?.()},{capture:true});
function startTextEdit(id){if(ctx.editingTextId===id&&activeEditor?.isConnected){return}const n=get(id);if(!n||!['text','note','shape'].includes(n.type))return;closeTextMenus();hideMenu();snap();ctx.selected=new Set([id]);render();const el=[...nodes.querySelectorAll('.node')].find(v=>v.dataset.id===id),content=el?.querySelector(n.type==='shape'?'.shape-text-content':'.node-text');if(!content)return;ctx.editingTextId=id;activeEditor=content;storedRange=null;const listeners=new AbortController(),options={signal:listeners.signal};el.classList.add('editing');if(n.type==='shape'){el.classList.add('shape-text-editing');el.style.setProperty('--shape-height',n.h+'px');el.querySelector('.shape-label').style.pointerEvents='auto'}el.style.setProperty('--note-edit-height',n.h+'px');content.contentEditable='true';content.spellcheck=true;content.lang='pt-BR';content.setAttribute('autocorrect','off');content.style.fontSize='inherit';content.style.lineHeight='normal';if(n.html)content.innerHTML=cleanRich(n.html);content.focus({preventScroll:true});
// UX-01: paste as plain text by default. Inserting text nodes at the caret
// retains the destination's inline color, font and paragraph attributes.
content.addEventListener('paste',event=>{
 const plain=event.clipboardData?.getData('text/plain');
 if(plain===undefined)return;
 event.preventDefault();
 const selection=window.getSelection();
 if(!selection?.rangeCount||!content.contains(selection.anchorNode))return;
 const range=selection.getRangeAt(0);
 range.deleteContents();
 const lines=plain.replace(/\r\n?/g,'\n').split('\n');
 const fragment=document.createDocumentFragment();
 for(let i=0;i<lines.length;i++){
   if(i)fragment.appendChild(document.createElement('br'));
   if(lines[i])fragment.appendChild(document.createTextNode(lines[i]));
 }
 const tail=fragment.lastChild;
 range.insertNode(fragment);
 if(tail){range.setStartAfter(tail);range.collapse(true);selection.removeAllRanges();selection.addRange(range)}
 content.dispatchEvent(new Event('input',{bubbles:true}));
},options);richbar.querySelector('[data-note-only]').hidden=n.type!=='note';fit.hidden=n.type==='shape';richbar.querySelector('[data-rich=alignment]').value=n.textAlign||'left';richbar.querySelector('[data-rich=weight]').value=n.fontWeight||(n.bold?700:400);richbar.querySelector('[data-rich=fontName]').value=(n.fontFamily||'Host Grotesk').split(',')[0].replace(/['"]/g,'');richbar.style.display='flex';const moveRichbar=placeEditor;moveRichbar();richbar.querySelector('[data-rich=fontPt]').value=n.fontPt||12;richbar.querySelector('[data-text-size-label]').textContent=(n.fontPt||12)+' pt';
richbar.style.setProperty('--text-current-color',getComputedStyle(content).color);
for(const b of richbar.querySelectorAll('[data-text-align]'))b.setAttribute('aria-pressed',String(b.dataset.textAlign===(n.textAlign||'left')));richbar.querySelector('[data-rich=textBg]').value=/^#[0-9a-f]{6}$/i.test(n.textBg||'')?n.textBg:'#ffffff';const range=document.createRange();range.selectNodeContents(content);range.collapse(false);const sel=window.getSelection();sel.removeAllRanges();sel.addRange(range);const padding=()=>{const style=getComputedStyle(el);return parseFloat(style.paddingTop)+parseFloat(style.paddingBottom)+parseFloat(style.borderTopWidth)+parseFloat(style.borderBottomWidth)};let dirty=false;const finish=()=>{if(ctx.editingTextId!==id)return;closeTextMenus();listeners.abort();storedRange=null;n.html=cleanRich(content.innerHTML);n.text=content.innerText.replace(/\n$/,'');if(n.type!=='shape'&&!ctx.sizeArtisticText?.(n))n.h=Math.max(n.h||120,Math.ceil(content.scrollHeight+padding()));ctx.editingTextId=null;activeEditor=null;richbar.style.display='none';content.contentEditable='false';ctx.onFinish?.(n);commit()};finishActive=finish;content.addEventListener('input',()=>{dirty=true;n.html=cleanRich(content.innerHTML);n.text=content.innerText.replace(/\n$/,'');if(n.type!=='shape'&&!ctx.sizeArtisticText?.(n)){const needed=Math.ceil(content.scrollHeight+padding());if(needed>n.h)n.h=needed;}el.style.width=n.w+'px';el.style.height=n.h+'px';el.style.setProperty('--note-edit-height',n.h+'px');moveRichbar();save()},options);content.addEventListener('click',e=>{const box=e.target.closest?.('[data-check]');if(box){box.textContent=box.textContent==='☐'?'☑':'☐';content.dispatchEvent(new Event('input',{bubbles:true}))}},options);content.addEventListener('blur',e=>{if(richbar.contains(e.relatedTarget))return;setTimeout(()=>{if(activeEditor===content&&!document.querySelector('#textReviewDialog[open]')&&!richbar.contains(document.activeElement)&&document.activeElement!==content)finish()},150)},options);content.addEventListener('keydown',e=>{e.stopPropagation();if(e.key==='Escape'){e.preventDefault();finish()}else if(e.key==='Tab'){e.preventDefault();document.execCommand('insertText',false,'    ')}},options)}

return {cleanRich,startTextEdit,position:placeEditor,finish(){finishActive?.();finishActive=null},get active(){return activeEditor}};
};
