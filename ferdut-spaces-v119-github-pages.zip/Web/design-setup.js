FerdutDesign.setup({state:()=>ferdutLab.getState(),prepare:()=>ferdutLab.prepareUI(),save:design=>ferdutLab.saveUIDesign(design)});
