/* One route and one loading promise per editor. UI mounts only on first use. */
window.FerdutStudios=(()=>{
const $=id=>document.getElementById(id),specs={type:{button:'studioType',label:'Laboratório Tipográfico',api:'FerdutTypography',files:['type-lab-host.js'],css:['type-lab-host.css']},creative:{button:'studioCreative'},resources:{button:'studioResources',label:'Biblioteca de Recursos',api:'FerdutResources',files:['resources.js'],css:['resources.css']},colors:{button:'studioColors',files:['palette-generation.js','palette-lab.js','palette-tools.js','pantone-match.js','palette-workspace.js','palette-tones.js','palette-hsl.js','ui-gradient-model.js','ui-gradients.js'],css:['palette-workspace.css','palette-hsl.css','ui-gradients.css']}},pending=new Map(),scripts=new Map(),styles=new Map(),loaded=new Set(['creative']),activate=new Map(),deactivate=new Map();let active='creative',generation=0;
// Keep view state separate from the shared document and from other projects.
const views=new Map();
const viewKey=(project,mode)=>JSON.stringify([project,mode]);
function remember(mode){
 const api=ferdutProject,s=api.state(),p=s.pages.find(p=>p.id===s.page);
 if(!p||['colors','type'].includes(mode)||!!p.slide!==(mode==='deck'))return;
 views.set(viewKey(s.projectId,mode),{page:p.id,x:s.x,y:s.y,zoom:s.zoom,ids:api.selected().map(n=>n.id)});
}
function restore(mode){
 const api=ferdutProject,s=api.state();
 const saved=views.get(viewKey(s.projectId,mode));
 const eligible=p=>!!p.slide===(mode==='deck');
 const page=s.pages.find(p=>p.id===saved?.page&&eligible(p));
 if(page){if(s.page!==page.id)api.navigate(page.id);api.setViewport(saved);api.selectItems(saved.ids.filter(id=>s.items.some(n=>n.id===id&&n.page===page.id)));api.finishViewport();return}
 if(mode==='creative'&&!s.pages.some(p=>p.id===s.page&&!p.slide)){
  let first=s.pages.find(eligible);if(!first){api.transaction(doc=>{first={id:'strategy-'+crypto.randomUUID(),name:'Estratégia'};doc.pages.push(first)})}api.navigate(first.id);
 }
}

for(const [mode,spec]of Object.entries(specs))if(!$(spec.button)){const b=document.createElement('button');b.id=spec.button;b.type='button';b.className='studio-tab';b.textContent=spec.label;b.setAttribute('aria-pressed','false');$('studioSwitch').append(b)}
function file(src,css=false){const map=css?styles:scripts;if(!map.has(src))map.set(src,new Promise((ok,no)=>{const el=document.createElement(css?'link':'script');if(css){el.rel='stylesheet';el.href=src}else el.src=src;el.onload=ok;el.onerror=()=>{map.delete(src);el.remove();no(Error('Não foi possível carregar '+src))};(css?document.head:document.body).append(el)}));return map.get(src)}
function canonical(){for(const [mode,spec]of Object.entries(specs)){const on=mode===active;$(spec.button).classList.toggle('active',on);$(spec.button).setAttribute('aria-pressed',String(on));document.body.classList.toggle('studio-'+(mode==='type'?'type':mode),on&&mode!=='creative')}for(const [mode,id]of [['deck','deckPanel']])if($(id))$(id).hidden=active!==mode;if($('paletteLab'))$('paletteLab').classList.toggle('open',active==='colors')}
async function ensure(mode){if(!specs[mode])throw Error('Ambiente desconhecido');if(loaded.has(mode))return;if(!pending.has(mode))pending.set(mode,(async()=>{const spec=specs[mode];for(const css of spec.css||[])await file(css,true);if(mode==='colors'&&!$('paletteLab')){const template=$('paletteLabTemplate');if(!template)throw Error('Estrutura do Laboratório de Cores ausente');document.body.append(template.content.cloneNode(true))}for(const src of spec.files||[]){if(mode==='colors'&&!['palette-generation.js','palette-lab.js','palette-workspace.js','palette-tones.js','palette-hsl.js','ui-gradient-model.js','ui-gradients.js'].includes(src)){try{await file(src)}catch(e){console.warn('Recurso opcional de Cores indisponível:',e)}}else await file(src)}if(mode==='colors'){if(!window.FerdutPalette)throw Error('Laboratório de Cores não iniciou; confira os arquivos locais');activate.set(mode,FerdutPalette.open);deactivate.set(mode,FerdutPalette.close)}else{const api=window[spec.api];activate.set(mode,api.open);deactivate.set(mode,api.close);api.open=()=>open(mode);}loaded.add(mode);canonical()})().catch(e=>{pending.delete(mode);throw e}));return pending.get(mode)}
async function open(mode){if(mode==='deck'){ferdutProject.notice('Apresentações está pausado. Seus slides continuam salvos.');mode='creative'}const token=++generation,button=$(specs[mode]?.button);if(!button)throw Error('Ambiente desconhecido');button.setAttribute('aria-busy','true');try{await ensure(mode);if(token!==generation)return;ferdutProject.prepare();const changed=active!==mode;if(changed){remember(active);deactivate.get(active)?.(false)}active=mode;if(changed){if(mode==='colors'&&ferdutProject.state().pages.find(p=>p.id===ferdutProject.state().page)?.slide)restore('creative');activate.get(mode)?.();if(!['colors','type'].includes(mode))restore(mode)}if(!changed&&mode==='creative')restore(mode);canonical();try{localStorage.setItem('ferdut-workspace-mode',mode)}catch{}window.dispatchEvent(new Event('ferdut-workspace-changed'));return window[specs[mode].api]}catch(e){canonical();ferdutProject.notice(e.message);console.error('Falha no ambiente '+mode,e);throw e}finally{button.removeAttribute('aria-busy')}}
$('studioSwitch').addEventListener('click',e=>{const entry=Object.entries(specs).find(([,s])=>e.target.closest('#'+s.button));if(!entry)return;e.preventDefault();e.stopImmediatePropagation();open(entry[0]).catch(()=>{})},true);
window.addEventListener('ferdut-project-loaded',()=>queueMicrotask(canonical));


async function navigate(pageId){
 const api=ferdutProject,project=api.state().projectId,page=api.state().pages.find(p=>p.id===pageId);
 if(!page)return false;
 if(page.slide){api.notice('Este slide está preservado; Apresentações está pausado.');return false}const mode='creative';
 if(active!==mode)await open(mode);
 if(project!==api.state().projectId||active!==mode)return false;
 if(api.state().page!==pageId)api.navigate(pageId);
 return true;
}
async function initial(){let mode='creative',saved=null;try{saved=localStorage.getItem('ferdut-workspace-mode');if(specs[saved])mode=saved}catch{}try{await open(specs[mode]?mode:'creative')}catch{active='creative';canonical()}}
return {open,ensure,navigate,initial,active:()=>active,stats:()=>({loaded:[...loaded],pending:[...pending.keys()].filter(m=>!loaded.has(m)),scripts:scripts.size})};
})();
