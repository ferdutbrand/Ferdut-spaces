importScripts('asset-export.js');
self.onmessage=async event=>{try{const buffer=await FerdutExport.zip(event.data.files).arrayBuffer();self.postMessage({buffer},[buffer])}catch(error){self.postMessage({error:error.message})}};
