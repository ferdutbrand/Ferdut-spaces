window.ferdutReady=(async()=>{
 try {window.ferdutInitialProject=await FerdutStorage.read()} catch(error){console.warn(error);window.ferdutRecoveryWarning=error.message}
 const files=['palette-samples.js','shape-text.js','notes-ui.js','checklist.js','mind-model.js','geometry.js','layout.js','layout-controls.js','sections.js','section-adaptive.js','pages.js','connections.js','manipulation.js','vectors.js','pdf-viewer.js','images.js','links.js','renderer.js','context-controls.js','text-review.js','editor.js','alignment-guides.js','touch-controller.js','file-output.js','save-coordinator.js','app.js','color.js','components.js','accessibility.js','design-system.js','design-setup.js','workbench.js','external-clipboard.js','affinity-transfer.js','project-assets.js','studio-loader.js','quick-actions.js','mind-ui.js','checklist-ui.js','checklist-sidebar.js','gradient-loader.js','asset-export.js','device-shell.js','compact-menus.js','object-interactions.js','identity-icons.js'];
 // Fetch independent files concurrently while retaining their execution order.
 await Promise.all(files.map(file=>new Promise((resolve,reject)=>{
  const script=document.createElement('script');
  script.async=false;script.src=file;script.onload=resolve;script.onerror=reject;
  document.body.appendChild(script);
 })));
 const settings=document.getElementById('settingsMenu');
 for(const id of ['deviceHealth']){
  const button=document.getElementById(id);
  button.setAttribute('role','menuitem');
  button.addEventListener('click',()=>{
   settings.hidden=true;
   for(const key of ['settingsBtn','uiSettingsShortcut'])document.getElementById(key)?.setAttribute('aria-expanded','false');
  });
  settings.append(button);
 }
 for(const id of ['openLayers','openAssets','deviceFit','exportPresentation','openPresentationExport','openQuickCommands'])document.getElementById(id)?.remove();
 await FerdutTypeSystem.installFonts(ferdutProject.state().typeSystem);
 await FerdutStudios.initial();
 if('serviceWorker' in navigator && /^https?:$/.test(location.protocol))FerdutWebUpdates.register();
})().catch(error=>{console.error(error);document.getElementById('toast').textContent='Falha ao iniciar. Recarregue o aplicativo.'});
