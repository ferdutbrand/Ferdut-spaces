/* Workspace navigation and local search over the active project. */
(()=>{
 'use strict';
 const $=id=>document.getElementById(id),dock=$('navDock'),search=$('navSearch'),
  panel=$('navSearchPanel'),input=$('navSearchInput'),type=$('navSearchType'),out=$('navSearchResults');
 document.body.classList.remove('fs-nav-right');dock?.remove();
 function toggle(open){
  panel.hidden=!open;search.setAttribute('aria-expanded',String(open));
  if(open){input.focus();render()}
 }
 search.setAttribute('aria-controls',panel.id);
 search.setAttribute('aria-expanded','false');
 search.onclick=()=>toggle(panel.hidden);
 const normalize=text=>String(text??'').normalize('NFD').replace(/\p{Diacritic}/gu,'').toLocaleLowerCase('pt-BR');
 const assetTypes=new Set(['image','pdf','palette','vector','link']);
 async function locate(page,item){
  const api=window.ferdutProject,state=api.state();
  if(!await FerdutStudios.navigate(page.id))return;
  if(item){
   // A collapsed section can represent an asset until the user expands it.
   let target=item,parent=state.items.find(n=>n.id===item.parent);
   while(parent){if(!parent.expanded)target=parent;parent=state.items.find(n=>n.id===parent.parent)}
   api.selectItems([target.id],true);
   const b=api.bounds(target),canvas=$('canvas').getBoundingClientRect(),nav=$('navigation').getBoundingClientRect();
   const left=document.body.classList.contains('fs-nav-right')?0:Math.max(0,nav.right-canvas.left);
   const right=document.body.classList.contains('fs-nav-right')?Math.min(canvas.width,nav.left-canvas.left):canvas.width;
   api.setViewport({zoom:state.zoom,x:(left+right)/2-(b.x+b.w/2)*state.zoom,y:canvas.height/2-(b.y+b.h/2)*state.zoom});
   api.finishViewport();
  }
  toggle(false);search.focus();
 }
 function render(){
  const query=normalize(input.value.trim()),state=window.ferdutProject?.state?.();
  if(!state){out.textContent='Projeto ainda não carregado';return}
  const matches=(...fields)=>fields.some(value=>normalize(value).includes(query));
  const byId=new Map(state.pages.map(p=>[p.id,p]));
  const rows=[];
  if(['all','page'].includes(type.value)){
   for(const p of state.pages.filter(p=>matches(p.name)).slice(0,25))rows.push({page:p,label:'▤ '+p.name});
  }
  if(type.value!=='page'){
   for(const n of state.items.filter(n=>assetTypes.has(n.type)&&(type.value==='all'||n.type===type.value)&&matches(n.text,n.name,n.pdfName,n.url,n.type)).slice(0,25)){
    const page=byId.get(n.page);if(page)rows.push({page,item:n,label:'◇ '+(n.text||n.name||n.pdfName||n.type)});
   }
  }
  out.replaceChildren();
  for(const row of rows){
   const li=document.createElement('div'),button=document.createElement('button');
   li.setAttribute('role','listitem');button.type='button';button.textContent=row.label;
   button.onclick=()=>locate(row.page,row.item).catch(error=>ferdutProject.notice(error.message));
   li.append(button);out.append(li);
  }
  if(!rows.length)out.textContent='Nenhum resultado';
 }
 input.addEventListener('input',render);type.addEventListener('change',render);
 panel.addEventListener('keydown',e=>{if(e.key==='Escape'){e.stopPropagation();toggle(false);search.focus()}if(e.target===input&&e.key==='Enter'){e.preventDefault();out.querySelector('button')?.click()}});
 window.addEventListener('ferdut-project-loaded',()=>{if(!panel.hidden)render()});
})();
