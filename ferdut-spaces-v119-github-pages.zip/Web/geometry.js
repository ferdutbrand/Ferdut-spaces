window.FerdutGeometry=(()=>{
function scaledBounds(box,side,dx,dy){let x=box.x,y=box.y,right=x+box.w,bottom=y+box.h;if(side.includes('w'))x=Math.min(right-12,x+dx);if(side.includes('e'))right=Math.max(x+12,right+dx);if(side.includes('n'))y=Math.min(bottom-12,y+dy);if(side.includes('s'))bottom=Math.max(y+12,bottom+dy);return{x,y,w:right-x,h:bottom-y}}

function modifierBounds(box,side,dx,dy,shift=false,alt=false){
 let b=scaledBounds(box,side,dx,dy);
 const cx=box.x+box.w/2,cy=box.y+box.h/2;
 if(alt){
  const widthDelta=b.w-box.w,heightDelta=b.h-box.h;
  b.w=Math.max(12,box.w+widthDelta*2);b.h=Math.max(12,box.h+heightDelta*2);
  b.x=cx-b.w/2;b.y=cy-b.h/2;
 }
 if(shift){
  const ratio=box.w/Math.max(1,box.h);
  if(side==='n'||side==='s'){b.w=Math.max(12,b.h*ratio);b.x=alt?cx-b.w/2:box.x+(box.w-b.w)/2}
  else if(side==='e'||side==='w'){b.h=Math.max(12,b.w/ratio);b.y=alt?cy-b.h/2:box.y+(box.h-b.h)/2}
  else {const scale=Math.max(b.w/box.w,b.h/box.h);b.w=Math.max(12,box.w*scale);b.h=Math.max(12,box.h*scale);b.x=alt?cx-b.w/2:side.includes('w')?box.x+box.w-b.w:box.x;b.y=alt?cy-b.h/2:side.includes('n')?box.y+box.h-b.h:box.y}
 }
 return b;
}

return Object.freeze({scaledBounds,modifierBounds});})();
