/* Project boundary: additive migration, validation before replacing live state. */
window.FerdutDocument = Object.freeze({
  normalize(data, defaults) {
    if (!data || !Array.isArray(data.items) || !Array.isArray(data.pages) || !data.pages.length)
      throw Error('Projeto sem páginas ou objetos válidos');
    const visiting=new WeakSet();function inspect(value){if(!value||typeof value!=='object')return;if(visiting.has(value))throw Error('Estrutura circular inválida no projeto');if(Object.keys(value).length===1&&typeof value.__ferdutAsset==='string')throw Error('Referências internas não são um projeto .entre; use a restauração de backup');visiting.add(value);for(const child of Object.values(value))inspect(child);visiting.delete(value)}inspect(data);
    const safeId=id=>typeof id==='string'&&id.length>0&&id.length<=512&&!/[<>"'&\u0000-\u001f]/.test(id);
    if(data.typography)data.typography=FerdutType.normalize(data.typography);if(data.iconLibrary)data.iconLibrary=FerdutIcons.normalize(data.iconLibrary);if(data.fontAssets){if(!Array.isArray(data.fontAssets)||data.fontAssets.length>8)throw Error('Biblioteca de fontes inválida');const fontIds=new Set();for(const f of data.fontAssets){if(!f||typeof f.id!=='string'||!/^[a-f0-9]{64}$/.test(f.id)||fontIds.has(f.id)||f.family!=='FerdutFont_'+f.id||typeof f.name!=='string'||f.name.length>200||typeof f.source!=='string'||f.source.length>6e6||!/^data:font\/otf;base64,[A-Za-z0-9+/=]+$/.test(f.source))throw Error('Fonte publicada inválida');fontIds.add(f.id)}}
    for(const n of data.items)if(n.textMode!==undefined&&(n.type!=='text'||!['artistic','frame'].includes(n.textMode)))throw Error('Modo de texto inválido');
    for(const n of data.items)if(n.stickyNote!==undefined&&(n.type!=='note'||typeof n.stickyNote!=='boolean'))throw Error('Configuração de nota adesiva inválida');
    for(const n of data.items)if(n.paletteOrigin!=null){const o=n.paletteOrigin;if(n.type!=='palette'||o.collection!=='sanzo-wada-v1'||!Number.isInteger(o.combination)||o.combination<1||o.combination>348||!Array.isArray(o.colors)||o.colors.length<2||o.colors.length>4||o.colors.some(c=>typeof c!=='string'||!/^#[0-9a-f]{6}$/i.test(c))||typeof o.modified!=='boolean')throw Error('Referência de paleta inválida')}FerdutPresentationModel.validate(data);for(const n of data.items)if(n.gradient){if(!['shape','vector'].includes(n.type))throw Error('Gradiente exige forma ou vetor');FerdutGradients.validate(n.gradient)}
    for(const n of data.items){if(n.annotation!==undefined&&(n.type!=='stroke'||typeof n.annotation!=='boolean'))throw Error('Anotação inválida');if(n.type==='stroke'&&n.opacity!==undefined&&(!Number.isFinite(n.opacity)||n.opacity<.1||n.opacity>1))throw Error('Opacidade de traço inválida')}
    if(data.typeSystem!==undefined)data.typeSystem=FerdutTypeSystem.normalize(data.typeSystem);
    if(data.uiGradientDraft!==undefined)FerdutGradients.validatePreset(data.uiGradientDraft);
    if(data.uiGradients!==undefined){if(!Array.isArray(data.uiGradients)||data.uiGradients.length>100)throw Error('Biblioteca de gradientes inválida');const seen=new Set();for(const row of data.uiGradients){if(!safeId(row.id)||seen.has(row.id))throw Error('Gradiente salvo inválido ou repetido');seen.add(row.id);FerdutGradients.validatePreset(row)}}
    function toneConfigs(rows){if(!Array.isArray(rows)||rows.length>12)throw Error('Tonalidades da paleta inválidas');for(const row of rows)FerdutColorTones.validate(row||{})}
    for(const n of data.items){if(n.paletteLayout!==undefined&&(n.type!=='palette'||!['specimen','ui-scale'].includes(n.paletteLayout)))throw Error('Visualização de paleta inválida');if(n.paletteTones!==undefined){if(n.type!=='palette')throw Error('Tonalidades exigem paleta');toneConfigs(n.paletteTones)}}
    if(data.colorLab?.toneConfigs!==undefined)toneConfigs(data.colorLab.toneConfigs);
    const ids = new Set(), pages = new Set();
    for (const p of data.pages) {
      if (!p || !safeId(p.id) || pages.has(p.id)) throw Error('Página inválida ou repetida');
      pages.add(p.id);
      if(p.slide){if(typeof p.slide!=='object'||p.slide.width!==1920||p.slide.height!==1080||!/^#[0-9a-f]{6}$/i.test(p.slide.background)||typeof p.slide.notes!=='string'||p.slide.notes.length>20000)throw Error('Slide 16:9 inválido');p.slide={width:1920,height:1080,background:p.slide.background,notes:p.slide.notes,...(p.slide.sectionId!=null?{sectionId:p.slide.sectionId}:{}),...(p.slide.parentId!=null?{parentId:p.slide.parentId}:{}),...(p.slide.collapsed!==undefined?{collapsed:p.slide.collapsed}:{}),...(p.slide.skipped!==undefined?{skipped:p.slide.skipped}:{}),...(p.slide.layoutGuides?{layoutGuides:structuredClone(p.slide.layoutGuides)}:{})};}
    }
    FerdutSlideOutline.validate(data,safeId);
    const items = data.items.map(n => {
      if (!n || !safeId(n.id) || ids.has(n.id) || !pages.has(n.page)) throw Error('Objeto inválido, repetido ou sem página');
      ids.add(n.id);
      return {...n, x:Number.isFinite(n.x)?n.x:0, y:Number.isFinite(n.y)?n.y:0,
        w:Math.max(12,Number.isFinite(Number(n.w))?(Number(n.w)||220):220), h:Math.max(12,Number.isFinite(Number(n.h))?(Number(n.h)||120):120)};
    });
    FerdutMind.validate(items);FerdutChecklist.validate(items);
    const index = new Map(items.map(n=>[n.id,n]));
    if(data.pages.filter(p=>p.slide).length>200)throw Error('Limite de 200 slides por projeto');
    for(const n of items)if(n.slideSource&&(!safeId(n.slideSource)||n.slideSource===n.id))throw Error('Origem vinculada inválida');
    for (const n of items) {
      const seen = new Set([n.id]); let p=n.parent;
      while(p) { if(seen.has(p)) throw Error('Ciclo entre seções'); seen.add(p); const parent=index.get(p);
        if(!parent || parent.type!=='folder' || parent.page!==n.page) {n.parent=null;break;} p=parent.parent;
      }
    }
    return {...defaults,...data, interactionPolicy:'static-neighbors-v1',viewSnapping:data.interactionPolicy==='static-neighbors-v1'?data.viewSnapping!==false:true, projectId:typeof data.projectId==='string'&&data.projectId?data.projectId:defaults.projectId,version:4, items,
      links:(Array.isArray(data.links)?data.links:[]).filter(l=>l&&ids.has(l.from)&&ids.has(l.to)),
      page:pages.has(data.page)?data.page:data.pages[0].id,
      zoom:Math.min(4,Math.max(.15,Number(data.zoom)||1)),
      x:Number.isFinite(data.x)?data.x:defaults.x,y:Number.isFinite(data.y)?data.y:defaults.y,
      timer:{...defaults.timer,...data.timer,running:false}};
  }
});
