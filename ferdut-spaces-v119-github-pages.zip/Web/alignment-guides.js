/* Alignment and spacing candidates use world coordinates. Tolerances come from the viewport. */
window.FerdutSnap=(()=>{
 const axes={x:['x','w','w','e'],y:['y','h','n','s']};
 function nearby(box,targets,zoom){
  const distance=160/zoom;
  const left=box.x-distance,right=box.x+box.w+distance;
  const top=box.y-distance,bottom=box.y+box.h+distance;
  return targets.filter(b=>b.slideGuide||(b.x<=right&&b.x+b.w>=left&&b.y<=bottom&&b.y+b.h>=top));
 }
 function snap(box,targets,tolerance,{side,spacing=false,grid=null}={}){
  const result={x:null,y:null};
  for(const [axis,[start,size,low,high]] of Object.entries(axes)){
   const positions=b=>[b[start],b[start]+b[size]/2,b[start]+b[size]];
   const points=positions(box);
   const moving=side?(side.includes(low)?[points[0]]:side.includes(high)?[points[2]]:[]):points;
   function consider(delta,at,segments){
    const best=result[axis];
    if(Math.abs(delta)<=tolerance&&(!best||Math.abs(delta)<Math.abs(best.delta)))result[axis]={delta,at,segments};
   }
   let before=null,after=null;
   const other=axis==='x'?'y':'x',otherSize=axes[other][1];
   for(const b of targets){
    for(const v of positions(b))for(const a of moving)consider(v-a,v);
    if(!spacing||b[other]>box[other]+box[otherSize]||b[other]+b[otherSize]<box[other])continue;
    const end=b[start]+b[size];
    if(end<=points[0]&&(!before||end>before[start]+before[size]))before=b;
    if(b[start]>=points[2]&&(!after||b[start]<after[start]))after=b;
   }
   if(before&&after){
    const from=before[start]+before[size],to=after[start],gap=(to-from-box[size])/2;
    const a=from+gap,b=a+box[size];
    if(gap>0)consider(a-points[0],a,[[from,a],[b,to]]);
    if(result[axis]?.segments)result[axis].cross=box[other]+box[otherSize]/2;
   }
  }
  if(grid&&grid.size>0)for(const [axis,[start,size,low,high]]of Object.entries(axes)){if(result[axis])continue;const point=side?(side.includes(low)?box[start]:side.includes(high)?box[start]+box[size]:null):box[start];if(point===null)continue;const origin=axis==='x'?grid.x||0:grid.y||0,at=origin+Math.round((point-origin)/grid.size)*grid.size,delta=at-point;if(Math.abs(delta)<=tolerance)result[axis]={delta,at}}
  return result;
 }
 function clear(){document.getElementById('alignmentGuides')?.remove()}
 function show(result,state,canvas){
  let el=document.getElementById('alignmentGuides');
  if(!result.x&&!result.y){if(el)el.hidden=true;return}
  if(!el){
   el=document.createElement('div');el.id='alignmentGuides';
   for(const axis of ['x','y'])for(let i=0;i<2;i++){
    const line=document.createElement('div');line.className='alignment-guide';
    line.dataset.axis=axis;line.dataset.segment=i;line.style.position='absolute';el.append(line);
   }
   document.getElementById('world').append(el);
  }
  el.hidden=false;
  const left=-state.x/state.zoom,top=-state.y/state.zoom,w=canvas.clientWidth/state.zoom,h=canvas.clientHeight/state.zoom,thin=1/state.zoom;
  for(const line of el.children){
   const {axis,segment}=line.dataset,row=result[axis],horizontal=axis==='x';
   line.hidden=!row||(!row.segments&&segment==='1');
   if(line.hidden)continue;
   if(row.segments){
    const [from,to]=row.segments[segment];
    Object.assign(line.style,{left:(horizontal?from:row.cross)+'px',top:(horizontal?row.cross:from)+'px',width:(horizontal?to-from:thin)+'px',height:(horizontal?thin:to-from)+'px'});
   }else Object.assign(line.style,{left:(horizontal?row.at:left)+'px',top:(horizontal?top:row.at)+'px',width:(horizontal?thin:w)+'px',height:(horizontal?h:thin)+'px'});
  }
 }
 return {snap,nearby,clear,show};
})();
