/* Sanitized inline vectors; Paper is loaded only for path operations. */
window.FerdutVectors=(()=>{
 const NS='http://www.w3.org/2000/svg',tags=new Set('svg g defs path rect circle ellipse polygon polyline line linearGradient radialGradient pattern stop clipPath mask title desc text tspan'.split(' '));
 const attrs=new Set('id viewBox width height x y x1 y1 x2 y2 cx cy r rx ry fx fy fr d points transform fill fill-opacity fill-rule stroke stroke-width stroke-opacity stroke-linecap stroke-linejoin stroke-miterlimit opacity clip-path clip-rule mask vector-effect patternUnits patternContentUnits gradientUnits gradientTransform spreadMethod offset stop-color stop-opacity font-family font-size font-weight text-anchor dominant-baseline preserveAspectRatio href'.split(' '));
 function clean(source){
  if(typeof source!=='string'||source.length>4e6||/<!DOCTYPE|<!ENTITY/i.test(source))throw Error('SVG inválido ou maior que 4 MB');
  const doc=new DOMParser().parseFromString(source,'image/svg+xml'),root=doc.documentElement;
  if(root.localName!=='svg'||doc.querySelector('parsererror'))throw Error('SVG inválido');
  if(root.querySelectorAll('*').length>10000)throw Error('SVG com excesso de elementos');
  for(const el of [root,...root.querySelectorAll('*')]){
   if(!tags.has(el.localName)){el.remove();continue}
   const style=el.getAttribute('style');if(style){const probe=document.createElement('span');probe.style.cssText=style;for(const key of Array.from(probe.style))if(attrs.has(key))el.setAttribute(key,probe.style.getPropertyValue(key))}
   for(const a of [...el.attributes])if(!attrs.has(a.localName)||/javascript:|data:|https?:|\/\//i.test(a.value)||(/url\s*\(/i.test(a.value)&&!/^url\(\s*["']?#[\w:.-]+["']?\s*\)$/.test(a.value))||(a.localName==='href'&&!/^#[\w:.-]+$/.test(a.value)))el.removeAttributeNode(a);
  }
  let vb=(root.getAttribute('viewBox')||'').trim().split(/[ ,]+/).map(Number);if(vb.length!==4||!vb.every(Number.isFinite)||vb[2]<=0||vb[3]<=0)vb=[0,0,parseFloat(root.getAttribute('width'))||100,parseFloat(root.getAttribute('height'))||100];
  root.setAttribute('viewBox',vb.join(' '));root.setAttribute('xmlns',NS);root.removeAttribute('width');root.removeAttribute('height');
  const normalized=doc.implementation.createDocument(NS,'svg',null);function copy(source,target){for(const a of source.attributes)if(a.localName!=='xmlns')target.setAttribute(a.localName,a.value);for(const child of source.childNodes)if(child.nodeType===1){const next=normalized.createElementNS(NS,child.localName);copy(child,next);target.append(next)}else if(child.nodeType===3||child.nodeType===4)target.append(normalized.createTextNode(child.textContent))}copy(root,normalized.documentElement);return {svg:new XMLSerializer().serializeToString(normalized.documentElement),viewBox:vb};
 }
 const cached=new Map();
 function markup(n,purpose='preview'){const key=purpose+'|'+FerdutImages.signature({svg:n.svg,id:n.id,fill:n.fill,strokeColor:n.strokeColor,strokeWidth:n.strokeWidth,gradient:n.gradient});if(cached.has(key))return cached.get(key);let safe;try{safe=clean(n.svg)}catch{return '<span>SVG não suportado</span>'}
  const root=new DOMParser().parseFromString(safe.svg,'image/svg+xml').documentElement,prefix='vec-'+String(n.id).replace(/[^\w-]/g,'')+'-',ids=new Map();
  for(const el of root.querySelectorAll('[id]')){const id=el.id;ids.set(id,prefix+id);el.id=prefix+id}
  for(const el of [root,...root.querySelectorAll('*')])for(const a of [...el.attributes]){let v=a.value;v=v.replace(/url\(\s*["']?#([\w:.-]+)["']?\s*\)/g,(_,id)=>`url(#${ids.get(id)||prefix+id})`);if(a.localName==='href'&&v.startsWith('#'))v='#'+(ids.get(v.slice(1))||prefix+v.slice(1));el.setAttribute(a.name,v)}
  for(const el of root.querySelectorAll('path,rect,circle,ellipse,polygon,polyline,line,text,tspan')){if(n.fill!==undefined)el.setAttribute('fill',n.fill);if(n.strokeColor!==undefined)el.setAttribute('stroke',n.strokeColor);if(n.strokeWidth!==undefined)el.setAttribute('stroke-width',String(n.strokeWidth))}
  root.setAttribute('width','100%');root.setAttribute('height','100%');root.setAttribute('preserveAspectRatio','none');let result=new XMLSerializer().serializeToString(root);if(n.gradient)result=FerdutGradients.vectorSVG(result,n,safe.viewBox,purpose);if(cached.size>32)cached.clear();cached.set(key,result);return result;
 }
 const load=()=>FerdutRuntime.load('paper');
 async function boolean(items,op,shapePath){
  if(!['unite','subtract','intersect','exclude'].includes(op)||items.length<2||items.length>32)throw Error('Selecione de 2 a 32 vetores ou formas');
  await load();const scope=new paper.PaperScope();scope.setup(document.createElement('canvas'));
  try{
   const paths=items.map(n=>{
    if(!['shape','vector'].includes(n.type)||n.imageSrc)throw Error('Use apenas formas sem imagem ou SVGs geométricos');
    const safe=n.type==='vector'?clean(n.svg):{svg:`<svg xmlns="${NS}" viewBox="0 0 100 100"><path d="${shapePath(n.shape||'rect')}"/></svg>`,viewBox:[0,0,100,100]};
    if(/<(text|tspan|mask|clipPath)\b/.test(safe.svg))throw Error('Converta textos e máscaras em caminhos antes da operação');
    const imported=scope.project.importSVG(safe.svg,{insert:false,expandShapes:true});const leaves=[];function walk(p){if(p instanceof scope.Path||p instanceof scope.CompoundPath){leaves.push(p.clone({insert:false}));return}for(const c of p.children||[])walk(c)}walk(imported);if(!leaves.length)throw Error('SVG sem caminhos geométricos');
    let path=leaves.shift();for(const q of leaves)path=path.unite(q,{insert:false});
    const [vx,vy,vw,vh]=safe.viewBox;path.transform(new scope.Matrix(n.w/vw,0,0,n.h/vh,n.x-vx*n.w/vw,n.y-vy*n.h/vh));path.rotate(Number(n.rotation)||0,new scope.Point(n.x+n.w/2,n.y+n.h/2));return path;
   });let result=paths.shift();for(const path of paths)result=result[op](path,{insert:false});const b=result.bounds;if(result.isEmpty()||b.width<.01||b.height<.01)throw Error('A operação resulta em uma área vazia');
   const svg=`<svg xmlns="${NS}" viewBox="${b.x} ${b.y} ${b.width} ${b.height}"><path fill-rule="evenodd" d="${result.pathData}"/></svg>`;
   return {svg:clean(svg).svg,x:b.x,y:b.y,w:b.width,h:b.height,rotation:0,fill:items[0].fill||'#B4B6E8',strokeColor:items[0].strokeColor||'#1B1522',strokeWidth:items[0].strokeWidth??0,...(items[0].gradient?{gradient:structuredClone(items[0].gradient)}:{})};
  }finally{scope.project.remove();scope.remove()}
 }
 return {clean,markup,boolean};
})();
