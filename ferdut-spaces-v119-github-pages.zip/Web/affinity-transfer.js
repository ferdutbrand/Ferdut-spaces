/* Mixed SVG interchange retains original embedded image bytes and separate vector nodes. */
window.FerdutAffinityTransfer=(()=>{
 'use strict';
 const api=window.ferdutProject;
 const supported=n=>['vector','stroke','palette','note','text'].includes(n.type)||
  n.type==='shape'&&!n.imageSrc&&(!(n.label||n.labelHtml)||!n.gradient)||
  n.type==='image'&&/^data:image\/(png|jpeg|webp|gif);base64,/i.test(n.src||'');
 async function compose(scene){
  const items=scene.items.filter(supported);
  if(!items.length)throw Error('Selecione imagens incorporadas ou vetores sem máscara de imagem.');
  const ids=new Set(items.map(n=>n.id));
  const links=scene.links.filter(l=>ids.has(l.from)&&ids.has(l.to));
  const bounds=FerdutLayout.union(items.map(n=>FerdutLayout.rotatedBounds(api.bounds(n),n.rotation||0)));
  const pad=Math.max(0,...items.map(n=>Math.min(1000,Number(n.strokeWidth??n.width)||0)/2));
  const region={x:bounds.x-pad,y:bounds.y-pad,w:bounds.w+2*pad,h:bounds.h+2*pad};
  const page={id:'selection'};
  if(!window.FerdutSceneExport)await new Promise((ok,no)=>{const script=document.createElement('script');script.src='scene-export.js';script.onload=ok;script.onerror=()=>no(Error('Motor SVG indisponível'));document.body.append(script)});
  const exporter=FerdutSceneExport;
  const result=await exporter.svgPage(page,{items:items.map(n=>({...n,page:page.id})),links},region);
  return {svg:result.svg,width:region.w,height:region.h,count:items.length,skipped:scene.items.length-items.length};
 }
 async function exportSelection(){
  try{
   const result=await compose(api.exportItems('selection'));
   FerdutFiles.download(new Blob([result.svg],{type:'image/svg+xml;charset=utf-8'}),'Ferdut-referencias.svg');
   api.notice(`${result.count} objeto(s) exportado(s) em SVG.${result.skipped?' Itens incompatíveis foram omitidos.':''}`);
   return true;
  }catch(error){api.notice(error.message);return false}
 }
 document.addEventListener('keydown',e=>{
  if(!(e.metaKey||e.ctrlKey)||!e.shiftKey||e.altKey||e.key.toLowerCase()!=='e'||e.repeat)return;
  if(document.activeElement?.isContentEditable||document.activeElement?.closest('input,textarea,select,dialog[open]'))return;
  e.preventDefault();exportSelection();
 },true);
 return {compose,canCompose:scene=>!!scene.items.length&&scene.items.every(supported),exportSelection};
})();
