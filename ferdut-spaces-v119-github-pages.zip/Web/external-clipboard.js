/* Vector-first external clipboard; structured objects remain internal. */
window.FerdutExternalClipboard = (() => {
  'use strict';
  let busy = false;
  let lastPNG = null;
  let lastVector = null;
  async function fingerprint(blob) {
    const bitmap = await createImageBitmap(blob);
    const canvas = document.createElement('canvas');
    canvas.width = canvas.height = 48;
    try {
      const ctx = canvas.getContext('2d', {willReadFrequently:true});
      ctx.drawImage(bitmap, 0, 0, 48, 48);
      const bytes = ctx.getImageData(0, 0, 48, 48).data;
      const digest = await crypto.subtle.digest('SHA-256', bytes);
      return bitmap.width + 'x' + bitmap.height + ':' + Array.from(new Uint8Array(digest)).join(',');
    } finally { bitmap.close();canvas.width = canvas.height = 1; }
  }
  async function matchesPNG(file) {
    const previous = lastPNG;
    if (!previous || previous.token!==api.clipboardToken() || file?.type !== 'image/png') return false;
    try {
      const [saved,current] = await Promise.all([previous.signature, fingerprint(file)]);
      return previous === lastPNG && previous.token===api.clipboardToken() && saved !== null && saved === current;
    } catch { return false; }
  }
  const api = window.ferdutProject;
  const excluded = () => document.body.classList.contains('studio-colors') ||
    document.activeElement?.isContentEditable ||
    ['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement?.tagName) ||
    !!document.activeElement?.closest('dialog[open], .pdf-reading .textLayer');
  const active = () => ['creative','deck'].includes(window.FerdutStudios?.active?.() || 'creative');
  const png = async scene => {
    const result = await FerdutPresentation.render('selection', {
      scene, background: 'transparent', scale: 2, format: 'png'
    });
    try {
      return await new Promise((resolve, reject) =>
        result.canvas.toBlob(blob => blob ? resolve(blob) : reject(new Error('Não foi possível criar a imagem')), 'image/png'));
    } finally { result.canvas.width = result.canvas.height = 1; }
  };
  let recovery,prepared=null;
  function showRecovery(value,canWrite){
    prepared=value;
    if(!recovery){
      recovery=document.createElement('dialog');recovery.setAttribute('aria-label','Recuperar cópia');
      recovery.innerHTML='<p>A cópia para outro aplicativo não foi concluída.</p><button type="button" data-copy-retry>Tentar novamente</button> <button type="button" data-copy-download>Salvar arquivo</button> <button type="button" data-copy-close>Fechar</button>';
      recovery.querySelector('[data-copy-retry]').onclick=()=>{void copy({retry:true})};
      recovery.querySelector('[data-copy-download]').onclick=()=>{if(prepared)FerdutFiles.download(prepared.svg?new Blob([prepared.svg],{type:'image/svg+xml'}):prepared.blob,prepared.svg?'Ferdut-selecao.svg':'Ferdut-selecao.png')};
      recovery.querySelector('[data-copy-close]').onclick=()=>recovery.close();document.body.append(recovery);
    }
    recovery.querySelector('[data-copy-retry]').hidden=!canWrite;if(!recovery.open)recovery.showModal();
  }
  async function copy({retry=false}={}){
    if(busy)return false;
    const native=window.webkit?.messageHandlers?.ferdutClipboard,canWrite=!!native||!!(navigator.clipboard?.write&&window.ClipboardItem);
    if(retry&&prepared?.token!==api.clipboardToken())prepared=null;
    const ready=retry?prepared:null,scene=ready?null:api.exportItems('selection');
    if(!ready&&!scene.items.length){api.notice('Selecione os elementos que deseja copiar.');return false}
    if(!ready){prepared=null;lastPNG=null;lastVector=null;api.copySelectionInternal()}
    const token=api.clipboardToken();busy=true;
    const vector=ready?.svg?Promise.resolve(ready):!ready&&window.FerdutAffinityTransfer?.canCompose(scene)?FerdutAffinityTransfer.compose(scene):null;
    // Vector copy never publishes a PNG. Receivers must not silently prefer a bitmap.
    const image=vector?null:ready?.blob?Promise.resolve(ready.blob):png(scene);
    let value;
    try{
      if(!canWrite)throw Error('Área de transferência indisponível');
      if(native){
        if(vector){value={token,...await vector};await native.postMessage({svg:value.svg,width:value.width,height:value.height})}
        else{value={token,blob:await image};const data=await new Promise((ok,no)=>{const reader=new FileReader();reader.onload=()=>ok(reader.result.split(',')[1]);reader.onerror=no;reader.readAsDataURL(value.blob)});await native.postMessage({png:data})}
      }else{
        const formats={};
        if(vector){const content=vector.then(result=>result.svg);void content.catch(()=>{});formats['text/plain']=content.then(text=>new Blob([text],{type:'text/plain'}));const type=['image/svg+xml','web image/svg+xml'].find(t=>ClipboardItem.supports?.(t));if(type)formats[type]=content.then(text=>new Blob([text],{type:'image/svg+xml'}))}
        else formats['image/png']=ready?.blob||image;
        await navigator.clipboard.write([new ClipboardItem(formats)]);
        value=vector?{token,...await vector}:{token,blob:await image};
      }
      if(vector)lastVector={token,svg:value.svg};else lastPNG={token,signature:Promise.resolve(value.blob).then(fingerprint).catch(()=>null)};
      prepared=null;if(recovery?.open)recovery.close();api.notice(vector?'Seleção copiada como vetor.':'Seleção copiada como imagem.');return true;
    }catch(error){try{value=value||(vector?{token,...await vector}:{token,blob:await image});showRecovery(value,canWrite)}catch{api.notice('Não foi possível preparar a cópia externa. A cópia interna continua disponível.')}return false}
    finally{busy=false}
  }
  document.addEventListener('keydown', event => {
    if (!active() || excluded() || event.repeat || event.altKey || event.shiftKey ||
      !(event.metaKey || event.ctrlKey) || event.key.toLowerCase() !== 'c' ||
      !api.selected().length) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    void copy();
  }, true);
  return {copy,matchesPNG,matchesSVG:text=>!!lastVector&&lastVector.token===api.clipboardToken()&&text===lastVector.svg, get busy() {return busy;}};
})();
