/* Share identical in-flight saves. Distinct generations, projects and views still
   reach storage, whose write() captures synchronously before the next edit. */
window.FerdutSaveCoordinator=({write,settled})=>{
 const pending=new Map();
 const key=(state,generation)=>JSON.stringify([state.projectId,generation,state.x,state.y,state.zoom,state.view]);
 function flush(state,generation){
  const project=state.projectId,token=key(state,generation);
  if(pending.has(token))return pending.get(token);
  let result;try{result=write(state)}catch(error){result=Promise.reject(error)}
  const job=Promise.resolve(result).then(value=>{settled({project,generation,key:token,result:value});return true},error=>{if(!error?.message)error=Error(typeof error==='string'&&error?error:'Falha de gravação');settled({project,generation,key:token,error});return false}).finally(()=>pending.delete(token));
  pending.set(token,job);return job;
 }
 return{flush,key,pending:()=>pending.size};
};
