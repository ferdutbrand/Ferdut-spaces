/* Sticky-note limits apply only to newly created notes; legacy geometry is preserved. */
window.FerdutNotes=(()=>{
 const side=240;
 function minimum(n){return n.type==='note'&&n.stickyNote?{w:side,h:side}:{w:12,h:n.type==='text'?(n.textMode==='artistic'?12:36):56}}
 function constrain(n,box,source,edge,center=false){if(!n.stickyNote||n.type!=='note')return box;const min=minimum(n),b={...box};if(b.w<min.w){b.w=min.w;b.x=center?source.x+(source.w-min.w)/2:edge?.includes('w')?source.x+source.w-min.w:source.x}if(b.h<min.h){b.h=min.h;b.y=center?source.y+(source.h-min.h)/2:edge?.includes('n')?source.y+source.h-min.h:source.y}return b}
 return {side,minimum,constrain};
})();
