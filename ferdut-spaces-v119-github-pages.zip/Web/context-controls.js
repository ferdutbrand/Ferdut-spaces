/* Screen-space placement shared by selection, appearance and rich-text bars. */
window.FerdutFloating=Object.freeze({
 place(elements,target){
  const bars=elements.filter(el=>el&&getComputedStyle(el).display!=='none');if(!bars.length)return;
  const gap=8,edge=12,minY=Math.max(document.querySelector('header')?.getBoundingClientRect().bottom||54,document.body.classList.contains('device-compact')?document.getElementById('deviceBar')?.getBoundingClientRect().bottom||0:0)+12,width=Math.max(...bars.map(el=>el.offsetWidth)),height=bars.reduce((h,el)=>h+el.offsetHeight,0)+gap*(bars.length-1),right=target.right??target.x+target.width,bottom=target.bottom??target.y+target.height,left=target.left??target.x,top=target.top??target.y;
  const clampX=x=>Math.max(edge,Math.min(innerWidth-width-edge,x)),clampY=y=>Math.max(minY,Math.min(innerHeight-height-edge,y)),center=clampX((left+right-width)/2);
  const obstacles=['#toolbar','#navigation','#contextDock','.zoom','#deckPanel','#deckInspector','#deckContextMenus'].map(s=>document.querySelector(s)).filter(el=>el&&getComputedStyle(el).display!=='none').map(el=>el.getBoundingClientRect());
  const hits=(a,b)=>a.x<b.right&&a.x+width>b.left&&a.y<b.bottom&&a.y+height>b.top;
  const candidates=[{x:center,y:top-height-16,side:'above'},{x:center,y:bottom+(target.clearance||56),side:'below'},{x:right+20,y:clampY(top),side:'right'},{x:left-width-20,y:clampY(top),side:'left'}];
  const fit=c=>c.x>=edge&&c.x+width<=innerWidth-edge&&c.y>=minY&&c.y+height<=innerHeight-edge&&!obstacles.some(o=>hits(c,o));
  let chosen=candidates.find(fit);if(!chosen)chosen={x:clampX(Math.max(220,center)),y:Math.max(128,minY),side:'docked'};
  let y=chosen.y;for(const el of bars){el.style.left=Math.max(edge,chosen.x+(width-el.offsetWidth)/2)+'px';el.style.top=y+'px';el.style.bottom='auto';el.style.transform='none';el.dataset.placement=chosen.side;y+=el.offsetHeight+gap}
 }
});
window.FerdutContextControls=ctx=>{
 const el=document.createElement('div');el.id='stylebar';el.setAttribute('role','toolbar');el.setAttribute('aria-label','Propriedades de aparência');el.innerHTML='<div id="noteColors"></div>'+[['fill','Preenchimento','color'],['textColor','Texto','color'],['strokeColor','Contorno','color'],['strokeWidth','Espessura','number']].map(([key,label,type])=>`<label data-style-field="${key}">${label}<input type="${type}" data-style="${key}" aria-label="${label}" ${type==='number'?'min="0" max="40" step="1"':''}></label>`).join('');document.body.append(el);
 const notes=n=>['note','text'].includes(n.type),properties=n=>n.type==='text'?['textColor']:notes(n)?['fill','textColor']:['shape','vector'].includes(n.type)?['fill','strokeColor','strokeWidth']:n.type==='stroke'?['strokeColor','strokeWidth']:[];
 const key=(n,prop)=>notes(n)&&prop==='fill'?'textBg':n.type==='stroke'?(prop==='strokeColor'?'color':prop==='strokeWidth'?'width':prop):prop;
 const value=(n,prop)=>n[key(n,prop)]??(prop==='fill'?(notes(n)?'#ffffff':'#B4B6E8'):prop==='strokeWidth'?(n.type==='stroke'?3:2):prop==='strokeColor'?(n.color||'#1B1522'):'#1B1522');
 const selection=()=>ctx.selected().map(ctx.get).filter(Boolean);
 function apply(prop,v){const list=selection();if(!list.length||!list.every(n=>properties(n).includes(prop)))return;const next=prop==='strokeWidth'?Math.max(list.some(n=>n.type==='stroke')?1:0,Math.min(40,Number(v)||0)):v;if(list.every(n=>value(n,prop)===next&&!(prop==='fill'&&n.gradient)))return;ctx.snap();for(const n of list){n[key(n,prop)]=next;if(prop==='textColor'&&n.textStyleRef)n.textStyleOverrides={textColor:next};if(prop==='fill')delete n.gradient;}ctx.commit()}
 el.addEventListener('click',e=>{const b=e.target.closest('[data-note-color]');if(b)apply('fill',b.dataset.noteColor)});
 el.addEventListener('change',e=>{if(e.target.dataset.style)apply(e.target.dataset.style,e.target.value)});
 function render(showSingle=false){const list=selection();if(list.length===1&&!showSingle){el.style.display='none';return null}const common=list.length?properties(list[0]).filter(prop=>list.every(n=>properties(n).includes(prop))):[];el.style.display=common.length&&!ctx.editing()?'flex':'none';if(el.style.display==='none')return null;for(const label of el.querySelectorAll('[data-style-field]')){const prop=label.dataset.styleField;label.hidden=!common.includes(prop);const input=label.querySelector('input');const same=list.every(n=>value(n,prop)===value(list[0],prop));input.value=value(list[0],prop);if(prop==='strokeWidth')input.min=list.some(n=>n.type==='stroke')?'1':'0';input.dataset.mixed=String(!same);input.title=same?'':'Valores diferentes — alterar aplica a todos';label.classList.toggle('mixed',!same)}const presets=el.querySelector('#noteColors');presets.hidden=!list.every(n=>n.type==='note');if(!presets.hidden)presets.innerHTML=ctx.colors.map((c,i)=>`<button type="button" data-note-color="${c}" aria-label="Cor da nota ${i+1}" style="--swatch:${c};background:${c}"></button>`).join('');return el}
 return {element:el,render,apply};
};
