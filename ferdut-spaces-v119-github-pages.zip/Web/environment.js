/* Capabilities are local; no remote service or tracking is enabled. */
window.FerdutEnvironment=Object.freeze({localService:['127.0.0.1','localhost','[::1]'].includes(location.hostname),web:!['127.0.0.1','localhost','[::1]'].includes(location.hostname)});
window.FerdutGrid=Object.freeze({spacing(base,zoom){let size=base*zoom;while(size<12)size*=2;return size}});
