/* Single-object actions inherit the same zoom and anchor as fit-to-content controls. */
(()=>{'use strict';const api=ferdutProject,$=id=>document.getElementById(id);let frame=0;
const single=document.createElement('button');single.id='elementLock';single.type='button';single.hidden=true;single.dataset.lockSelection='';document.body.append(single);
const multi=document.createElement('button');multi.id='lockSelection';multi.type='button';multi.hidden=true;multi.dataset.lockSelection='';$('selectionbar').querySelector('#selectionCount').after(multi);
const shapeText=document.createElement('button');shapeText.id='shapeTextButton';shapeText.type='button';shapeText.hidden=true;shapeText.textContent='T';shapeText.setAttribute('aria-label','Editar texto da forma');shapeText.title='Editar texto da forma · duplo clique';document.body.append(shapeText);
function symbol(locked){return `<svg viewBox="0 0 20 20" aria-hidden="true"><rect x="4" y="9" width="12" height="9" rx="2"/><path d="M7 9V6a3 3 0 0 1 6 0${locked?'v3':''}"/></svg>`}
function update(){frame=0;const list=api.selected(),editing=!!document.querySelector('#nodes [contenteditable=true]'),show=FerdutStudios.active()==='creative'&&api.activeTool()==='select'&&!api.gestureKind()&&!editing&&list.length>0;single.hidden=!show||list.length!==1;multi.hidden=!show||list.length<2;shapeText.hidden=true;document.body.classList.toggle('selection-is-locked',list.some(api.isItemLocked));const locked=list.length&&list.every(api.isItemLocked),pageLocked=!!api.state().pages.find(p=>p.id===api.state().page)?.locked;
for(const b of [single,multi]){b.innerHTML=symbol(locked);b.setAttribute('aria-pressed',String(!!locked));b.setAttribute('aria-label',locked?'Desbloquear seleção':'Bloquear seleção');b.title=b.getAttribute('aria-label');b.disabled=pageLocked}
if(single.hidden)return;const n=list[0],el=[...document.querySelectorAll('#nodes .node')].find(e=>e.dataset.id===n.id);let r=el?.getBoundingClientRect();if(!r){const box=FerdutLayout.rotatedBounds(api.bounds(n),n.rotation||0),c=$('canvas').getBoundingClientRect(),s=api.state();r={left:c.left+s.x+box.x*s.zoom,top:c.top+s.y+box.y*s.zoom,right:c.left+s.x+(box.x+box.w)*s.zoom}}
if(el){el.append(single);Object.assign(single.style,{position:'absolute',top:'-36px',right:'0px',left:'auto',transform:'none'});}
else{document.body.append(single);const z=api.state().zoom;Object.assign(single.style,{position:'fixed',left:(r.right-28*z)+'px',top:(r.top-36*z)+'px',right:'auto',transform:'scale('+z+')',transformOrigin:'top left'})}
single.disabled=pageLocked||api.isItemLocked(n)&&!n.locked;if(single.disabled&&!pageLocked)single.title='Bloqueado pela seção — desbloqueie a seção primeiro';
if(n.type==='shape'&&!api.isItemLocked(n)&&!pageLocked&&el){shapeText.hidden=false;el.append(shapeText);Object.assign(shapeText.style,{position:'absolute',left:'auto',right:'36px',top:'-36px',transform:'none'})}

}
function schedule(){if(!frame)frame=requestAnimationFrame(update)}
// Window capture precedes edit guards on document/canvas, so unlock remains operable.
window.addEventListener('pointerdown',e=>{if(e.target.closest?.('[data-lock-selection],#shapeTextButton')){e.preventDefault();e.stopImmediatePropagation()}},true);
window.addEventListener('click',e=>{const lock=e.target.closest?.('[data-lock-selection]'),text=e.target.closest?.('#shapeTextButton');if(!lock&&!text)return;e.preventDefault();e.stopImmediatePropagation();if(lock&&!lock.disabled)api.setSelectionLock();if(text)api.editShapeText(api.selected()[0]?.id);schedule()},true);
for(const type of ['ferdut-selection-updated','ferdut-selection-geometry','ferdut-viewport-updated','ferdut-workspace-changed','ferdut-project-loaded','ferdut-tool-changed','resize'])window.addEventListener(type,schedule);document.addEventListener('pointerdown',schedule,true);document.addEventListener('focusout',schedule,true);schedule();
})();
