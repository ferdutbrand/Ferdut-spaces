window.FerdutLinks=(()=>{
 let ctx,activePlayer;
 const coverFits=new Map();let fitFrame=0,fitTimer=0;
 function scheduleCoverFit(){if(!fitFrame&&!fitTimer)fitFrame=requestAnimationFrame(flushCoverFits)}
 function flushCoverFits(){fitFrame=0;if(ctx?.busy?.()){fitTimer=setTimeout(()=>{fitTimer=0;scheduleCoverFit()},120);return}const rows=[...coverFits.values()];coverFits.clear();ctx?.fitCovers?.(rows)}
 function fitImage(image){const node=image.closest('.node.linknode'),n=node&&ctx?.get(node.dataset.id);if(!node.isConnected||!n||!image.naturalWidth||!image.naturalHeight)return;const ratio=image.naturalWidth/image.naturalHeight;if(!Number.isFinite(ratio)||ratio<.05||ratio>30)return;const width=n.w||300;if(n.previewFitVersion===1&&n.previewFitWidth===width&&Math.abs((n.previewAspect||0)-ratio)<.0001)return;coverFits.set(n.id,{id:n.id,object:n,ratio,metaHeight:node.querySelector('.link-meta')?.offsetHeight||44,border:node.offsetWidth-node.clientWidth});scheduleCoverFit()}
 document.addEventListener('load',e=>{if(e.target.matches?.('.link-thumbnail'))fitImage(e.target)},true);

 const pending=new Map(),attempted=new WeakMap(),queue=[];
 let fetching=0;
 function pump(){
  while(fetching<3&&queue.length){
   const {url,resolve,reject}=queue.shift();fetching++;
   (FerdutEnvironment.localService?fetch('/api/link-preview?url='+encodeURIComponent(url),{signal:AbortSignal.timeout(18000)}):Promise.reject(Error('static-web')))
    .then(response=>{if(!response.ok)throw Error('indisponível');return response.json()})
    .then(resolve,reject).finally(()=>{fetching--;pump()});
  }
 }
 function request(url){
  if(!pending.has(url)){
   const task=new Promise((resolve,reject)=>queue.push({url,resolve,reject}));
   pending.set(url,task);pump();
   task.then(()=>pending.delete(url),()=>pending.delete(url));
  }
  return pending.get(url);
 }
 function safeURL(value){try{const u=new URL(value);return ['http:','https:'].includes(u.protocol)?u.href:'#'}catch{return '#'}}
 function embed(value){
  try{
   const u=new URL(value);
   if(['instagram.com','www.instagram.com'].includes(u.hostname)){const post=u.pathname.match(/^\/(reel|reels|p|tv)\/([\w-]+)\/?/);if(post)return 'https://www.instagram.com/'+(post[1]==='reels'?'reel':post[1])+'/'+post[2]+'/embed/';}
   let id;
   if(['www.youtube.com','youtube.com','m.youtube.com'].includes(u.hostname)){
    id=/^\/(shorts|live|embed)\//.test(u.pathname)?u.pathname.split('/')[2]:u.searchParams.get('v');
   }else if(u.hostname==='youtu.be')id=u.pathname.split('/')[1];
   if(/^[\w-]{11}$/.test(id||''))return 'https://www.youtube-nocookie.com/embed/'+id;
   if(['vimeo.com','www.vimeo.com'].includes(u.hostname)&&/^\/\d+\/?$/.test(u.pathname))return 'https://player.vimeo.com/video/'+u.pathname.split('/')[1];
  }catch{}
  return null;
 }
 function videoURL(url){
  try{return /\.(mp4|webm|ogv)$/i.test(new URL(url).pathname)?url:null}catch{return null}
 }
 function youtubeCover(url){const frame=embed(url);return frame?.startsWith('https://www.youtube-nocookie.com/embed/')?'https://i.ytimg.com/vi/'+frame.split('/').at(-1)+'/hqdefault.jpg':null}
 function markup(n,esc){
  const url=safeURL(n.url);
  let domain='Link';
  try{domain=new URL(url).hostname.replace(/^www\./,'')}catch{}
  const label=n.previewTitle||(n.text&&safeURL(n.text)!==url?n.text:domain);
  const video=embed(url)||videoURL(url);
  const fallback=youtubeCover(url);const cover=/^data:image\/(png|jpeg|webp|gif);base64,/.test(n.previewImage||'')?
   `<img class="link-thumbnail" src="${esc(n.previewImage)}" alt="" decoding="async" draggable="false">`:fallback?`<img class="link-thumbnail" src="${fallback}" alt="Capa do vídeo" decoding="async" draggable="false" referrerpolicy="no-referrer">`:'<span class="link-placeholder" aria-hidden="true">↗</span>';
  const action=video?`<button type="button" class="link-cover" data-link-action="play" aria-label="Reproduzir ${esc(label)}">${cover}<span class="link-play" aria-hidden="true">▶</span></button>`:
   `<a class="link-cover" href="${esc(url)}" target="_blank" rel="noopener noreferrer" aria-label="Abrir ${esc(label)}" draggable="false">${cover}</a>`;
  return `<div class="link-content">${action}<div class="link-meta"><div class="link-card-title">${esc(label)}</div><div class="link-domain">${esc(domain)}</div>${!n.previewImage&&!fallback&&n.previewStatus?`<small class="link-preview-status">${esc(n.previewStatus==='service'?(FerdutEnvironment.localService?'Prévia precisa do servidor local':'Prévia completa disponível no app para Mac'):n.previewStatus==='loading'?'Buscando capa…':'Capa indisponível na origem')}</small>`:''}</div></div>`;
 }
 async function refresh(n,{manual=false}={}){
  const original=safeURL(n?.url);
  if(!n||original==='#'||!navigator.onLine||!ctx.canEdit(n.page)||(!manual&&attempted.get(n)===original))return false;
  attempted.set(n,original);n.previewStatus='loading';
  try{
   const data=await request(original);
   if(ctx.get(n.id)!==n||safeURL(n.url)!==original||!ctx.canEdit(n.page))return false;
   n.previewTitle=String(data.title||'').slice(0,500);n.previewStatus=data.image?'ready':'unavailable';
   n.previewDescription=String(data.description||'').slice(0,2000);
   if(!n.previewCoverManual)n.previewImage=/^data:image\/(png|jpeg|webp|gif);base64,/.test(data.image||'')?data.image:undefined;
   ctx.update();
   return true;
  }catch{if(ctx.get(n.id)!==n||safeURL(n.url)!==original||!ctx.canEdit(n.page))return false;const cover=youtubeCover(original);if(cover&&!n.previewCoverManual){try{const response=await fetch(cover,{mode:'cors',signal:AbortSignal.timeout(6000)});const blob=await response.blob();if(!response.ok||!/^image\/(jpeg|png|webp)$/.test(blob.type)||blob.size>2*1024*1024)throw Error();const image=await new Promise((ok,no)=>{const reader=new FileReader();reader.onload=()=>ok(reader.result);reader.onerror=no;reader.readAsDataURL(blob)});if(ctx.get(n.id)===n&&safeURL(n.url)===original&&!n.previewCoverManual&&ctx.canEdit(n.page)){n.previewImage=image;n.previewStatus='ready';ctx.update();return true}}catch{}}n.previewStatus='service';ctx.update();if(manual)ctx.notice(FerdutEnvironment.localService?'Abra pelo servidor local para buscar capas. A origem também pode restringir a prévia.':'Nesta versão web, a origem pode impedir a capa. Use uma capa manual ou abra o link na origem.');return false}


 }
 let youtubePromise;
 function youtubeAPI(){if(window.YT?.Player)return Promise.resolve(window.YT);if(!youtubePromise)youtubePromise=new Promise((ok,no)=>{const previous=window.onYouTubeIframeAPIReady,script=document.createElement('script');let timer;window.onYouTubeIframeAPIReady=()=>{clearTimeout(timer);previous?.();ok(window.YT)};script.src='https://www.youtube.com/iframe_api';script.onerror=()=>{clearTimeout(timer);script.remove();youtubePromise=null;no(Error('Player indisponível'))};timer=setTimeout(()=>{script.remove();youtubePromise=null;no(Error('Player indisponível'))},8000);document.head.append(script)});return youtubePromise}
 function play(n,card){
  if(!navigator.onLine){ctx.notice('Conecte-se à internet para reproduzir este vídeo.');return}
  const url=safeURL(n.url),frameURL=embed(url),direct=videoURL(url);
  if(!frameURL&&!direct)return;
  if(frameURL&&!/^https?:$/.test(location.protocol)){
   ctx.notice('Abra o Ferdut pelo endereço HTTP ou HTTPS para reproduzir vídeos incorporados.');
   window.open(url,'_blank','noopener,noreferrer');return;
  }
  activePlayer?.close();
  const player=document.createElement('div');
  player.className='link-inline-player';
  const node=card.closest('.node');
  const instagram=frameURL?.startsWith('https://www.instagram.com/');
  const portrait=/\/(shorts|reel|reels|tv)\//.test(new URL(url).pathname);
  const ratio=portrait?9/16:(n.previewAspect>0?n.previewAspect:instagram?9/16:16/9);
  // The provider gets a usable CSS viewport, independent of the canvas zoom.
  const intrinsicWidth=instagram?400:640,providerChrome=instagram?130:0;
  const intrinsicHeight=intrinsicWidth/ratio+providerChrome;
  const viewport=document.createElement('div');viewport.className='link-media-viewport';
  player.classList.add('link-player-expanded');node.classList.add('link-playing');document.body.classList.add('link-media-playing');
  function layoutPlayer(){const rect=node.getBoundingClientRect(),zoom=window.ferdutProject?.state().zoom||1;
   const width=Math.max(1,Math.min(instagram?360:480,innerWidth-24,(innerHeight-150)*intrinsicWidth/intrinsicHeight));
   const height=width*intrinsicHeight/intrinsicWidth,scale=width/(intrinsicWidth*zoom);
   player.style.width=width/zoom+'px';player.style.height=(height+30)/zoom+'px';
   player.style.left=(Math.max(12,Math.min(rect.left,innerWidth-width-12))-rect.left)/zoom+'px';
   player.style.top=(Math.max(66,Math.min(rect.top,innerHeight-height-90))-rect.top)/zoom+'px';player.style.bottom='auto';
   viewport.style.width=width/zoom+'px';viewport.style.height=height/zoom+'px';
   media.style.width=intrinsicWidth+'px';media.style.height=intrinsicHeight+'px';media.style.transform='scale('+scale+')';
   bar.style.height=30/zoom+'px';bar.style.minHeight=30/zoom+'px';bar.style.fontSize=11/zoom+'px';external.style.fontSize=11/zoom+'px';close.style.cssText='width:'+24/zoom+'px;height:'+24/zoom+'px;min-width:0;min-height:0;padding:0;font-size:'+16/zoom+'px';
  }
  const cover=card.querySelector('.link-cover');
  const bar=document.createElement('div');bar.className='link-player-head';
  const external=document.createElement('a');external.href=url;external.target='_blank';external.rel='noopener noreferrer';external.textContent='Abrir na origem';
  const close=document.createElement('button');close.type='button';close.textContent='×';close.setAttribute('aria-label','Fechar vídeo');close.dataset.linkAction='close';
  bar.append(external,close);
  const media=document.createElement(frameURL?'iframe':'video');
  if(frameURL){
   media.title=n.previewTitle||'Vídeo incorporado';
   media.sandbox='allow-scripts allow-same-origin allow-presentation';
   media.referrerPolicy='strict-origin-when-cross-origin';
   media.allow='autoplay; fullscreen; encrypted-media; picture-in-picture';
   media.allowFullscreen=true;
   const source=new URL(frameURL);source.searchParams.set('autoplay','1');if(source.hostname==='www.youtube-nocookie.com'){source.searchParams.set('origin',location.origin);source.searchParams.set('enablejsapi','1');source.searchParams.set('playsinline','1');}media.src=source.href;
  }else{media.src=direct;media.controls=true;media.autoplay=true;media.playsInline=true}
  media.className='link-embed';
  viewport.append(media);player.append(viewport,bar);layoutPlayer();player.addEventListener('pointerdown',e=>e.stopPropagation());
  let youtubePlayer=null;const restore=()=>{window.removeEventListener('ferdut-viewport-updated',layoutPlayer);window.removeEventListener('resize',layoutPlayer);try{youtubePlayer?.destroy?.()}catch{}media.remove();player.remove();node.classList.remove('link-playing');document.body.classList.remove('link-media-playing');cover.hidden=false;activePlayer=null};
  close.onclick=restore;
  player.addEventListener('keydown',e=>{if(e.key==='Escape'){e.stopPropagation();restore();cover.focus()}});
  cover.hidden=true;cover.after(player);
  activePlayer={close:restore};window.addEventListener('ferdut-viewport-updated',layoutPlayer);window.addEventListener('resize',layoutPlayer);
  if(frameURL?.startsWith('https://www.youtube-nocookie.com/'))youtubeAPI().then(YT=>{if(!media.isConnected)return;youtubePlayer=new YT.Player(media,{events:{onError:event=>{if(!player.isConnected)return;let message=player.querySelector('.link-player-status');if(!message){message=document.createElement('p');message.className='link-player-status';message.setAttribute('role','status');player.append(message)}message.textContent=({100:'Vídeo removido, privado ou indisponível.',101:'O autor não permite reprodução incorporada.',150:'O autor não permite reprodução incorporada.',153:'O YouTube não reconheceu a identificação deste aplicativo.',2:'Endereço de vídeo inválido.',5:'O navegador não conseguiu iniciar este vídeo.'})[event.data]||'O YouTube não permitiu reproduzir este vídeo aqui.';}}})}).catch(()=>{});

  close.focus({preventScroll:true});
 }
 document.addEventListener('pointerdown',e=>{if(activePlayer&&!e.target.closest?.('.link-inline-player,.zoom'))activePlayer.close()},true);
 window.addEventListener('ferdut-workspace-changed',()=>activePlayer?.close());
 document.addEventListener('click',e=>{
  const b=e.target.closest?.('[data-link-action=play]');
  const n=b&&ctx?.get(b.closest('.node')?.dataset.id);
  if(n){e.stopPropagation();play(n,b.closest('.link-content'))}
 });
 async function setCover(n){
  if(!n||!ctx.canEdit(n.page))return;
  const picker=document.createElement('input');
  picker.type='file';picker.accept='image/png,image/jpeg,image/webp,image/gif';
  picker.onchange=async()=>{
   const file=picker.files[0];
   if(!file)return;
   if(file.size>15*1024*1024){ctx.notice('Escolha uma imagem de até 15 MB.');return}
   try{
    const bitmap=await createImageBitmap(file);
    const scale=Math.min(1,960/Math.max(bitmap.width,bitmap.height)),canvas=document.createElement('canvas');
    canvas.width=Math.max(1,Math.round(bitmap.width*scale));canvas.height=Math.max(1,Math.round(bitmap.height*scale));
    try{
     canvas.getContext('2d').drawImage(bitmap,0,0,canvas.width,canvas.height);
     if(ctx.get(n.id)!==n||!ctx.canEdit(n.page))return;
     ctx.snap();n.previewImage=canvas.toDataURL('image/jpeg',.85);n.previewCoverManual=true;ctx.update();
    }finally{bitmap.close();canvas.width=canvas.height=1}
   }catch{ctx.notice('Não foi possível abrir a imagem da capa.')}
  };
  picker.click();
 }
 window.addEventListener('online',()=>{if(ctx)document.querySelectorAll('.node.linknode').forEach(el=>{const n=ctx.get(el.dataset.id);if(n&&!n.previewImage){attempted.delete(n);void refresh(n)}})});
 return {setCover,setup:value=>ctx=value,markup,safeURL,embed,refresh,hydrate:(n,el)=>{if(!n.previewImage)void refresh(n);if(el)requestAnimationFrame(()=>{const image=el.isConnected&&el.querySelector('.link-thumbnail');if(image?.complete)fitImage(image)})}};
})();
