/* Heavy font validation/CFF/GPOS compilation stays outside the UI event loop. */
importScripts('vector-core.js','font-engine.js','vendor/opentype.min.js');
self.onmessage=event=>{const {id,document}=event.data;try{const buffer=FerdutType.compile(document,opentype);self.postMessage({id,buffer},[buffer])}catch(error){self.postMessage({id,error:error.message})}};
