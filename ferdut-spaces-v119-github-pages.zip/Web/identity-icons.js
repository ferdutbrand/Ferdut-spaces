/* Solid UI symbols, deliberately scoped away from document artwork. */
window.FerdutUIIcons=(()=>{'use strict';const paths={
select:'M4 2v19l5-6 4 7 3-2-4-7h8Z',
hand:'M7 11V5a1.5 1.5 0 0 1 3 0v6h1V3a1.5 1.5 0 0 1 3 0v8h1V5a1.5 1.5 0 0 1 3 0v7h1V9a1.5 1.5 0 0 1 3 0v6c0 5-3 8-8 8h-2c-3 0-5-2-6-4l-4-6a2 2 0 0 1 3-2l2 3Z',
pencil:'m3 16 5 5-7 2Zm1-2L15 3l6 6L10 20Zm12-12 1-1a2 2 0 0 1 3 0l3 3a2 2 0 0 1 0 3l-1 1Z',
eraser:'m3 12 8-8a3 3 0 0 1 4 0l6 6a3 3 0 0 1 0 4l-6 6H8l-5-5a2 2 0 0 1 0-3Zm2 1 5 5h4l4-4-7-7Z',
note:'M3 2h18v14l-7 6H3Zm12 12v5l5-5Z',
text:'M2 3h20v5h-3V6h-5v13h3v3H7v-3h3V6H5v2H2Z',
shape:'M2 3h13v13H2Zm16 8a6 6 0 1 1-5 8h5Z',
settings:'M19.65 9.65L22.84 10.11L22.84 13.89L19.65 14.35L19.07 15.74L21.00 18.33L18.33 21.00L15.74 19.07L14.35 19.65L13.89 22.84L10.11 22.84L9.65 19.65L8.26 19.07L5.67 21.00L3.00 18.33L4.93 15.74L4.35 14.35L1.16 13.89L1.16 10.11L4.35 9.65L4.93 8.26L3.00 5.67L5.67 3.00L8.26 4.93L9.65 4.35L10.11 1.16L13.89 1.16L14.35 4.35L15.74 4.93L18.33 3.00L21.00 5.67L19.07 8.26ZM12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8Z',
lock:'M6 9V6a6 6 0 0 1 12 0v3h3v14H3V9Zm3 0h6V6a3 3 0 0 0-6 0Zm2 5v5h2v-5Z',
unlock:'M6 9V6a6 6 0 0 1 12 0h-3a3 3 0 0 0-6 0v3h12v14H3V9Zm5 5v5h2v-5Z',
fit:'M1 1h8v3H4v5H1Zm14 0h8v8h-3V4h-5ZM1 15h3v5h5v3H1Zm19 0h3v8h-8v-3h5ZM7 7h10v10H7Z',
trash:'M7 1h10v3h5v3H2V4h5ZM4 9h16l-1 14H5Zm4 2v9h2v-9Zm6 0v9h2v-9Z',
copy:'M2 1h14v3H5v13H2Zm6 6h14v16H8Z',
plus:'M10 2h4v8h8v4h-8v8h-4v-8H2v-4h8Z',minus:'M3 10h18v4H3Z',
undo:'M9 2 0 10l9 8v-5h5a6 6 0 0 1 6 6h3a9 9 0 0 0-9-9H9Z',
redo:'m15 2 9 8-9 8v-5h-5a6 6 0 0 0-6 6H1a9 9 0 0 1 9-9h5Z',
save:'M10 1h4v11l4-4 2 2-8 8-8-8 2-2 4 4ZM2 17h3v4h14v-4h3v7H2Z',
open:'M2 3h8l3 3h9v4H2Zm0 9h22l-5 10H0Z',
search:'M10 1a9 9 0 1 0 5 16l6 6 3-3-7-6A9 9 0 0 0 10 1Zm0 3a6 6 0 1 1 0 12 6 6 0 0 1 0-12Z',
sun:'M10 0h4v4h-4Zm0 20h4v4h-4ZM0 10h4v4H0Zm20 0h4v4h-4ZM3 1l4 4-2 2-4-4Zm16 16 4 4-2 2-4-4ZM1 21l4-4 2 2-4 4ZM17 5l4-4 2 2-4 4ZM12 6a6 6 0 1 0 0 12 6 6 0 0 0 0-12Z',
moon:'M11 1a11 11 0 1 0 12 14A10 10 0 0 1 11 1Z',
link:'M9 3a6 6 0 0 1 9 0l4 4a6 6 0 0 1-8 9l-2-2 2-2 2 2a3 3 0 0 0 4-5l-4-4a3 3 0 0 0-5 0ZM3 9a6 6 0 0 1 7 0l2 2-2 2-2-2a3 3 0 0 0-4 4l5 5a3 3 0 0 0 4-4l2 2a6 6 0 0 1-8 4l-5-5a6 6 0 0 1 1-8Z',
connect:'M1 2h7v7H1Zm15 0h7v7h-7ZM8 18h8v6H8ZM4 11h3v2h10v-2h3v5h-7v1h-3v-1H4Z',
checklist:'M1 2h6v6H1Zm9 1h13v4H10ZM1 10h6v6H1Zm9 1h13v4H10ZM1 18h6v6H1Zm9 1h13v4H10Z',
left:'M1 1h3v22H1Zm6 4h16v5H7Zm0 9h11v5H7Z',right:'M20 1h3v22h-3ZM1 5h16v5H1Zm5 9h12v5H6Z',
top:'M1 1h22v3H1Zm4 6h5v16H5Zm9 0h5v11h-5Z',bottom:'M1 20h22v3H1ZM5 1h5v16H5Zm9 5h5v12h-5Z',
centerH:'M10 1h3v3h8v6h-8v4h5v6h-5v3h-3v-3H5v-6h5v-4H2V4h8Z',centerV:'M1 10h3V2h6v8h4V5h6v5h3v3h-3v8h-6v-8h-4v5H4v-5H1Z',
distributeH:'M1 1h3v22H1Zm19 0h3v22h-3ZM7 6h3v12H7Zm7-3h3v18h-3Z',distributeV:'M1 1h22v3H1Zm0 19h22v3H1ZM6 7h12v3H6Zm-3 7h18v3H3Z'};
function svg(name){return '<svg class="fs-solid-icon" data-fs-icon="'+name+'" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill-rule="evenodd" d="'+paths[name]+'"/></svg>'}
const mapping={'#uiSettingsShortcut,#settingsBtn':'settings','[data-tool=select]':'select','[data-tool=hand]':'hand','[data-tool=pencil]':'pencil','[data-tool=eraser]':'eraser','[data-tool=note]':'note','[data-tool=text]':'text','[data-tool=shape]':'shape','[data-tool=connect],#mindNew':'connect','[data-tool=checklist],#checklistNew,[data-rich=checklist],[data-rich=insertUnorderedList]':'checklist','#newPage,#zoomIn':'plus','#zoomOut':'minus','#zoomReset,[data-text-fit],[data-rich=fitText],[data-section-fit]':'fit','#undo,#pcUndo,#plUndo,#deviceUndo':'undo','#redo,#pcRedo,#plRedo,#deviceRedo':'redo','#exportBtn':'save','#importBtn':'open','[data-appearance=light]':'sun','[data-appearance=dark]':'moon','#pcHslEdit,[data-pc-edit-saved]':'pencil','#navSearch':'search','[data-pc-delete-saved]':'trash','[data-pc-copy]':'copy','[data-align=align-left]':'left','[data-align=align-right]':'right','[data-align=align-top]':'top','[data-align=align-bottom]':'bottom','[data-align=align-center-h]':'centerH','[data-align=align-center-v]':'centerV','[data-align=distribute-h]':'distributeH','[data-align=distribute-v]':'distributeV'};
let frame=0;const roots=new WeakSet();
function replace(button,name){if(button.classList.contains('ds-custom-icon'))return;const old=button.querySelector('svg');if(old){if(old.dataset.fsIcon===name&&old.querySelector('path')?.getAttribute('d')===paths[name])return;old.outerHTML=svg(name)}else if(button.matches('#exportBtn,#importBtn')){button.prepend(document.createRange().createContextualFragment(svg(name)));for(const n of [...button.childNodes])if(n.nodeType===3)n.textContent=n.textContent.replace(/[↓↑⇩⇧↥↧]/g,'').replace(/^\s*/,' ')}else if(button.matches('#newPage,#zoomIn,#zoomOut,#zoomReset'))button.innerHTML=svg(name)}
function run(){frame=0;for(const [selector,name]of Object.entries(mapping))for(const b of document.querySelectorAll(selector))replace(b,name);for(const b of document.querySelectorAll('#elementLock,#lockSelection,[data-pc-lock]'))replace(b,b.getAttribute('aria-pressed')==='true'?'lock':'unlock');for(const root of document.querySelectorAll('#toolbar,#navigation,#richbar,#selectionbar,#stylebar,#paletteLab,#elementLock,#lockSelection'))if(!roots.has(root)){roots.add(root);new MutationObserver(schedule).observe(root,{childList:true,subtree:true})}}
function schedule(){if(!frame)frame=requestAnimationFrame(run)}
for(const name of ['ferdut-selection-updated','ferdut-palette-changed','ferdut-project-loaded','ferdut-workspace-changed'])window.addEventListener(name,schedule);schedule();return{svg,refresh:schedule};})();
