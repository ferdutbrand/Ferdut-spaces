# Ferdut Spaces v0.117 — Auditoria técnica e otimizações

## Escopo
Revisão estática da v0.116. Não equivale a pentest, teste de carga nem validação visual real nos navegadores.

## Mudanças aplicadas
- Biblioteca de Recursos: renderização da lista limitada a 40 registros por página; paginação local, busca e filtros reiniciam a página; página se ajusta após exclusões.
- Tags: removido o botão de exclusão direta da lista; exclusão agora fica dentro da edição e exige confirmação, informando quantos recursos serão desassociados.
- Cores de tags: geração dinâmica de cor hexadecimal, tentando manter diferença perceptível das existentes e contraste mínimo aproximado contra os fundos claros/escuros da interface. Não há paleta fixa de 24.
- Verificação em lote: verificações paralelas atualizam estado sem renderizar a lista repetidamente; a interface é atualizada ao concluir o lote. Limite simultâneo de 4 preservado.
- URL: rejeita esquemas fora de HTTP/HTTPS, credenciais e hosts localhost/endereços IPv4 privados mais comuns. Isso é defesa local de navegação, não proteção completa contra DNS rebinding ou todos os formatos de IP.
- Importação JSON: limite de arquivo 5 MB; valida tags/cores, URLs e tipos; normaliza campos e remapeia tags; limita textos e rating.
- Diálogo: adiciona título acessível, foco inicial, fechamento por Escape e restauração do foco ao fechar.
- CSS: paginação, estado de foco visível e layout compacto mobile.
- Service Worker: cache version bumped para v117 para atualizar a instalação após deploy.
- Manifesto de SHA-256 dos arquivos publicados regenerado.

## Paginação
A aplicação é estática e hospedada em GitHub Pages; não há backend/server database. A paginação aplicada é **local/client-side**, limitando a renderização do DOM a 40 linhas por página. Busca e ordenação ainda analisam a coleção local completa. Paginação verdadeira no backend exigiria uma API e serviço de armazenamento, o que aumentaria custo e complexidade e não foi introduzido.

## Acessibilidade
- Botões da Biblioteca mantêm labels e títulos nativos (tooltips do navegador) e receberam foco visível via `:focus-visible`.
- Paginação com nav/aria-label e controles nomeados.
- Modal nomeado por `aria-labelledby`, foco inicial, Escape e retorno do foco.
- Nota: tooltip nativo (`title`) não substitui texto acessível nem foi submetido a teste WCAG completo; auditoria manual com teclado e leitor de tela continua necessária.

## Revisão de segurança estática
- URLs de recursos aceitam apenas HTTP/HTTPS; links abrem em nova aba com `rel="noopener noreferrer"`.
- Importação é validada antes de ser incorporada ao estado.
- HTML de nomes/descrições/tag é escapado ao renderizar.
- Fetch externo para verificar links é limitado a HEAD com timeout; fallback GET ocorre apenas quando HEAD não é aceito e o corpo é cancelado. Bloqueio de CORS é tratado como “não verificável”.
- Não foi identificado uso de `eval` ou `new Function` nos arquivos JavaScript próprios da pasta Web nesta varredura.
- Riscos remanescentes: recursos externos e fontes externas ainda dependem das políticas de CORS e do navegador; CSP e revisão de dependências vendorizadas não foram aplicadas/avaliadas por completo; a validação de IP/host não substitui uma política de rede.

## Lógicas redundantes
- Foi consolidado o contador de recursos por tag em uma única passagem na renderização da Biblioteca, em vez de filtrar todos os recursos repetidamente para cada tag.
- A renderização de linhas foi limitada por paginação.
- Não foi feita remoção agressiva de funções compartilhadas entre módulos: helpers com nomes semelhantes podem ter requisitos de contexto diferentes e sua consolidação sem testes de regressão poderia quebrar ambientes. Uma auditoria de duplicação estrutural mais ampla permanece como próxima etapa.

## Testes executados
- `node --check` em todos os JavaScript não-vendorizados de `Web`: aprovado.
- `scripts/verify-web.py`: aprovado; 139 dependências offline listadas.
- Integridade do ZIP e manifesto SHA-256: serão conferidos após empacotamento.
- Testes de interação no Chromium/Safari/Firefox e leitor de tela: não executados neste ambiente.
