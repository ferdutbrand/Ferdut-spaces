# Validação 0.115

Biblioteca de Recursos adicionada como ambiente sob demanda: CRUD de recursos e tags, cores exclusivas por tag, associação de múltiplas tags, busca, filtros combinados, ordenação, avaliação de 1–5 estrelas, exclusão com confirmação, exportação/importação JSON e persistência em localStorage. Verificação de disponibilidade usa HEAD com fallback GET quando o servidor responde 405/501; respostas HTTP 4xx/5xx são indisponíveis, respostas HTTP bem-sucedidas são acessíveis e bloqueios CORS/rede/timeout permanecem como não verificados. Verificação automática ao abrir o ambiente, com validade de 12 horas e concorrência limitada a quatro requisições.

Sintaxe JavaScript de resources.js e studio-loader.js aprovada; scripts/verify-web.py confirmou 137 dependências offline e fronteira de publicação Web. Não foi possível executar o teste de interface no Chromium deste ambiente: o navegador bloqueou tanto navegação localhost quanto file:// com ERR_BLOCKED_BY_ADMINISTRATOR. Testes funcionais e visuais reais ainda precisam ser executados no Mac/navegador. A verificação de links externos é limitada pelas políticas CORS dos sites; cinza significa não verificável, não necessariamente indisponível.


viewport-v113.cjs em Chromium/Firefox: 600 notas com texto longo, 15 passos de zoom com reutilização do conteúdo preparado (nenhuma passagem adicional de conteúdo nessa sequência), preservação das geometrias e textos, grade com intervalo visual mínimo de 12 px e liberação da indicação de composição ao encerrar o gesto. Isso mede o trabalho solicitado pelo JavaScript, não FPS nem uso de GPU no Mac.

pan-v99.cjs reexecutado em Chromium/Firefox: pan acompanha o ponteiro antes do próximo quadro, com 600 objetos, seleção ativa/inativa, três zooms e entradas por mão/espaço/botão central; posições dos objetos preservadas e viewport salvo. navigation-v110.cjs e selection-v112.cjs também passaram nos dois motores.

pages-v113.cjs em Chromium/Firefox: aplicação sob /ferdut-spaces/, modo estático simulado sem chamadas à API local, Estratégia/Cores/Tipografia, reabertura offline do iframe tipográfico e atualização do service worker com preservação do projeto em IndexedDB. Servidor de teste localhost, não é uma implantação real no GitHub Pages.

Scripts de verificação validam as 137 dependências offline e a fronteira de publicação Web. Sintaxe dos JavaScripts e seis verificações de pacote passaram. O workflow está preparado; a execução de Actions e publicação real dependem da conexão ao GitHub. WKWebView e compilação Swift não executados neste Linux.

# Validação 0.112

selection-v112.cjs: seleção por área com 600 elementos, zoom 20%, 100% e 250%, canvas deslocado, arrasto nos dois sentidos, passagem sobre o cabeçalho, remoção da caixa ao soltar e seleção final. Testes em Chromium e Firefox. Navegação e amostras verificadas novamente com navigation-v110.cjs. Compilação e execução WKWebView/macOS indisponíveis neste Linux; confirmar o comportamento no Mac.

# Validação 0.111

Regressão navigation-v110.cjs passou novamente em Chromium e Firefox. Sintaxe de todos os JavaScripts verificada e seis verificações de pacote passaram.

Tipografia testada em Chromium e Firefox: carregamento sob demanda, edição de estilos e escala, salvamento por projeto, catálogo nativo simulado, importação e persistência da fonte, envio de quatro textos editáveis, desfazer, reabertura e isolamento entre projetos. Validação rejeita configurações inválidas.

A leitura das fontes usa uma ponte nativa restrita ao documento principal local. O catálogo foi simulado nos testes web; compilação Swift e execução WKWebView não estão disponíveis neste Linux. A confirmação no Mac inclui listar as fontes ativas e visualizar famílias com variações de peso e itálico.

# Validação 0.110

navigation-v110.cjs em Chromium/Firefox: objeto com limites rotacionados entrando no viewport, 21 cores distintas no menu em claro/escuro, início de pan durante edição com botão central, renderização de objeto entrando na tela e retorno após navegações repetidas. Sem erros de página.

image-cache-v110.cjs (ambiente simulado): ultrapassa o orçamento de 64 MiB com sete miniaturas de 2048×2048; confirma origem imediata, orçamento mantido, ausência de URL revogada nos elementos ativos, recuperação de erro e preservação de originais. Não é uma medição de uso real de memória/decodificação do sistema.

pan-v99.cjs reexecutado em Chromium/Firefox: 600 elementos, três zooms, múltiplos modos de pan, preservação de geometrias e posição, transformação imediata e liberação da indicação de composição ao fim do gesto. Sintaxe JS e seis verificações de pacote concluídas. Resultados anteriores são históricos. WKWebView/macOS não executado neste Linux: o relato intermitente precisa ser confirmado após atualização no Mac.

# Validação 0.109

identity-v109.cjs em Chromium e Firefox: tokens e fundos nos dois temas, botões selecionados, SVGs preenchidos nos controles fixos e dinâmicos, troca de aparência sem alterações nos objetos, ausência de substituição de SVG em geometria do documento e abertura/fechamento da edição HSL. Inspeção visual dos dois temas e do Laboratório de Cores.

Reexecutados review-v108.cjs e match-hsl-v108.cjs em Chromium/Firefox, com sucesso. Sintaxe JS e seis verificações de pacote concluídas. Os valores da paleta e variações foram extraídos do SVG fornecido e registrados em IDENTIDADE.json. Demais resultados de testes preservados são históricos. Compilação/execução nativa macOS não disponíveis neste Linux.

# Validação 0.108

review-v108.cjs passou em Chromium e Firefox: integração do botão Revisar no editor real, spellcheck/lang, menu nativo não bloqueado em contenteditable, correções explícitas em prévia, cancelamento, aplicação, desfazer do projeto, preservação do negrito e do itálico, edição do texto interno de geometria e regras de repetição/pontuação/frase longa/redundância/parênteses. A exibição do dicionário nativo e sugestões do macOS depende de validação no Mac.

match-hsl-v108.cjs: atualização do Pantone durante a edição HSL, três alternativas, seleção de HEX de referência na prévia, cancelamento, aplicação em um único desfazer, persistência, controles HSL, erros de HEX, janela estreita e botão Match do cartão. Testado em Chromium e Firefox. pantone-promote-v106.cjs reexecutado com sucesso nos dois motores para busca exata, pontuação, tonalidades e exportações. O teste hsl-v107.cjs original é histórico: sua expectativa de adiar Pantone foi substituída nesta versão.

Verificações de pacote e sintaxe JS executadas. Não há execução/compilação nativa macOS neste Linux. Percentuais são índices digitais do app, não validação colorimétrica física.

# Validação 0.107

hsl-v107.cjs passou em Chromium e Firefox: caneta no cartão selecionado, gesto no círculo, prévia HSL/HEX, luminosidade, isolamento do rascunho persistido, preservação das outras cores, HEX inválido, cancelar/Escape, aplicar em um único desfazer/refazer, aplicação sem mudança sem histórico extra, popover em janela estreita e persistência após aplicar. Inspeção visual do editor realizada.

Reexecutados tones-v103.cjs, pantone-promote-v106.cjs e samples-v95.cjs com sucesso nos dois navegadores. Verificações de sintaxe e pacote executadas. Testes nativos de compilação e execução macOS não são possíveis neste Linux.

# Validação 0.106

Novo pantone-promote-v106.cjs em Chromium/Firefox: busca de referência sRGB exata no catálogo local (Match 100% e ΔE 0); índice explícito limitado e 100% reservado à coincidência; conteúdo SVG; clique promove somente a cor do cartão escolhido; escala recalculada; desfazer/refazer; promoção por botão acessível; salvar, envio ao canvas, exportação vetorial sem raster e persistência ao reabrir.

tones-v103.cjs foi adaptado para usar o botão explícito de copiar HEX, pois o clique direto passou intencionalmente a promover. Reexecutado junto de samples-v95.cjs contra esta versão. Sintaxe e pacote verificados. Outros resultados são históricos. A comparação digital não é validação colorimétrica de impressão. A camada nativa macOS não foi executada neste ambiente.

# Validação 0.105

Verificado o SVG gerado: oito códigos HEX derivados com fonte 5; HEX principal com fonte 12; números das variações com fonte 4,5. Verificações de sintaxe e pacote executadas. Resultados dos demais testes preservados são históricos; não houve execução nativa no Mac nesta alteração visual.

# Validação 0.104

Conferida a remoção de “Marca” e a redução exata à metade dos números no SVG compartilhado, mantendo fonte/tamanho dos HEX e dados técnicos. tones-v103.cjs reexecutado em Chromium e Firefox contra esta versão. Verificação de sintaxe e de pacote concluída. A camada macOS não foi executada neste Linux.

# Validação 0.103

Novo tones-v103.cjs: cálculo de nove tons em sRGB com marca exata e nível adaptado, teste de luminosidade monotônica e extremos, configuração inválida rejeitada, checkbox e cartão compartilhado, edição HEX/fixação, mudança de base, reordenação, desbloqueio e desfazer/refazer, cópia de HEX com clipboard mock, salvar/duplicar/vincular com ajustes, CSS/JSON/SVG, envio ao canvas, composição vetorial com texto e sem raster, persistência/reabertura e retorno ao modo de porcentagens. Chromium e Firefox.

Reexecutados samples-v95.cjs e ui-gradients-v102.cjs contra o código 0.103. gradient-math-v102.cjs verifica que as sugestões de gradiente continuam corretas após compartilhar o cálculo de tons. Verificação de sintaxe e seis verificações de pacote também executadas. Demais resultados são históricos.

Testes do clipboard usam payload/serialização no navegador. Não houve compilação macOS ou colagem nativa no Affinity neste ambiente Linux. A pendência da nota como caixa de texto nativa não é alterada nesta versão.

# Validação 0.102

- ui-gradients-v102.cjs em Chromium e Firefox: carregamento sob demanda, sugestões da paleta, tonalidade com original preservada, dois/três pontos, HEX inválido, posições/opacidade, desfazer/refazer, tipo radial e centro, superfícies/contraste, biblioteca criar/atualizar/excluir/restaurar, CSS/SVG baixados, janela estreita sem overflow horizontal, envio como forma com gradient nativo, composição vetorial sem imagem de fallback, persistência ao recarregar, paleta preservada e importação inválida rejeitada. Também direção linear, limite de 8 pontos, remoção do último, movimento de ponto por teclado e cópia CSS com mock.
- gradient-math-v102.cjs: identifica contraste insuficiente entre extremidades que individualmente passam; verifica interpolação alfa pré-multiplicada, superfície branca/preta, extremos da marca branco/preto, tons dentro de sRGB, direção linear e validação de opacidade.
- Reexecutados samples-v95.cjs e pan-v99.cjs contra esta versão. Resultados atualizados. Inspeção visual interna da prévia corrigiu conflito com estilos globais de cabeçalho e preenchimento SVG com proporções diferentes. Nenhuma captura de tela foi incluída no pacote.
- verify-package.py e verificação de sintaxe JavaScript executados.

A medição de contraste é amostrada; não afirma certificação de acessibilidade ou garantia do componente final. A execução e colagem reais da camada AppKit/WKWebView não foram realizadas neste Linux. A cópia nativa de gradientes usa o fluxo já existente, sem nova validação em Affinity nesta entrega.

# Validação 0.101

note-text-v101.cjs: Chromium e Firefox. Verifica um único text por nota, linhas com origem escalar e estilos sem posições individuais, conteúdo contínuo, acentos, parágrafo, negrito e cor parcial, fundo vetorial e nenhuma rasterização. Payload nativo exercitado com mock; conteúdo original preservado. Não valida uma caixa de texto nativa no Affinity.

samples-v95.cjs e editor-controls-v97.cjs reexecutados contra o código atual. Resultados desses cenários atualizados; outros resultados permanecem históricos. Sintaxe e pacote verificados. Colagem real via WKWebView/AppKit no Affinity não executada neste ambiente Linux.

# Validação 0.100

Novo overview-v100.cjs: comparação com 0.99 em Chromium e Firefox, 1.200 elementos a zoom 0,2. Verifica redução de alterações do viewBox e de leituras das dimensões do canvas; contagem integral dos 900 cartões, 300 traços e 150 conexões; geometria dos objetos preservada; superfícies cobrem toda a área visível após pan, zoom 15/20/40/100/200% e redimensionamento.

A baseline é opcional (BASELINE_WEB). Sem uma cópia anterior disponível, executa apenas os testes da versão atual. Resultados registrados em results-overview-v100.json. Tempos de JavaScript variam e não representam FPS, composição ou repintura no WKWebView do Mac.

Reexecutados pan-v99.cjs, interactions-v97.cjs e static-neighbors-v96.cjs contra esta versão. Verificação de sintaxe e pacote também executadas. Os arquivos de resultados correspondentes foram atualizados. Demais resultados preservados são históricos.

# Validação 0.99

pan-v99.cjs: testes de navegação com eventos de ponteiro, com e sem seleção, três níveis de zoom e três entradas. Verifica resposta imediata 1:1, ausência de nova serialização dos cartões já renderizados durante o pan, preservação de geometria e persistência. interactions-v97.cjs reexecutado para edição, bloqueio, grupos e arraste de objetos. verify-package.py e verificação de sintaxe JavaScript concluídos.

Não foi possível executar o app nativo neste ambiente Linux. A causa observada no código era trabalho completo de renderização por quadro com seleção ativa; esta versão retira esse trabalho do caminho de navegação e aplica a translação diretamente ao evento de mouse. A confirmação do atraso relatado depende do projeto real no Mac mini.

# Validação 0.98

Regressões executadas nesta versão em Chromium e Firefox: editor-controls-v97, interactions-v97, static-neighbors-v96, samples-v95, units-text-v92. Os nomes indicam a versão em que cada cenário foi introduzido; os resultados foram atualizados contra o código 0.98. Testes históricos de duplicação pelos pontos + ou de empurrão em cadeia não representam o comportamento atual.

consolidation-v98.cjs verifica catálogo enxuto, ausência dos módulos antigos na abertura, carga raster sob demanda, troca Estratégia/Cores, persistência e arraste de seleção em uma cena de 600 itens. Para comparar outra cópia, defina BASELINE_WEB com o caminho da pasta Web anterior. Sem uma cópia anterior disponível, testa apenas a versão atual.

Resultados de tempos são observações de um ensaio em Linux/headless, sem equivalência garantida com o Mac mini. O teste tem cadência limitada pelo navegador; a mediana de quadro ficou igual antes/depois. A redução comprovada é de trabalho de DOM e carregamento inicial, não um aumento medido de FPS nativo.

A camada AppKit/WKWebView não foi compilada/executada neste ambiente. Teste nativo necessário: iniciar o .app, abrir seu projeto habitual, arrastar conjuntos em zoom ampliado, editar notas/formas, trocar para Cores e voltar, salvar/reabrir, copiar para Affinity/Figma e reproduzir links permitidos pelo provedor.

# Estado de validação — beta macOS 0.97

|Parte|Resultado|
|---|---|
|Manifesto e configuração do pacote|Verificados por Python/plistlib|
|Recursos exigidos pelo service worker|Todos presentes|
|Fontes e ícone|Presentes; formato PNG verificado|
|Script de geração|Sintaxe Bash aprovada; recusa Linux antes de criar build|
|Interface empacotada|Inicialização, Estratégia/Cores, Pantone, offline e persistência aprovados em Chromium e Firefox|
|WebKit no ambiente Linux|Indisponível por bibliotecas do sistema ausentes|
|Compilação Swift com SDK macOS|Não executada: Swift/Xcode/AppKit/WebKit macOS ausentes no ambiente|
|Executável nativo/assinatura/instalação|Pendente no Mac do usuário|
|Servidor Swift e consulta real de capas|Implementados, não executados aqui|
|Menus nativos, importação/exportação, downloads, encerramento|Implementados, não executados aqui|
|Desempenho no Mac, Safari/WKWebView e players reais|Pendente|

Não confundir os testes da interface em um servidor de teste com execução do servidor Swift ou do aplicativo nativo. Nenhum teste automatizado daqui comprova a compilação ou o funcionamento da camada AppKit.

Testes incluídos: `python3 Testes/verify-package.py` (6 verificações) e `node Testes/web-package.cjs` (Playwright). JSON dos navegadores incluído. O executável nativo deve ser criado com `bash Gerar-App-Mac.sh` no Mac.

O serviço usa sockets Darwin para bind explícito a 127.0.0.1, porta fixa 32189. O banco do app fica sob gerenciamento do WKWebsiteDataStore.default() com identificador com.ferdut.spaces.mac. Não altere identificador/porta em atualizações sem migração. Atualizações devem preservar o armazenamento e continuar aceitando os arquivos .entre anteriores.

Sem novo backend remoto, novas dependências de runtime ou serviço pago. Nenhuma medição de FPS/memória nativa realizada.

## Verificações específicas 0.91

Chromium/Firefox: fluxo aprovado de notas novas/legadas, duplicação nas quatro direções com original fixo, conteúdo/HTML/cor preservados e cópia sem grupo, desfazer/refazer, limite mínimo por API/arraste real/grupo/ajuste ao conteúdo, texto livre independente, recolher/expandir por ponteiro/teclado, persistência das preferências e reabertura offline com Estratégia e Cores. Cabeçalho nativo testado simulando a classe injetada no WebKit. Sem erros de página.

Esses testes executam os recursos web em servidor de teste. Não comprovam a compilação Swift, janela AppKit ou limpeza de cache no macOS. A suíte completa de regressão das versões anteriores não foi repetida nesta alteração localizada. Relatório em Testes/results-notes-v91.json.

## Verificações específicas 0.92

`node Testes/units-text-v92.cjs`: Chromium e Firefox. Dez comandos de alinhamento/distribuição/grade preservam membros de grupos e rotas internas. Verificados desfazer/refazer, edição isolada, texto livre crescendo e diminuindo durante digitação, múltiplas linhas explícitas, conversão para caixa com quebra, conversão inversa, redimensionamento proporcional, persistência e geometria de textos legados. Resultados em `Testes/results-units-text-v92.json`.

A camada nativa continua dependendo de compilação e validação no Mac. Não houve medição de performance nativa nem execução do WKWebView aqui.

Regressão localizada 0.92: também passou `Testes/notes-v92.cjs` em Chromium/Firefox (notas, menus, preferências, offline e Cores); WebKit indisponível. A fixture de texto desse teste escolhe explicitamente o modo caixa para testar a compatibilidade anterior.

## Verificações específicas 0.93

`Testes/samples-v93.cjs`: Chromium/Firefox aprovados. Conferidos remoção de controles, bloqueio de seleção visual com edição preservada, fórmula CMYK/tonalidades, dados técnicos compartilhados entre laboratório/canvas, editar/salvar/excluir/desfazer paleta, SVG válido com texto editável da nota e amostras sem imagens raster, payload SVG+PNG no receptor nativo simulado e fallback de navegador, persistência.

O bridge macOS usa WKScriptMessageHandlerWithReply e NSPasteboard com SVG (`public.svg-image`), texto SVG e PNG. Restringe mensagens ao frame principal do serviço local e limita os tamanhos. Ainda NÃO compilado/executado no macOS. Não foram executados Affinity/Figma nem um pasteboard real. Programas podem escolher o PNG ou importar linhas/trechos de texto de forma diferente. SVG salvo por ⌘⇧E é a alternativa interoperável.

Foram repetidos testes anteriores de grupos/texto (v92) e notas/menus/offline/Cores (v92). Resultados JSON acompanham o pacote. WebKit indisponível neste Linux. A suíte histórica completa não foi repetida.

A cópia interna foi verificada também quando o paste oferece SVG como texto: os objetos continuam paleta/nota, com exclusão e desfazer independentes.

## Verificações específicas 0.94

`Testes/samples-v94.cjs` em Chromium/Firefox: limites dos 11 caminhos em 0/0/100/100, limites individuais e do grupo iguais à geometria pintada, toolbar ajustada sem operações booleanas, SVG sem margem arbitrária, payload vetorial sem PNG (Mac simulado e browser), erro/recuperação preservando SVG, fallback PNG para composição incompatível, cópia interna preservando tipos, biblioteca e persistência.

`Sources/VectorClipboard.swift` implementa representação PDF de um documento SVG em WKWebView temporário por createPDF. O formato PDF nativo NÃO foi executado aqui, nem analisado em Affinity/Figma. Não considerar o teste simulado uma comprovação do NSPasteboard real. Compilação Swift com SDK macOS pendente. O build inclui explicitamente o novo arquivo.

Não foram alterados identificador do aplicativo ou origem de armazenamento. Uma representação PNG não é oferecida quando a seleção pode ser composta como SVG. O aplicativo receptor ainda escolhe entre SVG, PDF ou texto SVG.

## Verificações específicas 0.95

- `Testes/interactions-v95.cjs`: Chromium/Firefox. Texto interno por botão e duplo clique, conclusão e SVG sem imagem; cadeado individual e múltiplo; seleção de bloqueados e Shift; impedimento de arraste/teclas/excluir/editar; bloqueio em lote de nota/texto/forma/seção/imagem/vetor/link/checklist/traço; herança da seção; desbloqueio; desfazer/refazer; persistência. Arraste real de 500 formas em zoom 2: item fixo protegido, margem entre todos os pares, restauração por desfazer.
- `Testes/layout-session-v95.cjs`: 165 resoluções consecutivas comparadas ao motor anterior, com cena plana, grupos, seções, itens imóveis e alvos de encaixe. Mesmas coordenadas e conjunto de itens movidos. A fixture anterior serve apenas de referência para equivalência; não faz parte do runtime.
- Benchmark do solver: relatório `Testes/results-layout-session-v95.json`. Mediana em 1.500 itens 7,89→3,39 ms; em 4.000 itens 19,80→4,76 ms. Teste sintético no Linux, não medição de FPS/latência completa no Mac.
- Regressões de grupos/texto (v92), notas/menus/offline (v92) e amostras/geometria/cópia (v95) passaram em Chromium/Firefox. WebKit indisponível por bibliotecas do sistema ausentes.

A camada nativa de clipboard/PDF continua sem compilação/execução neste ambiente. Nenhum resultado daqui comprova a colagem real em Affinity/Figma ou a fluidez nativa no Mac.

## Verificações específicas 0.96

`Testes/static-neighbors-v96.cjs`: Chromium/Firefox aprovados. Arraste real contra objetos próximos: vizinhos mantêm todos os dados originais, unidade editada não se sobrepõe, desfazer/refazer restaura as coordenadas. Snap de borda verificado por arraste; inserção/redimensionamento não deslocam o vizinho; grupo preserva posições internas; preferências não oferecem direção de empurrão; snap pode ser desligado e continua desligado após reabrir.

O relatório de equivalência com o motor de empurrão da v95 é histórico e não é uma expectativa desta versão: o comportamento foi intencionalmente alterado. Não houve migração automática das posições dos projetos. Nenhuma medição de FPS nativo foi realizada.

Também passou `Testes/interactions-v96.cjs`, preservando texto interno, bloqueios e seleção, herança de seção, persistência e margens em uma cena com 500 itens a zoom 200%. O cenário de grupo em colisão preserva o deslocamento relativo de seus waypoints internos.

## Verificações específicas 0.97

`Testes/editor-controls-v97.cjs` em Chromium e Firefox: criação de nota vazia pelos quatro pontos com fonte/cor/tamanho preservados e original intacto; cadeado e fit com dimensões e espaçamento iguais em zoom .3/.75/1/2.5; bloquear/desbloquear; editor rico compartilhado da forma; negrito e cor parciais; fonte/peso/tamanho/alinhamento globais; geometria intacta; SVG editável; render PNG; desfazer/refazer; reabertura; editor de notas preservado.

Regressões de interação/bloqueios/arraste de 500 itens (v97), texto livre/grupos (v92) e amostras/geometria/clipboard simulado (v95) passaram em Chromium/Firefox. O seletor do teste de edição de forma foi atualizado para o conteúdo interno do editor compartilhado. A alteração dos pontos de duplicar para criar vazio é intencional; as expectativas de duplicação de conteúdo dos testes antigos de notas são históricas.

Não houve compilação ou execução do AppKit/WKWebView neste Linux. Clipboard e PDF nativos, Affinity/Figma e aparência no Mac continuam sem validação automática aqui.


## v0.116 — Refinamento de tags
- Cores de tag atribuídas automaticamente, com tentativa de evitar repetição, luminosidade muito baixa e cores visualmente próximas.
- Removido seletor de cores da criação/edição de tags.
- Exclusão de tags disponível apenas dentro da tela de edição, com confirmação adicional.
