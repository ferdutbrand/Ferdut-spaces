import Foundation
import Darwin

// Stable loopback origin keeps IndexedDB/localStorage at the same address across launches.
final class LocalServer {
    static let port: UInt16 = 32189
    let root: URL
    private var socketFD: Int32 = -1
    init(root: URL) { self.root = root.resolvingSymlinksInPath() }
    func start() throws {
        let fd = Darwin.socket(AF_INET, SOCK_STREAM, 0)
        guard fd >= 0 else { throw NSError(domain: "Socket", code: Int(errno)) }
        var reuse: Int32 = 1
        setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &reuse, socklen_t(MemoryLayout<Int32>.size))
        var address = sockaddr_in()
        address.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
        address.sin_family = sa_family_t(AF_INET)
        address.sin_port = Self.port.bigEndian
        address.sin_addr = in_addr(s_addr: inet_addr("127.0.0.1"))
        let bound = withUnsafePointer(to: &address) { ptr in
            ptr.withMemoryRebound(to: sockaddr.self, capacity: 1) { Darwin.bind(fd, $0, socklen_t(MemoryLayout<sockaddr_in>.size)) }
        }
        guard bound == 0, Darwin.listen(fd, 32) == 0 else {
            let code = errno; Darwin.close(fd)
            throw NSError(domain: "Servidor local", code: Int(code), userInfo: [NSLocalizedDescriptionKey: "Não foi possível abrir a porta \(Self.port). Feche outra instância do Ferdut e tente novamente."])
        }
        socketFD = fd
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            while let self = self, self.socketFD == fd {
                let client = Darwin.accept(fd, nil, nil)
                if client < 0 { break }
                DispatchQueue.global(qos: .userInitiated).async { self.receive(client) }
            }
        }
    }
    func stop() { if socketFD >= 0 { Darwin.shutdown(socketFD, SHUT_RDWR); Darwin.close(socketFD); socketFD = -1 } }
    private func receive(_ fd: Int32) {
        var one: Int32 = 1
        setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &one, socklen_t(MemoryLayout<Int32>.size))
        var timeout = timeval(tv_sec: 10, tv_usec: 0)
        setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &timeout, socklen_t(MemoryLayout<timeval>.size))
        setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &timeout, socklen_t(MemoryLayout<timeval>.size))
        var data = Data(), buffer = [UInt8](repeating: 0, count: 8192)
        while data.count <= 16384 {
            let count = buffer.withUnsafeMutableBytes { bytes in Darwin.recv(fd, bytes.baseAddress, bytes.count, 0) }
            if count <= 0 { Darwin.close(fd); return }
            data.append(contentsOf: buffer.prefix(count))
            if data.range(of: Data("\r\n\r\n".utf8)) != nil { break }
        }
        guard data.count <= 16384, let header = String(data: data, encoding: .utf8),
              let first = header.components(separatedBy: "\r\n").first else { reply(fd, 400); return }
        let parts = first.split(separator: " ")
        guard parts.count == 3, ["GET", "HEAD"].contains(String(parts[0])),
              let components = URLComponents(string: String(parts[1])), components.scheme == nil, components.host == nil else { reply(fd, 400); return }
        let requestPath = components.path
        if requestPath == "/api/link-preview" {
            guard parts[0] == "GET", let raw = components.queryItems?.first(where: { $0.name == "url" })?.value else { reply(fd, 400); return }
            PreviewService.preview(raw) { result in
                let object = result ?? ["error": "Preview unavailable"]
                self.reply(fd, result == nil ? 422 : 200, mime: "application/json", body: (try? JSONSerialization.data(withJSONObject: object)) ?? Data())
            }
            return
        }
        let componentsPath = requestPath.split(separator: "/", omittingEmptySubsequences: true)
        guard !componentsPath.contains(where: { $0.hasPrefix(".") }), !requestPath.contains("\0") else { reply(fd, 403); return }
        let file = root.appendingPathComponent(requestPath == "/" ? "index.html" : String(requestPath.dropFirst())).resolvingSymlinksInPath()
        guard file.path.hasPrefix(root.path + "/"), let contents = try? Data(contentsOf: file, options: .mappedIfSafe) else { reply(fd, 404); return }
        let types = ["html":"text/html; charset=utf-8", "js":"text/javascript", "mjs":"text/javascript", "css":"text/css", "json":"application/json", "webmanifest":"application/manifest+json", "png":"image/png", "jpg":"image/jpeg", "svg":"image/svg+xml", "webp":"image/webp", "ttf":"font/ttf", "woff2":"font/woff2", "wasm":"application/wasm"]
        reply(fd, 200, mime: types[file.pathExtension] ?? "application/octet-stream", body: contents, head: parts[0] == "HEAD")
    }
    private func reply(_ fd: Int32, _ status: Int, mime: String = "text/plain", body: Data = Data(), head: Bool = false) {
        let reason = status == 200 ? "OK" : "Unavailable"
        var payload = Data("HTTP/1.1 \(status) \(reason)\r\nContent-Type: \(mime)\r\nContent-Length: \(body.count)\r\nCache-Control: no-store\r\nConnection: close\r\nX-Content-Type-Options: nosniff\r\n\r\n".utf8)
        if !head { payload.append(body) }
        payload.withUnsafeBytes { bytes in
            guard let base = bytes.baseAddress else { return }
            var sent = 0
            while sent < bytes.count {
                let count = Darwin.send(fd, base.advanced(by: sent), bytes.count - sent, 0)
                if count <= 0 { break }; sent += count
            }
        }
        Darwin.close(fd)
    }
}
