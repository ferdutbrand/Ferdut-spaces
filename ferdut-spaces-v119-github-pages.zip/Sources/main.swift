import AppKit
import WebKit
import UniformTypeIdentifiers

final class AppDelegate: NSObject, NSApplicationDelegate, WKNavigationDelegate, WKUIDelegate, WKDownloadDelegate, WKScriptMessageHandlerWithReply {
    var window: NSWindow!
    var web: WKWebView!
    var server: LocalServer?
    var loaded = false
    var pendingFiles = [String]()
    var quitting = false
    var clipboardJob: VectorClipboardJob?
    let origin = "http://127.0.0.1:\(LocalServer.port)"

    func applicationDidFinishLaunching(_ notification: Notification) {
        makeMenu()
        guard let resources = Bundle.main.resourceURL else { showError("Recursos do aplicativo ausentes."); NSApp.terminate(nil); return }
        do { let service = LocalServer(root: resources.appendingPathComponent("Web")); try service.start(); server = service }
        catch { showError(error.localizedDescription); NSApp.terminate(nil); return }
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .default()
        let nativeUI = WKUserScript(source: "window.FerdutNativeMac=true;document.addEventListener('DOMContentLoaded',()=>document.body.classList.add('native-mac'));", injectionTime: .atDocumentStart, forMainFrameOnly: true)
        config.userContentController.addUserScript(nativeUI)
        config.userContentController.addScriptMessageHandler(self, contentWorld: .page, name: "ferdutClipboard")
        config.userContentController.addScriptMessageHandler(self, contentWorld: .page, name: "ferdutFonts")
        config.preferences.javaScriptCanOpenWindowsAutomatically = false
        config.mediaTypesRequiringUserActionForPlayback = []
        web = WKWebView(frame: .zero, configuration: config)
        web.navigationDelegate = self; web.uiDelegate = self
        web.allowsBackForwardNavigationGestures = false
        window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 1360, height: 900), styleMask: [.titled,.closable,.miniaturizable,.resizable], backing: .buffered, defer: false)
        window.title = "Ferdut Spaces"
        window.minSize = NSSize(width: 900, height: 640)
        window.isReleasedWhenClosed = false
        window.contentView = web
        window.setFrameAutosaveName("FerdutMainWindow")
        window.center(); window.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
        let version = Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "113"
        let load = { [self] in web.load(URLRequest(url: URL(string: origin + "/")!, cachePolicy: .reloadIgnoringLocalCacheData)) }
        if UserDefaults.standard.string(forKey: "FerdutWebBuild") != version {
            let caches: Set<String> = [WKWebsiteDataTypeDiskCache, WKWebsiteDataTypeMemoryCache, WKWebsiteDataTypeFetchCache, WKWebsiteDataTypeServiceWorkerRegistrations]
            config.websiteDataStore.removeData(ofTypes: caches, modifiedSince: .distantPast) {
                UserDefaults.standard.set(version, forKey: "FerdutWebBuild"); _ = load()
            }
        } else { _ = load() }
    }
    func applicationWillTerminate(_ notification: Notification) { server?.stop() }
    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool { window?.makeKeyAndOrderFront(nil); return true }
    func applicationShouldTerminate(_ sender: NSApplication) -> NSApplication.TerminateReply {
        guard loaded, !quitting, web != nil else { return .terminateNow }
        quitting = true
        web.callAsyncJavaScript("if(!window.ferdutProject)return true;window.ferdutProject.prepare();return (await window.ferdutProject.flush())!==false;", arguments: [:], in: nil, in: .page) { [weak self] result in
            guard let self = self, self.quitting else { return }; self.quitting = false
            switch result {
            case .success(let value) where (value as? Bool) == true: NSApp.reply(toApplicationShouldTerminate: true)
            default:
                self.window.makeKeyAndOrderFront(nil)
                let alert = NSAlert(); alert.messageText = "Não foi possível confirmar o salvamento."
                alert.informativeText = "Volte ao projeto e exporte uma cópia antes de encerrar."
                alert.addButton(withTitle: "Voltar ao projeto"); alert.runModal()
                NSApp.reply(toApplicationShouldTerminate: false)
            }
        }
        DispatchQueue.main.asyncAfter(deadline: .now()+8) { [weak self] in
            guard let self = self, self.quitting else { return }; self.quitting = false
            NSApp.reply(toApplicationShouldTerminate: false)
            self.showError("O salvamento ainda não foi confirmado. Confira o projeto e tente encerrar novamente.")
        }
        return .terminateLater
    }
    func application(_ sender: NSApplication, openFiles filenames: [String]) { pendingFiles += filenames; openPendingFiles(); sender.reply(toOpenOrPrint: .success) }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) { loaded = true; openPendingFiles() }
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) { loaded = false; showError("O processo de conteúdo foi interrompido. O app vai reabrir os dados salvos localmente."); webView.reload() }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) { showError("Não foi possível iniciar a interface: " + error.localizedDescription) }

    private func showError(_ message: String) { let alert = NSAlert(); alert.messageText = "Ferdut Spaces"; alert.informativeText = message; alert.runModal() }
    private func makeMenu() {
        let main = NSMenu(), appMenu = NSMenu(), appItem = NSMenuItem()
        main.addItem(appItem); appItem.submenu = appMenu
        appMenu.addItem(withTitle: "Sobre Ferdut Spaces", action: #selector(about), keyEquivalent: "")
        appMenu.addItem(.separator()); appMenu.addItem(withTitle: "Ocultar Ferdut Spaces", action: #selector(NSApplication.hide(_:)), keyEquivalent: "h")
        appMenu.addItem(withTitle: "Encerrar Ferdut Spaces", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")
        let file = NSMenu(title: "Arquivo"), fileItem = NSMenuItem(title: "Arquivo", action: nil, keyEquivalent: ""); fileItem.submenu = file; main.addItem(fileItem)
        file.addItem(withTitle: "Importar projeto…", action: #selector(importFile), keyEquivalent: "o")
        file.addItem(withTitle: "Exportar projeto…", action: #selector(exportFile), keyEquivalent: "s")
        let edit = NSMenu(title: "Editar"), editItem = NSMenuItem(title: "Editar", action: nil, keyEquivalent: ""); editItem.submenu = edit; main.addItem(editItem)
        edit.addItem(withTitle: "Desfazer", action: #selector(undoProject), keyEquivalent: "z")
        let redo = edit.addItem(withTitle: "Refazer", action: #selector(redoProject), keyEquivalent: "z"); redo.keyEquivalentModifierMask = [.command,.shift]
        edit.addItem(.separator())
        for (title, action, key) in [("Recortar","cut:","x"),("Copiar","copySelection:","c"),("Colar","paste:","v"),("Selecionar tudo","selectAll:","a")] { edit.addItem(withTitle: title, action: Selector(action), keyEquivalent: key) }
        let view = NSMenu(title: "Visualizar"), viewItem = NSMenuItem(title: "Visualizar", action: nil, keyEquivalent: ""); viewItem.submenu = view; main.addItem(viewItem)
        view.addItem(withTitle: "Enquadrar conteúdo", action: #selector(fit), keyEquivalent: "1").keyEquivalentModifierMask = [.command,.shift]
        view.addItem(withTitle: "Tela cheia", action: #selector(NSWindow.toggleFullScreen(_:)), keyEquivalent: "f").keyEquivalentModifierMask = [.command,.control]
        NSApp.mainMenu = main
    }
    @objc func about() { NSApp.orderFrontStandardAboutPanel(options: [NSApplication.AboutPanelOptionKey.applicationName:"Ferdut Spaces", NSApplication.AboutPanelOptionKey.applicationVersion:"Beta macOS 0.113", NSApplication.AboutPanelOptionKey.credits:NSAttributedString(string:"Estratégia, Cores e Tipografia · dados locais")]) }
    // Prefer SVG/PDF for vector selections; keep PNG only for incompatible compositions.
    @objc func copySelection(_ sender: Any?) {
        web?.evaluateJavaScript("(()=>{const e=document.activeElement;if(!e?.isContentEditable&&!e?.closest('input,textarea,select,dialog[open]')&&window.FerdutStudios?.active()==='creative'&&window.ferdutProject?.selected().length){void window.FerdutExternalClipboard.copy()}else if(e?.tagName==='IFRAME')e.contentWindow.document.execCommand('copy');else document.execCommand('copy')})()", completionHandler: nil)
    }
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage, replyHandler: @escaping (Any?, String?) -> Void) {
        let url = message.frameInfo.request.url
        guard message.frameInfo.isMainFrame, url?.scheme == "http", url?.host == "127.0.0.1", url?.port == Int(LocalServer.port), let payload = message.body as? [String: Any] else { replyHandler(nil, "Origem inválida"); return }
        if message.name == "ferdutFonts" {
            guard payload["action"] as? String == "list" else { replyHandler(nil, "Pedido de fontes inválido"); return }
            let manager = NSFontManager.shared
            let families = manager.availableFontFamilies.filter { !$0.hasPrefix(".") }.sorted { $0.localizedStandardCompare($1) == .orderedAscending }
            let catalog: [[String: Any]] = families.compactMap { family in
                let faces: [[String: Any]] = (manager.availableMembers(ofFontFamily: family) ?? []).compactMap { member in
                    guard member.count >= 4, let postscript = member[0] as? String, let style = member[1] as? String else { return nil }
                    let weight = (member[2] as? NSNumber)?.intValue ?? 5
                    let cssWeight = weight <= 2 ? 100 : weight <= 3 ? 300 : weight <= 5 ? 400 : weight <= 6 ? 500 : weight <= 8 ? 600 : weight <= 10 ? 700 : weight <= 12 ? 800 : 900
                    let traits = NSFontTraitMask(rawValue: (member[3] as? NSNumber)?.uintValue ?? 0)
                    return ["postscript": postscript, "style": style, "weight": cssWeight, "italic": traits.contains(.italicFontMask)]
                }
                return faces.isEmpty ? nil : ["family": family, "faces": faces]
            }
            replyHandler(catalog, nil); return
        }
        guard message.name == "ferdutClipboard" else { replyHandler(nil, "Recurso desconhecido"); return }
        if let svg = payload["svg"] as? String {
            guard clipboardJob == nil, svg.utf8.count <= 24*1024*1024, svg.hasPrefix("<svg "), let width = payload["width"] as? Double, let height = payload["height"] as? Double, width.isFinite, height.isFinite, width > 0, height > 0, width <= 20000, height <= 20000, width*height <= 64000000 else { replyHandler(nil, "Seleção vetorial inválida ou grande demais"); return }
            let initialChange = NSPasteboard.general.changeCount
            let job = VectorClipboardJob(width: width, height: height) { [weak self] pdf in
                self?.clipboardJob = nil
                let pasteboard = NSPasteboard.general
                guard pasteboard.changeCount == initialChange else { replyHandler(nil, "A área de transferência mudou durante a cópia; copie novamente"); return }
                let item = NSPasteboardItem()
                item.setData(Data(svg.utf8), forType: NSPasteboard.PasteboardType(UTType.svg.identifier))
                if let pdf = pdf { item.setData(pdf, forType: .pdf) }
                item.setString(svg, forType: .string)
                // Do not offer PNG/TIFF for a vector selection: some editors prefer the bitmap.
                pasteboard.clearContents()
                guard pasteboard.writeObjects([item]) else { replyHandler(nil, "Não foi possível copiar o vetor"); return }
                replyHandler(["svg":true,"pdf":pdf != nil], nil)
            }
            clipboardJob = job; job.start(svg: svg)
            return
        }
        guard let encoded = payload["png"] as? String, encoded.utf8.count <= 48*1024*1024, let png = Data(base64Encoded: encoded), png.starts(with: [137,80,78,71,13,10,26,10]) else { replyHandler(nil, "Imagem inválida"); return }
        let item = NSPasteboardItem(); item.setData(png, forType: .png)
        let pasteboard = NSPasteboard.general; pasteboard.clearContents()
        guard pasteboard.writeObjects([item]) else { replyHandler(nil, "Não foi possível copiar"); return }
        replyHandler(true, nil)
    }

    @objc func fit() { web?.evaluateJavaScript("window.FerdutDevice?.fit()", completionHandler: nil) }
    @objc func undoProject() { history("undo") }
    @objc func redoProject() { history("redo") }
    private func history(_ action: String) {
        web?.evaluateJavaScript("(()=>{const e=document.activeElement;if(e?.isContentEditable||/^(INPUT|TEXTAREA)$/.test(e?.tagName))document.execCommand('\(action)');else window.ferdutProject?.\(action)()})()", completionHandler: nil)
    }
    @objc func importFile() {
        guard loaded else { return }
        let panel = NSOpenPanel(); panel.canChooseDirectories = false; panel.allowsMultipleSelection = true
        panel.beginSheetModal(for: window) { response in if response == .OK { self.pendingFiles += panel.urls.map(\.path); self.openPendingFiles() } }
    }
    private func openPendingFiles() {
        guard loaded, !pendingFiles.isEmpty else { return }
        let paths = pendingFiles; pendingFiles.removeAll()
        // Preserve order: each imported file becomes an independent project through the existing API.
        func next(_ index: Int) {
            guard index < paths.count else { return }
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: paths[index]))
                _ = try JSONSerialization.jsonObject(with: data)
                web.callAsyncJavaScript("await window.ferdutReady;const bytes=Uint8Array.from(atob(payload),c=>c.charCodeAt(0));const doc=JSON.parse(new TextDecoder().decode(bytes));await window.ferdutWorkspace.importProject(doc);return true;", arguments: ["payload":data.base64EncodedString()], in: nil, in: .page) { result in
                    if case .failure(let error) = result { self.showError("Falha ao importar: " + error.localizedDescription) }; next(index+1)
                }
            } catch { showError("Não foi possível ler o projeto: " + error.localizedDescription); next(index+1) }
        }
        next(0)
    }
    @objc func exportFile() {
        guard loaded else { return }
        web.callAsyncJavaScript("await window.ferdutReady;window.ferdutProject.prepare();await window.ferdutProject.flush();return JSON.stringify(window.ferdutProject.state());", arguments: [:], in: nil, in: .page) { result in
            guard case .success(let value) = result, let json = value as? String else { self.showError("Não foi possível preparar o projeto."); return }
            let panel = NSSavePanel(); panel.nameFieldStringValue = "Ferdut Spaces.entre"
            panel.beginSheetModal(for: self.window) { response in
                guard response == .OK, let url = panel.url else { return }
                do { try Data(json.utf8).write(to: url, options: .atomic) } catch { self.showError(error.localizedDescription) }
            }
        }
    }
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else { decisionHandler(.cancel); return }
        if navigationAction.shouldPerformDownload { decisionHandler(.download); return }
        let local = url.scheme == "http" && url.host == "127.0.0.1" && url.port == Int(LocalServer.port)
        if navigationAction.targetFrame?.isMainFrame == false { decisionHandler(["https","http","about","blob","data"].contains(url.scheme ?? "") ? .allow : .cancel); return }
        if local || ["blob","data","about"].contains(url.scheme ?? "") { decisionHandler(.allow); return }
        if ["https","http","mailto"].contains(url.scheme ?? "") { NSWorkspace.shared.open(url) }
        decisionHandler(.cancel)
    }
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let url = navigationAction.request.url, ["https","http","mailto"].contains(url.scheme ?? "") { NSWorkspace.shared.open(url) }; return nil
    }
    func webView(_ webView: WKWebView, runOpenPanelWith parameters: WKOpenPanelParameters, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping ([URL]?) -> Void) {
        let panel = NSOpenPanel(); panel.allowsMultipleSelection = parameters.allowsMultipleSelection; panel.canChooseDirectories = false
        panel.beginSheetModal(for: window) { completionHandler($0 == .OK ? panel.urls : nil) }
    }
    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        showError(message); completionHandler()
    }
    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        let alert = NSAlert(); alert.messageText = message; alert.addButton(withTitle: "Confirmar"); alert.addButton(withTitle: "Cancelar"); completionHandler(alert.runModal() == .alertFirstButtonReturn)
    }
    func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String, defaultText: String?, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (String?) -> Void) {
        let alert = NSAlert(); alert.messageText = prompt; alert.addButton(withTitle: "OK"); alert.addButton(withTitle: "Cancelar")
        let input = NSTextField(frame: NSRect(x: 0,y: 0,width: 300,height: 24)); input.stringValue = defaultText ?? ""; alert.accessoryView = input
        completionHandler(alert.runModal() == .alertFirstButtonReturn ? input.stringValue : nil)
    }
    func webView(_ webView: WKWebView, navigationAction: WKNavigationAction, didBecome download: WKDownload) { download.delegate = self }
    func webView(_ webView: WKWebView, navigationResponse: WKNavigationResponse, didBecome download: WKDownload) { download.delegate = self }
    func download(_ download: WKDownload, decideDestinationUsing response: URLResponse, suggestedFilename: String, completionHandler: @escaping (URL?) -> Void) {
        let panel = NSSavePanel(); panel.nameFieldStringValue = (suggestedFilename as NSString).lastPathComponent
        panel.beginSheetModal(for: window) { completionHandler($0 == .OK ? panel.url : nil) }
    }
    func download(_ download: WKDownload, didFailWithError error: Error, resumeData: Data?) { showError("Falha ao salvar arquivo: " + error.localizedDescription) }
}

let app = NSApplication.shared
let delegate = AppDelegate()
app.delegate = delegate
app.setActivationPolicy(.regular)
app.run()
