import AppKit
import WebKit

// A short-lived, isolated WebKit document produces a PDF representation of the SVG.
// No screenshot or raster canvas is involved. The main application view is untouched.
final class VectorClipboardJob: NSObject, WKNavigationDelegate {
    private var renderer: WKWebView?
    private var completion: ((Data?) -> Void)?
    private var timeout: DispatchWorkItem?
    private let width: CGFloat
    private let height: CGFloat
    init(width: Double, height: Double, completion: @escaping (Data?) -> Void) {
        self.width = CGFloat(width); self.height = CGFloat(height); self.completion = completion
        super.init()
    }
    func start(svg: String) {
        let config = WKWebViewConfiguration(); config.websiteDataStore = .nonPersistent()
        let view = WKWebView(frame: NSRect(x: 0, y: 0, width: width, height: height), configuration: config)
        renderer = view; view.navigationDelegate = self
        let html = "<html><head><meta charset='utf-8'><meta http-equiv='Content-Security-Policy' content=\"default-src 'none'; style-src 'unsafe-inline'; img-src data:; font-src data:;\"><style>html,body{width:100%;height:100%;margin:0;padding:0;background:transparent;overflow:hidden}body>svg{display:block;width:100%;height:100%}</style></head><body>" + svg + "</body></html>"
        let task = DispatchWorkItem { [weak self] in self?.finish(nil) }; timeout = task
        DispatchQueue.main.asyncAfter(deadline: .now()+12, execute: task)
        view.loadHTMLString(html, baseURL: nil)
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        webView.callAsyncJavaScript("await document.fonts.ready;return true;", arguments: [:], in: nil, in: .page) { [weak self] _ in
            guard let self = self, self.completion != nil else { return }
            let config = WKPDFConfiguration(); config.rect = CGRect(x: 0, y: 0, width: self.width, height: self.height)
            webView.createPDF(configuration: config) { [weak self] result in
                switch result { case .success(let data): self?.finish(data); case .failure: self?.finish(nil) }
            }
        }
    }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { finish(nil) }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) { finish(nil) }
    private func finish(_ data: Data?) {
        guard let done = completion else { return }; completion = nil
        timeout?.cancel(); timeout = nil; renderer?.stopLoading(); renderer?.navigationDelegate = nil; renderer = nil
        done(data)
    }
}
