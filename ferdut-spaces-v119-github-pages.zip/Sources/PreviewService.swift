import Foundation
import Darwin

private func publicURL(_ url: URL) -> Bool {
    guard ["https", "http"].contains(url.scheme ?? ""), let host = url.host,
          url.user == nil, url.password == nil, url.port == nil || [80,443].contains(url.port!) else { return false }
    var result: UnsafeMutablePointer<addrinfo>?
    guard getaddrinfo(host, nil, nil, &result) == 0, let first = result else { return false }
    defer { freeaddrinfo(first) }
    var cursor: UnsafeMutablePointer<addrinfo>? = first, found = false
    while let row = cursor {
        defer { cursor = row.pointee.ai_next }
        let info = row.pointee
        if info.ai_family == AF_INET {
            guard let address = info.ai_addr else { return false }
            let ip = address.withMemoryRebound(to: sockaddr_in.self, capacity: 1) { $0.pointee.sin_addr.s_addr.bigEndian }
            let a = (ip >> 24) & 255, b = (ip >> 16) & 255
            if a == 0 || a == 10 || a == 127 || a >= 224 || (a == 169 && b == 254) || (a == 172 && b >= 16 && b <= 31) || (a == 192 && [0,168].contains(b)) || (a == 100 && b >= 64 && b <= 127) || (a == 198 && [18,19,51].contains(b)) || (a == 203 && b == 0) { return false }
            found = true
        } else if info.ai_family == AF_INET6 {
            var text = [CChar](repeating: 0, count: Int(INET6_ADDRSTRLEN))
            guard let address = info.ai_addr else { return false }
            var ip = address.withMemoryRebound(to: sockaddr_in6.self, capacity: 1) { $0.pointee.sin6_addr }
            guard inet_ntop(AF_INET6, &ip, &text, socklen_t(text.count)) != nil else { return false }
            let value = String(cString: text).lowercased()
            guard (value.hasPrefix("2") || value.hasPrefix("3")), !value.hasPrefix("2001:db8:") else { return false }
            found = true
        }
    }
    return found
}

// Per-request limits; redirect URLs go through the same public-address check.
private final class RemoteFetch: NSObject, URLSessionDataDelegate {
    let limit: Int
    let expected: [String]
    let done: (Data?, String?) -> Void
    var bytes = Data(), mime: String?, finished = false
    var session: URLSession?
    init(limit: Int, expected: [String], done: @escaping (Data?, String?) -> Void) { self.limit = limit; self.expected = expected; self.done = done }
    func start(_ url: URL) {
        guard publicURL(url) else { done(nil,nil); return }
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 5; config.timeoutIntervalForResource = 8
        config.httpCookieStorage = nil; config.urlCache = nil
        session = URLSession(configuration: config, delegate: self, delegateQueue: nil)
        var request = URLRequest(url: url)
        request.setValue("Mozilla/5.0 (compatible; FerdutSpacesMac/0.90; public link preview)", forHTTPHeaderField: "User-Agent")
        session?.dataTask(with: request).resume()
    }
    private func complete(_ data: Data?, _ type: String?) {
        guard !finished else { return }; finished = true
        done(data,type); session?.finishTasksAndInvalidate(); session = nil
    }
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) {
        completionHandler(request.url.map(publicURL) == true ? request : nil)
    }
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive response: URLResponse, completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) {
        guard let response = response as? HTTPURLResponse, (200..<300).contains(response.statusCode), let type = response.mimeType,
              expected.contains(type), response.expectedContentLength <= Int64(limit) else { completionHandler(.cancel); return }
        mime = type; completionHandler(.allow)
    }
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        if bytes.count + data.count > limit { dataTask.cancel(); return }; bytes.append(data)
    }
    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        complete(error == nil && mime != nil ? bytes : nil, error == nil ? mime : nil)
    }
}

enum PreviewService {
    private static func fetch(_ url: URL, limit: Int, expected: [String], done: @escaping (Data?,String?) -> Void) {
        RemoteFetch(limit: limit, expected: expected, done: done).start(url)
    }
    private static func matches(_ pattern: String, _ text: String) -> [[String]] {
        guard let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive,.dotMatchesLineSeparators]) else { return [] }
        let ns = text as NSString
        return regex.matches(in: text, range: NSRange(location: 0, length: ns.length)).map { m in
            (0..<m.numberOfRanges).map { m.range(at: $0).location == NSNotFound ? "" : ns.substring(with: m.range(at: $0)) }
        }
    }
    private static func decode(_ text: String) -> String {
        var value = text
        for (entity,replacement) in [("&amp;","&"),("&quot;","\""),("&#39;","'"),("&lt;","<"),("&gt;",">")] { value = value.replacingOccurrences(of: entity, with: replacement) }
        return value
    }
    private static func attributes(_ tag: String) -> [String:String] {
        var attrs = [String:String]()
        for m in matches(#"([\w:-]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))"#, tag) {
            attrs[m[1].lowercased()] = decode(!m[2].isEmpty ? m[2] : !m[3].isEmpty ? m[3] : m[4])
        }
        return attrs
    }
    private static func metadata(_ html: String) -> [String:String] {
        var result = [String:String]()
        for m in matches(#"<meta\b[^>]*>"#, html) {
            let a = attributes(m[0]), key = (a["property"] ?? a["name"] ?? "").lowercased()
            if let value = a["content"], result[key] == nil { result[key] = String(value.prefix(2000)) }
        }
        if let m = matches(#"<title\b[^>]*>(.*?)</title>"#, html).first { result["title"] = decode(String(m[1].prefix(500))) }
        for m in matches(#"<img\b[^>]*>"#, html) {
            let a = attributes(m[0]); if a["class"]?.contains("EmbeddedMediaImage") == true { result["embedded"] = a["src"]; break }
        }
        return result
    }
    private static func youtube(_ url: URL) -> URL? {
        let host = url.host?.lowercased(), parts = url.pathComponents.filter { $0 != "/" }
        var id: String?
        if host == "youtu.be" { id = parts.first }
        if ["youtube.com","www.youtube.com","m.youtube.com"].contains(host ?? "") {
            id = ["shorts","live","embed"].contains(parts.first ?? "") ? parts.dropFirst().first : URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems?.first(where: { $0.name == "v" })?.value
        }
        guard let id = id, id.range(of: #"^[\w-]{11}$"#, options: .regularExpression) != nil else { return nil }
        return URL(string: "https://i.ytimg.com/vi/\(id)/hqdefault.jpg")
    }
    static func preview(_ raw: String, done: @escaping ([String:String]?) -> Void) {
        guard raw.count < 8192, let url = URL(string: raw), publicURL(url) else { done(nil); return }
        fetch(url, limit: 1024*1024, expected: ["text/html","application/xhtml+xml"]) { data,_ in
            var meta = metadata(data.flatMap { String(data: $0, encoding: .utf8) } ?? "")
            let finish: ([String:String]) -> Void = { meta in
                var result = ["url":raw,"title":meta["og:title"] ?? meta["twitter:title"] ?? meta["title"] ?? url.host ?? "Link", "description":meta["og:description"] ?? meta["description"] ?? ""]
                var candidates = ["og:image:secure_url","og:image","og:image:url","twitter:image","twitter:image:src","embedded"].compactMap { key in meta[key].flatMap { URL(string: $0, relativeTo: url)?.absoluteURL } }
                if let fallback = youtube(url) { candidates = Array(candidates.prefix(1)) + [fallback] }
                func next(_ remaining: [URL]) {
                    guard let first = remaining.first else { done(result); return }
                    fetch(first, limit: 2*1024*1024, expected: ["image/png","image/jpeg","image/webp","image/gif"]) { image,type in
                        if let image = image, let type = type { result["image"] = "data:\(type);base64," + image.base64EncodedString(); done(result) }
                        else { next(Array(remaining.dropFirst())) }
                    }
                }
                next(Array(candidates.prefix(2)))
            }
            let parts = url.pathComponents.filter { $0 != "/" }
            if ["instagram.com","www.instagram.com"].contains(url.host ?? ""), meta["og:image"] == nil, parts.count >= 2, ["p","reel","tv"].contains(parts[0]), parts[1].range(of: #"^[\w-]+$"#, options: .regularExpression) != nil,
               let embed = URL(string: "https://www.instagram.com/\(parts[0])/\(parts[1])/embed/captioned/") {
                fetch(embed, limit: 1024*1024, expected: ["text/html"]) { data,_ in
                    if let data = data, let html = String(data: data, encoding: .utf8), let image = metadata(html)["embedded"] { meta["embedded"] = image }
                    finish(meta)
                }
            } else { finish(meta) }
        }
    }
}
