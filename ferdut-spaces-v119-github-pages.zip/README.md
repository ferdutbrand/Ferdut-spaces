# Ferdut Spaces

Aplicação pessoal para estratégia de marca, exploração de cores e tipografia. Interface em português, arquivos estáticos e armazenamento local no navegador. Versão 0.115.

## Publicar no GitHub Pages

1. Crie um repositório **ferdut-spaces**, com a branch padrão **main**. No plano gratuito, use repositório público para o Pages. Não adicione projetos de clientes ao repositório.
2. Extraia este pacote. Envie **o conteúdo da pasta ferdut-spaces-mac**, incluindo `Web`, `scripts` e `.github/workflows/pages.yml`, para a raiz do repositório. Não envie o ZIP como único arquivo. O GitHub Desktop pode publicar a pasta completa, incluindo `.github`.
3. No repositório, abra **Settings → Pages → Build and deployment → Source → GitHub Actions**.
4. Em **Actions → Publicar Ferdut Spaces**, use **Run workflow** se o primeiro push aconteceu antes de ativar o Pages. A publicação termina com a URL do site no job e em Settings → Pages.
5. Abra `https://SEU-USUARIO.github.io/ferdut-spaces/`. O nome do repositório pode mudar: os caminhos da aplicação são relativos.

O fluxo publica **somente Web**, depois de validar suas dependências e o JavaScript. A compilação do app macOS não é necessária para a versão online. O código usa as ações oficiais do GitHub; o token temporário do próprio Actions é suficiente, sem token pessoal no código.

## Atualizar pelo próprio GitHub

- Abra um arquivo dentro de **Web**, clique no lápis e faça o commit na branch **main**. A publicação começa automaticamente.
- Para mudanças em vários arquivos, use GitHub Desktop ou VS Code. Se já existe este repositório, atualize os arquivos dele; não crie um novo repositório a cada versão.
- Para uma nova versão recebida em ZIP, substitua os arquivos no checkout do mesmo repositório, confira as alterações e faça commit/push. Preserve os arquivos pessoais fora dessa pasta.
- Cada publicação recebe uma identificação de cache baseada no commit. Uma aba aberta oferece **Salvar e atualizar**, que só recarrega depois de confirmar o salvamento local. Uma primeira abertura pode exigir uma recarga após a instalação do cache offline.
- Para desfazer uma atualização, reverta o commit pelo GitHub; um novo deploy publica o estado revertido.

## Seus projetos

Cada navegador guarda sua própria cópia em IndexedDB. Publicar ou atualizar o site não envia esses projetos ao GitHub. Abrir o link em outro computador não recupera automaticamente o trabalho do Mac: use **Salvar arquivo** e **Abrir arquivo** para transportar o projeto. Exporte uma cópia antes de apagar dados do navegador ou trocar de domínio/endereço.

O site público não tem login, servidor de projetos nem colaboração em tempo real. Não há coleta de conteúdo implementada no app. GitHub Pages e provedores de vídeos/imagens podem receber requisições necessárias ao acesso a seus serviços. Não publique arquivos privados na pasta Web. Um repositório público também expõe os arquivos e o histórico do código que você enviar.

## Diferenças da edição web

- Estratégia, Cores, Biblioteca de Recursos e Tipografia funcionam no navegador. A Biblioteca de Recursos mantém tags, links, descrições e avaliações no armazenamento local do navegador; exporte o JSON para backup ou transferência. Importação de fontes TTF/OTF e salvamento por projeto permanecem disponíveis.
- O catálogo de fontes ativas do macOS usa a ponte nativa e fica no app para Mac. No navegador, importe uma fonte para testar.
- GitHub Pages não executa o servidor de prévias de links. Capas já incorporadas e capas públicas do YouTube continuam possíveis; outras capas dependem da origem ou de uma capa manual. Vídeos incorporados dependem da permissão do provedor e da conexão.
- A área de transferência depende das permissões e formatos aceitos pelo navegador e pelo software de destino. Não há promessa de equivalência à ponte nativa do Mac.
- Depois da primeira carga completa, os arquivos do aplicativo ficam disponíveis offline; mídias externas não são garantidas offline.

## Executar localmente e gerar o app

Para testar: `python3 -m http.server 8000 --directory Web` e abra `http://localhost:8000`. O servidor simples não fornece `/api/link-preview`; essa prévia completa pertence ao servidor nativo do app.

No Mac, execute `bash Gerar-App-Mac.sh`. As correções web também fazem parte do pacote macOS. A compilação Swift e o desempenho real no WKWebView precisam ser validados no Mac.

## Validação

`python3 scripts/verify-web.py` verifica os arquivos publicados e as dependências offline. Os testes de navegador ficam em Testes, com resultados identificados por versão em VALIDACAO.md. Não interpretam tempo de execução no Linux como medição de FPS no Mac.
