#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
if [[ "$(uname -s)" != Darwin ]]; then
  echo 'Execute este comando no Mac mini. A compilação usa os frameworks do macOS.' >&2
  exit 1
fi
if ! xcrun --find swiftc >/dev/null 2>&1; then
  echo 'Abra o Xcode e conclua a instalação dos componentes antes de continuar.' >&2
  exit 1
fi
app="$PWD/build/Ferdut Spaces.app"
if [[ -e "$app" ]]; then
  backup="$PWD/build/Ferdut Spaces-anterior-$(date +%Y%m%d-%H%M%S).app"
  mv -- "$app" "$backup"
fi
mkdir -p "$app/Contents/MacOS" "$app/Contents/Resources"
echo 'Compilando a janela e os serviços do Mac…'
xcrun swiftc -swift-version 5 -O -target "$(uname -m)-apple-macos13.0" -sdk "$(xcrun --sdk macosx --show-sdk-path)" Sources/LocalServer.swift Sources/PreviewService.swift Sources/VectorClipboard.swift Sources/main.swift -framework AppKit -framework WebKit -o "$app/Contents/MacOS/FerdutSpaces"
cp Info.plist "$app/Contents/Info.plist"
ditto Web "$app/Contents/Resources/Web"
iconset="$PWD/build/Ferdut.iconset"
mkdir -p "$iconset"
for size in 16 32 128 256 512; do
  sips -z "$size" "$size" Web/icons/icon-512.png --out "$iconset/icon_${size}x${size}.png" >/dev/null
  double=$((size * 2))
  sips -z "$double" "$double" Web/icons/icon-512.png --out "$iconset/icon_${size}x${size}@2x.png" >/dev/null
done
iconutil -c icns "$iconset" -o "$app/Contents/Resources/Ferdut.icns"
codesign --force --sign - "$app"
echo ''
echo "Aplicativo gerado: $app"
echo 'Abra a pasta build e arraste Ferdut Spaces.app para Aplicativos.'
echo 'Na primeira abertura, importe a cópia .entre exportada do Safari.'
open -R "$app"
