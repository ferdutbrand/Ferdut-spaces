"""Portable packaging checks; does not compile or test the macOS application."""
import hashlib,json,plistlib,re,subprocess,sys,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class PackageTests(unittest.TestCase):
    def test_offline_assets_complete(self):
        script=(ROOT/'Web/service-worker.js').read_text()
        entries=json.loads(re.search(r'const ASSETS=(\[.*?\]);',script,re.S)[1])
        self.assertGreater(len(entries),80)
        missing=[p for p in entries if p!='./' and not (ROOT/'Web'/p.removeprefix('./')).is_file()]
        self.assertEqual(missing,[])
    def test_plist_and_entrypoint(self):
        info=plistlib.loads((ROOT/'Info.plist').read_bytes())
        self.assertEqual(info['CFBundleIdentifier'],'com.ferdut.spaces.mac')
        self.assertEqual(info['LSMinimumSystemVersion'],'13.0')
        self.assertEqual(info['CFBundleExecutable'],'FerdutSpaces')
        self.assertTrue((ROOT/'Sources/main.swift').is_file())
        self.assertTrue((ROOT/'Sources/VectorClipboard.swift').is_file())
        self.assertIn('Sources/VectorClipboard.swift',(ROOT/'Gerar-App-Mac.sh').read_text())
    def test_shell_syntax(self):
        subprocess.run(['bash','-n',str(ROOT/'Gerar-App-Mac.sh')],check=True)
    def test_requires_macos_before_build(self):
        if sys.platform=='darwin':self.skipTest('Linux-only rejection check')
        result=subprocess.run(['bash',str(ROOT/'Gerar-App-Mac.sh')],capture_output=True,text=True)
        self.assertEqual(result.returncode,1)
        self.assertIn('Mac mini',result.stderr)
        self.assertFalse((ROOT/'build').exists())
    def test_web_has_no_python_runtime(self):
        self.assertEqual(list((ROOT/'Web').rglob('*.py')),[])
    def test_fonts_and_icon(self):
        self.assertTrue((ROOT/'Web/fonts/HostGrotesk-Regular.ttf').stat().st_size>1000)
        self.assertTrue((ROOT/'Web/icons/icon-512.png').read_bytes().startswith(b'\x89PNG\r\n\x1a\n'))
if __name__=='__main__':unittest.main()
