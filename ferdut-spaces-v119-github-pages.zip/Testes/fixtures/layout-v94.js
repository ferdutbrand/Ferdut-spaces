/* Local collision resolution in world coordinates. No mutation on load/render. */
window.FerdutLayout=(()=>{
 const defaults=Object.freeze({gap:12,padding:20,mode:'nearest'});
 const clamp=(n,min,max,fallback)=>Number.isFinite(+n)?Math.max(min,Math.min(max,+n)):fallback;
 function settings(value={}){return {gap:clamp(value?.gap,0,96,12),padding:clamp(value?.padding,8,96,20),mode:['nearest','horizontal','vertical'].includes(value?.mode)?value.mode:'nearest'}}
 function rotatedBounds(box,rotation=0){const angle=rotation*Math.PI/180,c=Math.abs(Math.cos(angle)),s=Math.abs(Math.sin(angle)),w=box.w*c+box.h*s,h=box.w*s+box.h*c;return {x:box.x+(box.w-w)/2,y:box.y+(box.h-h)/2,w,h}}
 const intersects=(a,b,gap=0)=>a.x<b.x+b.w+gap-.001&&a.x+a.w+gap>b.x+.001&&a.y<b.y+b.h+gap-.001&&a.y+a.h+gap>b.y+.001;
 function union(boxes){const x=Math.min(...boxes.map(b=>b.x)),y=Math.min(...boxes.map(b=>b.y));return {x,y,w:Math.max(...boxes.map(b=>b.x+b.w))-x,h:Math.max(...boxes.map(b=>b.y+b.h))-y}}
 class Grid{
  constructor(){this.cells=new Map();this.keys=new Map();this.large=new Set();this.size=256}
  range(b){return [Math.floor(b.x/this.size),Math.floor(b.y/this.size),Math.floor((b.x+b.w)/this.size),Math.floor((b.y+b.h)/this.size)]}
  remove(unit){for(const key of this.keys.get(unit)||[]){const bucket=this.cells.get(key);bucket?.delete(unit);if(!bucket?.size)this.cells.delete(key)}this.keys.delete(unit);this.large.delete(unit)}
  insert(unit){this.remove(unit);const [x,y,r,b]=this.range(unit.box);if((r-x+1)*(b-y+1)>4096){this.large.add(unit);return}const keys=[];for(let i=x;i<=r;i++)for(let j=y;j<=b;j++){const key=i+':'+j;keys.push(key);if(!this.cells.has(key))this.cells.set(key,new Set());this.cells.get(key).add(unit)}this.keys.set(unit,keys)}
  query(box,gap=0){const result=new Set(this.large);const [x,y,r,b]=this.range({x:box.x-gap,y:box.y-gap,w:box.w+gap*2,h:box.h+gap*2});if((r-x+1)*(b-y+1)>4096){for(const u of this.keys.keys())result.add(u);return result}for(let i=x;i<=r;i++)for(let j=y;j<=b;j++)for(const u of this.cells.get(i+':'+j)||[])result.add(u);return result}
 }
 function create(ctx){
  function resolve(anchorIds,options={}){
   const state=ctx.getState(),prefs=settings(state.layout),page=state.page,index=new Map(state.items.map(n=>[n.id,n]));
   const temporaryUnit=new Set(options.unitIds||[]);
   const anchors=new Set(anchorIds),protectedIds=new Set(options.immovable||[]),children=new Map();for(const n of state.items){const p=n.parent||null;if(!children.has(p))children.set(p,[]);children.get(p).push(n)}
   const family=id=>{const found=new Set([id]),queue=[id];for(let i=0;i<queue.length;i++)for(const n of children.get(queue[i])||[])if(!found.has(n.id)){found.add(n.id);queue.push(n.id)}return [...found]};
   const scopes=new Set();for(const id of [...anchors]){let n=index.get(id),guard=0;while(n&&guard++<100){scopes.add(n.parent||null);if(n.parent)anchors.add(n.parent);n=index.get(n.parent)}}
   const depth=id=>{let n=index.get(id),d=0;while(n&&d<100){d++;n=index.get(n.parent)}return d};
   const moved=new Set();let comparisons=0;
   for(const parent of [...scopes].sort((a,b)=>depth(b)-depth(a))){if(ctx.skipScope?.(parent))continue;
    const map=new Map();for(const n of children.get(parent)||[]){if(n.page!==page||n.type==='connection')continue;const key=temporaryUnit.has(n.id)?'selection':n.groupId?'group:'+n.groupId:'node:'+n.id;if(!map.has(key))map.set(key,{id:key,members:[],ids:new Set(),boxes:[],order:map.size});const u=map.get(key);u.members.push(n);for(const id of n.type==='folder'?family(n.id):[n.id])u.ids.add(id);u.boxes.push(n.type==='folder'?(n.expanded?ctx.sectionBounds(n):{x:n.x,y:n.y,w:205,h:44}):rotatedBounds(ctx.bbox(n),n.rotation||0))}
    const units=[...map.values()];for(const u of units){u.box=union(u.boxes);u.pinned=[...u.ids].some(id=>anchors.has(id));u.immovable=[...u.ids].some(id=>protectedIds.has(id));u.allowed=!!options.allowedContainer&&u.ids.has(options.allowedContainer)}
    const grid=new Grid();for(const u of units)grid.insert(u);const immovable=new Set(units.filter(u=>u.immovable)),settled=new Set(immovable),queue=[];
    function freePosition(target){
     const directions=prefs.mode==='horizontal'?['right','left']:prefs.mode==='vertical'?['down','up']:['right','down','left','up'];const candidates=[];
     for(const dir of directions){let box={...target.box},done=false;
      for(let k=0;k<=units.length+1;k++){const hits=[...grid.query(box,prefs.gap)].filter(u=>u!==target&&settled.has(u)&&!u.allowed&&intersects(box,u.box,prefs.gap));comparisons+=hits.length;if(!hits.length){done=true;break}
       if(dir==='right')box.x=Math.max(...hits.map(u=>u.box.x+u.box.w+prefs.gap));else if(dir==='left')box.x=Math.min(...hits.map(u=>u.box.x-prefs.gap-box.w));else if(dir==='down')box.y=Math.max(...hits.map(u=>u.box.y+u.box.h+prefs.gap));else box.y=Math.min(...hits.map(u=>u.box.y-prefs.gap-box.h));
      }
      if(done)candidates.push({box,distance:Math.abs(box.x-target.box.x)+Math.abs(box.y-target.box.y)});
     }
     candidates.sort((a,b)=>a.distance-b.distance);return candidates[0]?.box;
    }
    function shiftUnit(unit,next){const dx=next.x-unit.box.x,dy=next.y-unit.box.y;if(!dx&&!dy)return;for(const id of unit.ids){const n=index.get(id);if(n){ctx.setPos(n,n.x+dx,n.y+dy);moved.add(id)}}unit.box=next;grid.insert(unit)}
    for(const unit of units.filter(u=>u.pinned&&!u.immovable)){if(immovable.size){const next=freePosition(unit);if(next)shiftUnit(unit,next)}settled.add(unit);queue.push(unit)}
    for(let i=0;i<queue.length;i++){
     const source=queue[i];if(source.allowed)continue;
     const hits=[...grid.query(source.box,prefs.gap)].filter(u=>u!==source&&!settled.has(u)&&!u.allowed&&intersects(source.box,u.box,prefs.gap)).sort((a,b)=>a.order-b.order);comparisons+=hits.length;
     for(const target of hits){if(settled.has(target))continue;const next=freePosition(target);if(!next)continue;shiftUnit(target,next);settled.add(target);queue.push(target)}
    }
   }
   return {moved:[...moved],comparisons};
  }
  return {resolve};
 }
 return Object.freeze({defaults,settings,rotatedBounds,intersects,union,create});
})();
