# Atualização 0.113 — Navegação e GitHub Pages

A navegação reutiliza uma margem de objetos e a superfície SVG enquanto há cobertura da tela. O gesto atualiza a transformação e adia a reconstrução dos controles para o fim. O zoom mantém o ponto sob o ponteiro. A grade passa a mostrar menos divisões quando afastada, sem alterar coordenadas, encaixe ou dados dos objetos. O salvamento do zoom é agendado após o gesto, sem repetir a indicação de salvamento a cada evento da roda.

O pacote contém uma única base para Mac e web. Para o Mac, encerre com ⌘Q, execute `bash Gerar-App-Mac.sh` e substitua o app. Para publicar online e atualizar pelo GitHub, siga README.md. A pasta `.github` contém a publicação automática da pasta Web. Projetos pessoais não devem ser enviados ao repositório.

O site continua com armazenamento local por navegador. Os projetos do app para Mac não aparecem automaticamente na web: use Salvar arquivo/Abrir arquivo. A edição web não usa a API local de prévias nem acessa o catálogo nativo de fontes. O navegador oferece importação de fontes e capas já incorporadas. Atualizações do site oferecem Salvar e atualizar; não apagam IndexedDB.

Testes funcionais passaram em Chromium e Firefox, inclusive caminhos de repositório, carregamento offline dos três ambientes e atualização preservando o projeto local. A medição de fluidez real e a compilação Swift permanecem pendentes no Mac.

---

# Atualização 0.112 — Seleção por área

A seleção por arrasto captura o ponteiro até soltar o botão, inclusive ao passar sobre menus, o cabeçalho ou fora do canvas. A caixa acompanha cada movimento; o cálculo dos itens selecionados é agrupado por quadro, com destaque leve durante o gesto. Alças e menus são reconstruídos ao terminar, sem refazer todos os objetos a cada movimento. A seleção final é processada antes de encerrar o arrasto.

Para atualizar: encerre o app com ⌘Q, extraia este ZIP, execute `bash Gerar-App-Mac.sh` e substitua o app em Aplicativos. Projetos preservados.

---

# Atualização 0.111 — Laboratório Tipográfico

A nova aba Tipografia integra o estudo de fontes ao app: sugestões de pareamento, título, subtítulo, corpo e especial, oito escalas e proporção personalizada. Compare a hierarquia nas composições editorial, post e primeira dobra de landing, com textos próprios e prévia desktop/mobile.

Use Fontes do Mac para listar famílias ativas ou Importe uma fonte TTF/OTF. Salvar sistema guarda estilos, textos e fontes importadas no projeto. Fontes instaladas no sistema precisam existir no computador de destino; fontes importadas são incorporadas ao projeto, respeitando sua licença. As sugestões são referências para comparação visual, sem pontuação automática de compatibilidade.

Enviar ao espaço cria quatro textos editáveis agrupados e independentes do sistema salvo. Exportar disponibiliza CSS e JSON. O laboratório carrega sob demanda, sem executar a interface tipográfica durante a navegação pelo canvas. Projetos anteriores são preservados.

Para atualizar: encerre com ⌘Q, extraia este ZIP, execute `bash Gerar-App-Mac.sh` e substitua o app em Aplicativos. A integração foi testada em Chromium e Firefox; compilação e catálogo real de fontes do macOS ainda precisam de confirmação no Mac.

---

# Atualização 0.110 — Visibilidade e amostras

As amostras de cor do menu de texto voltam a mostrar suas cores nos temas claro e escuro, inclusive no hover. O tema dos botões não cobre mais os preenchimentos das amostras. As cores predefinidas de notas também são preservadas.

Navegação: começar a mover o canvas pelo botão do meio encerra corretamente a edição de texto, permitindo que novos elementos sejam renderizados ao entrar na tela. A filtragem de elementos visíveis considera a rotação. O cache de imagens restaura a fonte original antes de descartar uma miniatura em uso; uma resposta atrasada não instala uma URL já descartada. Imagens novas têm uma fonte imediata enquanto a miniatura é preparada, e falhas de miniatura retornam à original. Os dados e arquivos originais não são alterados.

Testes de navegação, amostras, rotação, cache e pan com 600 elementos passaram. Esta correção trata causas concretas identificadas no código; o desaparecimento intermitente específico do WKWebView/macOS ainda depende de confirmação no Mac, que não pode ser executado neste Linux.

Para atualizar: feche com ⌘Q, extraia este ZIP, gere novamente com Gerar-App-Mac.sh usando bash e substitua o app em Aplicativos. Projetos preservados.

---

# Atualização 0.109 — Nova identidade visual

Interface atualizada com o sistema fornecido: #454D64, #DBE2E9, #1C1F2A, #D4B592 e #B86029, e as tonalidades do SVG anexado. Azul-ardósia e seus neutros nas superfícies, areia nas seleções e cobre nas ações. O cobre mais escuro é utilizado em botões do modo claro para legibilidade; no modo escuro, a tonalidade clara usa texto escuro.

Ícones próprios flat e preenchidos nas ferramentas principais, páginas, configurações, cadeados, ajustar conteúdo, alinhamento, edição e biblioteca de paletas. Mantêm nomes acessíveis e funções existentes. Não há preenchimento global de SVG: os vetores, imagens, cores das notas e paletas dos projetos não são alterados. Ícones personalizados nas configurações continuam preservados. As personalizações explícitas de interface por projeto têm prioridade sobre os novos padrões. O editor de estilização mostra a nova paleta como referência padrão.

Os símbolos são SVGs locais, sem pacote externo ou download. A atualização dos controles é limitada aos menus e eventos de interface, sem observar todos os elementos do canvas nem executar código durante cada movimento do mouse.

Para atualizar: encerre com ⌘Q, extraia este ZIP, gere novamente com Gerar-App-Mac.sh usando bash e substitua o app em Aplicativos. Projetos preservados.

---

# Atualização 0.108 — Revisão local e Match Pantone na prévia

## Revisar textos

Dê dois cliques na nota, texto ou texto de uma forma e use Revisar na barra de edição. A revisão usa regras locais: espaços entre palavras, espaço antes de alguns sinais, sinais repetidos, parênteses sem par, palavras consecutivas repetidas, expressões possivelmente redundantes e frases com mais de 35 palavras. Sugestões de leitura não são afirmações de erro; não há avaliação semântica de argumentos ou reescrita por IA. Não há chamadas de rede para revisar.

Corrigir altera somente a prévia. Ver trecho seleciona o texto na prévia; Ignorar oculta o apontamento naquela sessão. Aplicar alterações leva a revisão ao editor, preservando a formatação ao redor das correções. Cancelar descarta. Ao sair da edição, use o Desfazer do projeto para retornar. A análise é sob demanda e a lista é limitada a 100 apontamentos.

O editor solicita correção ortográfica em português brasileiro ao navegador/macOS, preservando o menu nativo do botão direito enquanto escreve. As palavras sublinhadas e sugestões dependem do corretor do sistema e dos idiomas instalados. Não foram validadas no WKWebView do Mac neste Linux. Não há substituição automática habilitada pelo Ferdut.

## Match Pantone

A prévia HSL agora busca a referência PMS C próxima após uma breve pausa de 160 ms no ajuste. Mostra amostra digital, código, HEX e percentual. A ficha acompanha a busca. Match oferece as três referências com menor ΔE76 (Lab D65/sRGB). Escolher uma substitui a cor na prévia pelo HEX digital daquela referência; Aplicar confirma e Cancelar restaura. O botão Match do cartão também abre essas opções. Resultados antigos de buscas não substituem uma prévia mais recente.

O percentual permanece um índice digital do app, calculado por 100 menos ΔE76, limitado e arredondado; não é certificação Pantone nem previsão de impressão. Consulte amostra física para produção.

Para atualizar: feche com ⌘Q, extraia este ZIP, gere novamente com Gerar-App-Mac.sh usando bash e substitua o app em Aplicativos.

---

# Atualização 0.107 — Edição HSL com prévia

Selecione uma cor no Laboratório de Cores e clique na caneta no canto superior do cartão. O círculo controla matiz e saturação; os controles abaixo ajustam matiz, saturação e luminosidade. Também é possível digitar HEX.

O cartão, os dados técnicos, contraste e tonalidades acompanham a prévia. Pantone é recalculado ao aplicar, para manter a interação fluida. Aplicar registra uma única alteração para desfazer; Cancelar, Escape ou fechar descartam o ajuste. As outras cores ficam preservadas. Salvar continua sendo a ação que grava a paleta na biblioteca do projeto.

Para atualizar: encerre o app com ⌘Q, extraia o ZIP, execute Gerar-App-Mac.sh com bash e substitua o aplicativo em Aplicativos.

---

# Atualização 0.106 — Match digital e tonalidade como principal

- A ficha de cada cor mostra, abaixo do PMS aproximado, Match digital ≈ e o percentual, acompanhado do ΔE. O mesmo conteúdo é usado no laboratório, canvas e exportações. A busca de Pantone aproximado também apresenta esse índice.
- O percentual é uma convenção explícita do aplicativo: máximo de 0 e (100 − ΔE76), arredondado a uma casa decimal. A comparação é entre a cor sRGB exibida e as representações digitais do catálogo local, convertidas para Lab D65. 100% é reservado à coincidência digital (tolerância numérica 1e-9); demais resultados são limitados a 99,9%. Esse índice não é um padrão de porcentagem Pantone, uma probabilidade ou uma previsão de fidelidade na impressão. ΔE é apresentado para permitir conferir a diferença sem depender do índice. A ficha continua buscando o PMS C mais próximo no catálogo existente.
- No Laboratório de Cores, clicar numa tonalidade do cartão agora promove aquela cor a principal, no lugar da antiga ação de copiar HEX. A escala, os dados técnicos, o contraste de referência e a busca de Pantone são atualizados a partir dela. Só a cor daquele cartão é alterada. A edição respeita os tons que foram fixados; os demais são recalculados. Use Desfazer para voltar.
- Em Ajustar escala, as amostras são botões Usar que oferecem a mesma promoção pelo teclado. Os botões específicos de copiar HEX continuam disponíveis nesse editor.
- A promoção altera o rascunho da paleta; Salvar aplica ao item/cópias vinculadas conforme o fluxo existente. No canvas, o clique continua selecionando a paleta como objeto; esta atualização não transforma um clique de seleção em edição automática do objeto salvo.

Testes Chromium/Firefox: Match de referência exata 100%, índice limitado, promoção de cor, recálculo, desfazer/refazer, botões acessíveis, salvar/enviar/exportar e reabrir, além das regressões de tonalidades e paletas. Não foi possível executar o .app ou colar em Affinity neste Linux.

Atualize fechando com ⌘Q, extraindo este ZIP, gerando novamente com Gerar-App-Mac.sh usando bash e substituindo o aplicativo anterior em Aplicativos.

---

# Atualização 0.105 — HEX das tonalidades

Reduzido somente o HEX das oito variações de tonalidade: fonte SVG 10 → 5, metade do tamanho. O HEX principal, os dados técnicos e os números de ordem conservam os tamanhos atuais. O cartão compartilhado aplica o ajuste no laboratório, canvas e exportação SVG/PNG.

Encerre com ⌘Q, extraia este ZIP, gere novamente com Gerar-App-Mac.sh usando bash e substitua o app anterior em Aplicativos.

---

# Atualização 0.104 — hierarquia visual das tonalidades

Removido o rótulo “Marca” do cartão compartilhado. Os números das tonalidades foram reduzidos à metade: 10 → 5 no campo principal e 9 → 4,5 nas oito variações. HEX e dados técnicos conservam o tamanho atual. O mesmo desenho atende Laboratório de Cores, canvas e SVG/PNG.

Para atualizar, encerre com ⌘Q, execute Gerar-App-Mac.sh com bash e substitua o aplicativo anterior. Projetos preservados.

---

# Atualização 0.103 — tonalidades no cartão da paleta

No Laboratório de Cores, ative Tonalidades UI. O cartão conserva HEX, RGB, CMYK aproximado e PMS aproximado da cor original e mostra oito variações abaixo. A nona cor é a própria cor da marca, identificada no campo principal como Marca. Use Ajustar escala para editar cada família.

- Famílias de 100 a 900, calculadas em OKLab/OKLCH e ajustadas para sRGB por redução de intensidade. A cor da marca é preservada exatamente, e sua posição é escolhida pela luminosidade; não há obrigação de ocupar o nível 500. As cores extremas branco/preto limitam a possibilidade de clarear/escurecer. A numeração organiza a família, não representa porcentagem, transparência ou contraste garantido entre níveis.
- Clique em uma tonalidade do cartão para copiar o HEX. O editor oferece a mesma ação por teclado, seletor da cor da paleta e campos HEX para as variações. A cor original é alterada somente no editor principal.
- Editar uma variação fixa automaticamente aquele HEX. Fixar mantém o tom quando a cor principal muda. Desbloquear volta à geração automática. A cor da marca tem prioridade na posição que passa a ocupar na escala. Restaurar escala remove os ajustes; Desfazer/Refazer permite recuperá-los.
- As configurações acompanham a cor ao reordenar, inserir ou remover cores. Salvamento, duplicação e cópias vinculadas conservam a visualização e os ajustes. Ao enviar ao Espaço, a paleta é selecionada/enquadrada para facilitar o próximo passo.
- A estrutura do cartão é compartilhada pelo laboratório, canvas, PNG e SVG. As dimensões continuam as mesmas; os quatro blocos de porcentagem são substituídos, no modo UI, por oito células de tonalidades. O modo anterior continua disponível ao desligar Tonalidades UI. Paletas antigas não mudam automaticamente.
- SVG exportado e a composição vetorial da cópia incluem retângulos de cor e legendas de nível/HEX como texto. CSS inclui variáveis para a cor base e os nove níveis. JSON exporta as famílias. O arquivo .entre e os backups preservam ajustes e cadeados; não há afirmação de importação de famílias por JSON de paleta externa.
- Gradientes continuam disponíveis no mesmo ambiente, usando o mesmo cálculo de tonalidades para suas sugestões Suave/Profundo. Ajustes manuais das escalas não substituem automaticamente os pontos de gradientes já criados.

Os níveis não recebem automaticamente funções como fundo/texto/botão. Use o contraste e a prévia do componente para escolher a aplicação; uma escala sozinha não é uma certificação de acessibilidade.

Testados Chromium/Firefox: cor original exata, adaptação do nível, progressão perceptiva, branco/preto, ajustes e locks, alteração da cor principal, reordenação, desfazer/refazer, duplicação/vínculo, envio ao canvas, composição SVG sem imagem de fallback, CSS/JSON, salvar e reabrir. A colagem real no Affinity continua dependendo da execução no Mac.

Atualize encerrando com ⌘Q, extraindo o ZIP e executando Gerar-App-Mac.sh com bash. Substitua o app anterior em Aplicativos. Identificador e armazenamento permanecem iguais.

---

# Atualização 0.102 — gradientes no Laboratório de Cores

Abra Laboratório de Cores → Gradientes. O editor fica no mesmo ambiente, com biblioteca própria dentro do projeto.

- Linear: direção de 0 a 360 graus. Radial: centro e raios horizontal/vertical. São de 2 a 8 pontos, com HEX, seletor de cor, opacidade e posição. Os pontos internos podem ser arrastados na faixa ou movidos com as setas; início/fim delimitam 0/100%. Remover um extremo promove o próximo ponto. O editor não oferece malha nesta etapa.
- Sugestões usam a paleta atual: Suave e Profundo mantêm uma cor original e derivam uma tonalidade por OKLab/OKLCH, reduzindo a intensidade quando necessário para caber no sRGB. Duas cores usa as amostras escolhidas. Não há nível 500 obrigatório nem alteração das cores originais da paleta. As sugestões são pontos de partida, não garantia estética ou de acessibilidade.
- Prévia como fundo, botão ou cartão. Claro/Escuro escolhe a superfície sob o gradiente; ela também pode ser editada. A cor do texto é configurável. Texto automático escolhe preto ou branco pelo melhor contraste mínimo amostrado; se ambos forem insuficientes, o aviso continua.
- Contraste considera a faixa inteira, não somente as extremidades: 257 posições uniformes mais as posições dos pontos, interpolação sRGB com alfa pré-multiplicado e composição sobre a superfície escolhida. Os avisos usam 4,5:1 para texto comum e 3:1 para texto grande. É uma verificação amostrada conservadora da faixa de cores, não uma certificação nem análise de cada pixel do componente final. É possível que o menor contraste fique entre amostras; tamanho/peso real e posição do texto precisam ser avaliados no produto.
- Salvar cria um gradiente no projeto; carregar e salvar novamente atualiza o mesmo registro. Novo inicia outro rascunho. Excluir tem recuperação pela opção Desfazer exclusão. Rascunho e até 100 gradientes acompanham salvamento, backup e arquivo .entre. A edição do rascunho tem desfazer/refazer próprios.
- Enviar ao Espaço cria uma forma vetorial de 640×360 com o preenchimento editável no motor existente. A forma é uma cópia independente; editar a biblioteca não altera automaticamente o canvas. Ela pode ser copiada pelo fluxo vetorial existente.
- Copiar CSS; salvar CSS ou SVG. CSS usa interpolação explícita `in srgb`, exigindo suporte do destino a essa sintaxe. SVG usa gradientes nativos e stop-opacity. A superfície da prévia não é incorporada no SVG, que pode ter transparência. Coloque-o sobre a superfície usada para avaliar contraste. No CSS, a regra .brand-gradient já inclui a superfície e a cor do texto da prévia.

O editor só carrega ao entrar em Cores. Interface atual de paletas, fichas e cores da marca permanece funcional. A escala completa numerada de tonalidades não foi acrescentada nesta entrega; aqui as tonalidades derivadas são usadas nas sugestões de gradiente.

Testes de fluxo em Chromium/Firefox, layout estreito, exportação vetorial, persistência, edição e recuperação. Validação nativa de colagem no Affinity e execução do .app continuam dependendo do Mac. A pendência de caixa de texto única na cópia de notas não é alterada por esta atualização.

Para atualizar: feche o app com ⌘Q, extraia o ZIP, execute Gerar-App-Mac.sh com bash e substitua o app anterior em Aplicativos. Projetos preservados.

---

# Atualização 0.101 — texto contínuo na cópia das notas

- A exportação SVG de notas deixa de atribuir uma coordenada x a cada caractere. Cada nota possui um único elemento text; cada linha visual recebe uma origem, e os trechos de estilo fluem normalmente dentro dela.
- Fontes, pesos, cores parciais, itálico, sublinhado e espaçamento entre letras continuam no SVG. Fundo da nota continua vetor, e o conteúdo do projeto não muda.
- Texto das formas e texto livre usam o mesmo caminho de exportação. A exportação das fichas de paletas permanece igual.

Limite: um objeto text SVG com linhas posicionadas não é uma caixa de texto nativa do Affinity com refluxo automático. Este ajuste elimina a fragmentação por coordenadas de caracteres na origem, mas o agrupamento ao colar depende do importador. Não foi possível executar a colagem real no Affinity neste ambiente. Se a importação ainda separar as linhas, a criação de uma caixa com fluxo terá de usar uma representação suportada pelo aplicativo; esta versão não afirma resolver esse caso.

Testes Chromium/Firefox: nota com várias linhas e parágrafos, acentos, texto em negrito/cor parcial, nenhum vetor de posições por caractere, um único objeto text por nota, fundo vetorial, nenhuma imagem de fallback, payload nativo e preservação do conteúdo original. Regressões de paletas/copiar/colar e editor de formas/notas também executadas.

Atualize fechando com ⌘Q, extraindo o ZIP, executando Gerar-App-Mac.sh com bash e substituindo o app anterior em Aplicativos. Projetos preservados.

---

# Atualização 0.100 — navegação com visão ampla

- As superfícies SVG das conexões e dos traços agora têm uma reserva de 256 pixels de tela em cada lado. Durante o movimento, são deslocadas junto com a cena; só mudam de enquadramento quando a reserva acaba. Zoom e redimensionamento da janela atualizam o enquadramento imediatamente.
- A dimensão útil do canvas é mantida por ResizeObserver, eliminando leituras repetidas de clientWidth/clientHeight nos testes de visibilidade de cada elemento.
- A resposta direta ao mouse da 0.99 continua. Nenhum texto, imagem ou traço foi ocultado para obter esta redução de trabalho.

Comparação em Chromium e Firefox, Linux, 1.200 elementos a 20%, incluindo 900 cartões, 300 traços e 150 conexões, em 60 movimentos: 120 → 2 atualizações das superfícies SVG e 5.512 → 0 consultas síncronas às dimensões. Todos os elementos visíveis continuaram renderizados. Estes números medem trabalho de código/DOM, não FPS nem tempo de GPU no Mac.

Testados zoom de 15% a 250%, cobertura das superfícies ao mover/alterar zoom/redimensionar, navegação pelas três entradas com/sem seleção, preservação da geometria, persistência, edição, bloqueio e snap. O app nativo ainda precisa da sua validação no Mac mini.

Atualize encerrando com ⌘Q, extraindo o ZIP e executando Gerar-App-Mac.sh com bash. Substitua o app anterior em Aplicativos. O armazenamento e os projetos são preservados.

---

# Atualização 0.99 — resposta ao mover a tela

- A translação da tela acompanha o evento atual do mouse, sem esperar o quadro que atualiza cartões e menus. O deslocamento usa coordenadas da tela e não depende do zoom.
- Com seleção ativa, navegar deixa de provocar a conferência completa dos cartões a cada quadro. A verificação de conteúdo ocorre em renderizações normais; durante a navegação, cartões existentes usam atualização de geometria e novos cartões entram conforme a área visível muda.
- A atualização de visibilidade mantém a seleção e usa o mesmo limite de deslocamento com ou sem seleção. O ajuste da interface ao zoom não é repetido durante uma simples translação.
- Mão, Espaço + arraste e botão do meio entram no caminho de navegação antes dos controles de seleção. A indicação de composição gráfica vale só durante o movimento, sendo liberada ao terminar.

Testes automatizados Chromium/Firefox: 600 elementos, seleção ativa/inativa, zoom 30/100/250%, três entradas de navegação, posição visual igual à posição do evento antes do próximo quadro, geometria dos elementos preservada e posição final salva/reaberta. Isso verifica o caminho de interação; a fluidez no WKWebView precisa ser confirmada no Mac mini.

Para atualizar: encerre com ⌘Q, extraia o ZIP, execute `Gerar-App-Mac.sh` com bash e substitua o app anterior em Aplicativos. Identificador e armazenamento local permanecem iguais.

---

# Atualização 0.98 — consolidação de Estratégia e Cores

- Comandos de camadas, ativos, sobreposição, tipografia, ícones e vínculos antigos foram retirados do catálogo e dos atalhos ativos. A edição de atalhos continua disponível para as funções atuais.
- O carregador de painéis antigos deixou de iniciar. A exportação raster usada por cópia e SVG híbrido carrega apenas quando necessária, com nova tentativa disponível em caso de falha. O diálogo antigo de apresentação não é mais criado.
- Durante o arraste, os cartões já renderizados atualizam a geometria sem serializar novamente seu conteúdo a cada quadro. As conferências completas continuam nas renderizações normais e ao concluir a interação. Seções mantêm a atualização própria do conteúdo e das dimensões.
- A moldura de transformação de várias seleções reaproveita suas alças durante a interação, em vez de desmontá-las e recriá-las a cada movimento.
- Dados históricos e validação de arquivos continuam compatíveis; slides e fontes já salvos não foram apagados. Identificador, endereço local e armazenamento do app foram mantidos.

Comparação automatizada em Chromium/Linux, cena com 600 notas, formas, imagens e links, zoom 150% e 60 movimentos: 60 → 0 recriações da moldura; 59 → 57 scripts na abertura; 533.413 → 511.707 bytes JavaScript carregados. Mediana entre quadros ~16,7 ms nas duas versões: este cenário não demonstrou aumento de FPS. A menor carga de trabalho não substitui uma medição no Mac mini.

Para atualizar: feche o app com ⌘Q, extraia este ZIP e execute `Gerar-App-Mac.sh` com bash. No Terminal, digite `bash ` (com espaço), arraste o arquivo para a janela e pressione Enter. Substitua o app anterior em Aplicativos. Não use Node para executar o arquivo .sh.

Validação de interface e dados em Chromium e Firefox; compilação Swift, reprodução dos provedores e colagem real em Affinity/Figma precisam de validação no Mac. Nenhuma promessa nova de compatibilidade externa foi introduzida.

---

# Atualização 0.97 — notas vazias e editor compartilhado

- Os pontos + ao redor de uma nota agora criam uma nova nota vazia naquela direção. Preservam tamanho e aparência geral, sem copiar texto, HTML ou etiquetas. A nota original não muda. A duplicação convencional por comando/atalho continua disponível para quando você realmente quiser uma cópia.
- O texto interno das formas usa o mesmo editor das notas: fonte, peso, tamanho em pontos, cor, alinhamento, negrito parcial e demais comandos de texto. Acesse por duplo clique ou T. A formatação é salva no projeto. Editar texto não redimensiona a forma; para mudar suas dimensões use as alças.
- O fundo da nota e o ajuste automático da caixa não aparecem no editor de texto da forma, pois a geometria tem preenchimento e dimensões próprios. A aparência vetorial e os textos compatíveis são preservados no SVG; formatação não suportada usa imagem para não perder conteúdo. A prévia PNG também renderiza o texto formatado.
- Cadeado individual e T acompanham o zoom da mesma forma que o ajuste ao conteúdo, compartilhando tamanho, distância e rotação do elemento. A barra de múltipla seleção continua em tamanho de interface. Os controles da seleção ficam acessíveis junto de notas vizinhas.

Testados Chromium/Firefox, zoom 30/75/100/250%, quatro direções, formatação parcial e global, SVG/PNG, persistência, bloqueio e desfazer/refazer. A camada nativa de PDF e a colagem externa continuam dependendo de validação no Mac.

Para instalar, encerre o app, gere novamente com `Gerar-App-Mac.sh` e substitua o anterior. Os projetos locais são preservados.

---

# Atualização 0.96 — vizinhos estáticos e snap

- Foi removido o deslocamento em cadeia dos vizinhos. Em uma colisão, somente a unidade editada é ajustada para uma posição livre próxima; os demais objetos permanecem onde estavam. O mesmo vale para inserção e redimensionamento.
- A proteção contra sobreposição e a margem entre objetos continuam. Grupos e seções movidos como unidade levam seus próprios membros consigo. A organização explícita de divisões de uma seção continua sendo uma operação própria, assim como alinhar/distribuir uma seleção.
- Snap de bordas/centros e indicação visual de alinhamento continuam disponíveis. Ao entrar nesta versão, os projetos anteriores recebem snap ativado, sem reorganizar seu conteúdo. A opção pode ser desligada em Configurações → Organização → Encaixar nos objetos próximos; a escolha é salva no projeto.
- A opção de direção do deslocamento dos vizinhos foi retirada. Não há mais modo de empurrão para ativar. Grupos e itens bloqueados mantêm suas proteções.
- O índice espacial de arraste continua sendo reutilizado, mas não existe mais a fila de propagação de movimento entre vizinhos. Não houve medição de FPS no Mac.

Gere novamente o app com `Gerar-App-Mac.sh` e substitua o anterior. Identificador e armazenamento permanecem iguais. Código e interface testados em Chromium/Firefox; validação nativa depende do seu Mac.

---

# Atualização 0.95 — texto nas formas, bloqueio e interação

- Duplo clique em uma forma abre a edição do texto interno. O botão T ao lado da seleção oferece o mesmo acesso. Escape ou um clique fora conclui a edição; Enter cria uma nova linha. O SVG de formas simples mantém geometria e texto editáveis.
- O cadeado aparece acima do canto direito do elemento selecionado, ao lado do ajuste ao conteúdo quando existente. Com vários itens selecionados, aparece na barra da seleção e aplica o bloqueio/desbloqueio a todos em uma única ação.
- Itens bloqueados continuam selecionáveis, inclusive com Shift, e podem ser copiados. Arraste, alças, edição, exclusão e atalhos de alteração são protegidos. Clique no cadeado novamente para desbloquear. Desfazer/refazer e o arquivo .entre preservam o estado.
- Bloquear uma seção protege seus filhos. Para liberar um filho bloqueado pela seção, desbloqueie primeiro a seção. Grupos com integrante bloqueado não podem ser movidos como conjunto.
- O motor de colisões reutiliza os índices espaciais durante o arraste em áreas sem seções, inclusive agrupamentos. Atualiza somente unidades que se moveram ou foram restauradas. O resultado das colisões foi comparado com o motor anterior. Ao terminar o arraste, o cálculo completo continua sendo executado. Seções e cenários de hierarquia mantêm o caminho anterior conservador.

## Desempenho observado

Teste sintético do cálculo de colisões, neste ambiente Linux: mediana de 7,89 para 3,39 ms com 1.500 itens; com 4.000 itens, de 19,80 para 4,76 ms. Esses números NÃO representam FPS do aplicativo ou tempo de interação no Mac. Renderização, conteúdo e organização das seções também influenciam a resposta. Teste de arraste real com 500 itens e zoom 200% passou em Chromium/Firefox, com objeto bloqueado fixo, margem mantida e desfazer restaurando a geometria.

Para instalar esta versão, gere novamente o app e substitua o anterior. Identificador e origem de armazenamento foram mantidos.

---

# Ferdut Spaces 0.94 para Mac

Estratégia e Cores. Interface local em AppKit + WKWebView; macOS 13 ou superior. O app gerado não precisa de Node/Python nem de navegador aberto. Este ZIP contém o projeto completo, não um aplicativo já compilado/notarizado.

## Atualizar

1. Exporte uma cópia .entre do seu projeto como backup e encerre o app com ⌘Q.
2. Extraia este ZIP.
3. No Terminal, digite `bash` e um espaço, arraste o arquivo `Gerar-App-Mac.sh` para o Terminal e pressione Enter.
4. Ao terminar, arraste o novo Ferdut Spaces.app da pasta build para Aplicativos e substitua o anterior.

É necessário gerar novamente o aplicativo para instalar a correção nativa da cópia. Abrir só o index.html ou copiar somente os arquivos Web não atualiza a parte nativa.

Identificador do app (`com.ferdut.spaces.mac`) e porta local (32189) permanecem iguais: o armazenamento existente do app é preservado. Dados que estão apenas no Safari precisam ser exportados como .entre e importados no aplicativo, pois são armazenamentos separados. Não altere identificador/porta sem migração.

## O que muda na 0.94

- As formas básicas ocupam toda a área de transformação. Foi removido o recuo de 3–4% que existia nos próprios caminhos geométricos. Retângulo, elipse, triângulo, estrela e demais formas seguem o mesmo critério. A borda de seleção acompanha a geometria; o contorno pintado pode se estender metade da espessura para fora, como um traço centrado no caminho.
- Contorno deixa de variar indevidamente conforme o tamanho da forma. A geometria nova é usada no canvas, imagens, máscaras, gradientes e cópia/exportação.
- Menu de aparência usa somente a largura dos controles. Foram retirados os botões de operações booleanas. O motor interno permanece para compatibilidade com documentos anteriores.
- Cópias compatíveis com SVG não publicam mais PNG junto. No app Mac, são oferecidos SVG, SVG como texto e uma representação PDF gerada diretamente do documento SVG pelo WebKit, sem captura de tela. Alguns editores de Mac recebem melhor o PDF do que o SVG.
- O PDF é preparado em uma vista temporária isolada e descartada após o uso. A janela/projeto não muda. Se falhar ou exceder o prazo, a cópia mantém SVG. Uma cópia feita em outro aplicativo durante a preparação não é sobrescrita.
- Seleções incompatíveis com SVG mantêm a cópia de imagem. Dentro do Ferdut, o conteúdo estruturado continua editável. Falha de envio de vetor oferece repetir ou salvar SVG, sem transformá-lo silenciosamente em PNG.

## Como testar a cópia

Abra o app novo, selecione um retângulo e uma elipse, pressione ⌘C, aguarde a confirmação e use ⌘V no Affinity. Confira se o resultado contém objetos editáveis em vez de uma camada de imagem. Repita com uma nota e uma paleta. Para programas que aceitam SVG como texto, esse formato continua disponível; a escolha de formato é feita pelo aplicativo receptor.

A colagem no Affinity/Figma e o PDF nativo ainda precisam ser validados no Mac. Não há garantia universal de reconstrução de uma caixa de parágrafo; o SVG contém texto editável com trechos posicionados. Se o receptor não aceitar o clipboard vetorial, ⌘⇧E salva o SVG da seleção para importar diretamente. As fontes Host Grotesk estão em Web/fonts para instalar no Catálogo de Fontes, caso o receptor substitua a tipografia.

## Recursos mantidos

Amostras com HEX/RGB/CMYK/PMS aproximado e tonalidades; editar/excluir na biblioteca; texto livre por padrão e conversão para caixa; alinhamento por grupos; notas com mínimo e duplicação lateral; menus recolhíveis; previews de links; funcionamento offline. Apresentações continua fora da interface principal.

CMYK é aproximação matemática de sRGB sem perfil ICC. PMS C usa referência digital local por proximidade Lab. Para produção, confira amostra física e perfil da gráfica.

## Validação disponível

Testes de interface em Chromium/Firefox, com receptores simulados de clipboard. Swift/AppKit/WKWebView e aplicativos receptores não podem ser executados neste Linux: compilação, assinatura, PDF nativo e colagem real dependem de teste no Mac. Detalhes em VALIDACAO.md.
